<?php
defined('ABSPATH') || exit;

final class SND_Data {
    private static $cache;

    public static function editable() {
        $data = get_option('snd_dataset', null);
        if (!is_array($data) || empty($data['territories'])) { $data = require SND_DIR . 'data/territories.php'; }
        $ids=array_column($data['territories'],'id');
        if(in_array('rs-00',$ids,true) && in_array('m-beograd',$ids,true)){
            foreach(require SND_DIR.'data/belgrade-municipalities.php' as $borough){if(!in_array($borough['id'],$ids,true)){$data['territories'][]=$borough;}}
            if(strpos($data['coverage']??'','Igra obuhvata 29 upravnih okruga i Grad Beograd')===0){$data['coverage']='Igra obuhvata upravne okruge, Grad Beograd i opštine, uključujući 17 gradskih opština Beograda i Kosovo i Metohiju. Za Kosovo i Metohiju koristi se podela na pet okruga i 29 opština. Stanovništvo je iz Popisa RZS 2022; gde uporediv podatak nije dostupan, postavlja se geografsko pitanje. Obrisi služe igri i nisu katastarske karte.';}
            $source='https://kro.mre.gov.rs/arcgis/rest/services/IMIS/MINING_PUBLIC/MapServer/4';
            if(!in_array($source,array_column($data['sources']??array(),'url'),true)){$data['sources'][]=array('label'=>'MRE — granice beogradskih gradskih opština','url'=>$source,'license'=>'Javni geografski servis MRE; nije navedena posebna licenca za redistribuciju. Granice su pojednostavljene.');}
        }
        $ids=array_column($data['territories'],'id');
        foreach(require SND_DIR.'data/city-municipalities.php' as $borough){if(in_array($borough['parent_id'],$ids,true) && !in_array($borough['id'],$ids,true)){$data['territories'][]=$borough;$ids[]=$borough['id'];}}
        if(strpos($data['coverage']??'','Igra obuhvata upravne okruge')===0){$data['coverage']='Igra obuhvata 29 upravnih okruga i Grad Beograd, kao i 197 opština, gradskih opština i gradova prema spisku RZS. Pet gradova je predstavljeno kroz svih 28 gradskih opština, bez preklapanja sa matičnim gradovima. Uključeni su Kosovo i Metohija sa pet okruga i 29 opština. Popis RZS 2022. tamo nije sproveden. Obrisi služe igri i nisu katastarske karte.';}
        // Refresh only the shipped Belgrade default; administrator edits take precedence.
        foreach ($data['territories'] as &$item) {
            if (in_array($item['id'],array('rs-00','m-beograd'),true) && ($item['landmark']['name']??'')==='Beogradska tvrđava' && ($item['landmark']['image']??'')==='photos/4056dbb5852cdbe3.jpg') {
                $item['landmark']=require SND_DIR.'data/belgrade-landmark.php';
            }
        }
        unset($item);
        $overrides = get_option('snd_overrides', array());
        foreach ($data['territories'] as &$item) { if (isset($overrides[$item['id']])) { $item = array_merge($item, $overrides[$item['id']]); } }
        unset($item);
        return $data;
    }

    public static function get() {
        if (self::$cache !== null) { return self::$cache; }
        $data = self::editable();
        $items = array();
        foreach ($data['territories'] as $item) {
            if (!empty($item['disabled'])) { continue; }
            $items[$item['id']] = $item;
        }
        $data['territories'] = $items;
        $data['revision'] = substr(hash('sha256', wp_json_encode($data)), 0, 16);
        self::$cache = $data;
        return $data;
    }

    public static function reset_cache() { self::$cache = null; }

    public static function pool($kind) {
        if(SND_Kinds::is_explore($kind)){return SND_Explore::pool($kind);}
        $data = self::get();
        $retired=self::retired_ids();return array_filter($data['territories'], function ($t) use ($kind,$retired) { return $t['kind'] === $kind && !in_array($t['id'],$retired,true); });
    }
    public static function retired_ids() {
        $parents=array();foreach(self::get()['territories'] as $t){if(!empty($t['parent_id'])){$parents[]=$t['parent_id'];}}return array_values(array_unique($parents));
    }

    public static function image_url($path) {
        if (strpos($path, 'https://') === 0) { return esc_url_raw($path, array('https')); }
        return SND_URL . 'assets/' . ltrim($path, '/');
    }

    public static function validate($data) {
        if (!is_array($data) || !isset($data['schema']) || (int) $data['schema'] !== 1 || empty($data['territories']) || !is_array($data['territories'])) {
            return new WP_Error('snd_schema', 'Očekivan je JSON sa schema: 1 i nizom territories.');
        }
        if (count($data['territories']) > 400) { return new WP_Error('snd_size', 'Dozvoljeno je najviše 400 teritorija.'); }
        $out = array('schema' => 1, 'coverage' => sanitize_text_field($data['coverage'] ?? ''), 'sources' => array(), 'territories' => array());
        foreach (array_slice((array) ($data['sources'] ?? array()), 0, 30) as $s) {
            $out['sources'][] = array('label' => sanitize_text_field($s['label'] ?? ''), 'url' => esc_url_raw($s['url'] ?? '', array('https')), 'license' => sanitize_text_field($s['license'] ?? ''));
        }
        $ids = array();
        $counts = array('district' => 0, 'municipality' => 0);
        foreach ($data['territories'] as $t) {
            if (!is_array($t)) { return new WP_Error('snd_item', 'Svaka teritorija mora biti objekat.'); }
            $id = is_string($t['id'] ?? null) ? $t['id'] : '';
            $kind = $t['kind'] ?? '';
            if (!preg_match('/^[a-z0-9-]{1,70}$/D', $id) || isset($ids[$id]) || !is_string($kind) || !isset($counts[$kind]) || !is_string($t['name'] ?? null) || trim(sanitize_text_field($t['name'])) === '') {
                return new WP_Error('snd_identity', 'Teritorija nema jedinstven ispravan id, name ili kind (district/municipality).');
            }
            foreach (array('path', 'map_path') as $key) {
                if (!isset($t[$key]) || !is_string($t[$key]) || strlen($t[$key]) > 150000 || !preg_match('/^[MmLlHhVvCcSsQqTtAaZz0-9eE.,\s+\-]+$/D', $t[$key])) {
                    return new WP_Error('snd_shape', 'Neispravna SVG putanja za ' . $id . '. Dozvoljeni su samo podaci putanje.');
                }
            }
            $c = $t['center'] ?? null;
            if (!is_array($c) || count($c) !== 2 || !isset($c[0], $c[1]) || !is_numeric($c[0]) || !is_numeric($c[1]) || $c[0] < 40 || $c[0] > 48 || $c[1] < 17 || $c[1] > 25) {
                return new WP_Error('snd_center', 'Neispravan center [geografska širina, geografska dužina] za ' . $id . '.');
            }
            $row = array('id' => $id, 'kind' => $kind, 'name' => sanitize_text_field($t['name']), 'center' => array((float) $c[0], (float) $c[1]), 'path' => $t['path'], 'map_path' => $t['map_path']);
            foreach (array('region', 'seat', 'district_id','parent_name','sors_code') as $key) { $row[$key] = sanitize_text_field($t[$key] ?? ''); }
            if(isset($t['parent_id']) && !is_string($t['parent_id'])){return new WP_Error('snd_parent','Neispravna matična gradska celina: '.$id);}
            if(isset($t['boundary_source']) && !is_string($t['boundary_source'])){return new WP_Error('snd_source','Neispravan izvor granice: '.$id);}
            if(!empty($t['parent_id'])){$row['parent_id']=sanitize_key($t['parent_id']);}
            if(!empty($t['boundary_source'])){$row['boundary_source']=esc_url_raw($t['boundary_source'],array('https'));}
            $row['aliases'] = array_map('sanitize_text_field', array_slice((array) ($t['aliases'] ?? array()), 0, 15));
            $row['population'] = max(0, (int) ($t['population'] ?? 0));
            $row['year'] = (int) ($t['year'] ?? 0);
            $row['population_source'] = esc_url_raw($t['population_source'] ?? '', array('https'));
            if ($row['population'] && ($row['year'] < 1900 || $row['year'] > (int) gmdate('Y') || !$row['population_source'])) {
                return new WP_Error('snd_population', 'Za stanovništvo su obavezni ispravna godina i HTTPS izvor: ' . $id);
            }
            if ($kind === 'district' && empty($row['seat'])) { return new WP_Error('snd_seat', 'Nedostaje sedište: ' . $id); }
            $row['landmark'] = array();
            if (!empty($t['landmark']['name']) && !empty($t['landmark']['image'])) {
                $l = $t['landmark'];
                $image = (string) $l['image'];
                if (!(strpos($image, 'https://') === 0 && esc_url_raw($image, array('https'))) && !preg_match('~^photos/[a-zA-Z0-9_-]+\.(jpg|jpeg|png|webp)$~D', $image)) {
                    return new WP_Error('snd_image', 'Neispravna putanja fotografije za ' . $id);
                }
                if (empty($l['credit']) || empty($l['license']) || empty($l['source_url'])) { return new WP_Error('snd_credit', 'Fotografija zahteva autora, licencu i izvor: ' . $id); }
                foreach (array('name', 'credit', 'license', 'fact') as $key) { $row['landmark'][$key] = sanitize_text_field($l[$key] ?? ''); }
                if(isset($l['quiz_name']) && is_string($l['quiz_name'])){$row['landmark']['quiz_name']=sanitize_text_field($l['quiz_name']);}
                $row['landmark']['image'] = $image;
                $row['landmark']['source_url'] = esc_url_raw($l['source_url'], array('https'));
                foreach(array('sr','en','de','ru') as $lang){foreach(array('name','fact','quiz_name') as $field){
                    if(!empty($l['translations'][$lang][$field]) && is_string($l['translations'][$lang][$field])){$row['landmark']['translations'][$lang][$field]=sanitize_text_field($l['translations'][$lang][$field]);}
                }}
            }
            $row['disabled'] = !empty($t['disabled']);
            $ids[$id] = true;
            if (!$row['disabled']) { $counts[$kind]++; }
            $out['territories'][] = $row;
        }
        foreach($out['territories'] as $row){if(!empty($row['parent_id']) && !isset($ids[$row['parent_id']])){return new WP_Error('snd_parent','Nedostaje matična gradska celina: '.$row['id']);}}
        $parents=array();foreach($out['territories'] as $row){if(!$row['disabled'] && !empty($row['parent_id'])){$parents[$row['parent_id']]=true;}}
        foreach($out['territories'] as $row){if(!$row['disabled'] && isset($parents[$row['id']])){$counts['municipality']--;}}
        if ($counts['district'] < 4 || $counts['municipality'] < 4) { return new WP_Error('snd_pool', 'Potrebne su najmanje četiri aktivne teritorije u svakoj igri.'); }
        foreach ($out['territories'] as $row) {
            if ($row['kind'] === 'municipality' && (!isset($ids[$row['district_id']]) || !self::find_district($out['territories'], $row['district_id']))) {
                return new WP_Error('snd_parent', 'Opština mora imati postojeći district_id okruga: ' . $row['id']);
            }
            if ($row['kind'] === 'district' && !$row['disabled'] && in_array($row['id'], array('rs-25', 'rs-26', 'rs-27', 'rs-28', 'rs-29'), true)) {
                $members = array_filter($out['territories'], function ($m) use ($row) { return $m['kind'] === 'municipality' && !$m['disabled'] && $m['district_id'] === $row['id']; });
                if (!$members) { return new WP_Error('snd_members', 'Okrug mora imati najmanje jednu aktivnu opštinu za pitanje o pripadnosti: ' . $row['id']); }
            }
        }
        return $out;
    }

    private static function find_district($rows, $id) {
        foreach ($rows as $row) { if ($row['id'] === $id) { return $row['kind'] === 'district' && !$row['disabled']; } }
        return false;
    }
}
