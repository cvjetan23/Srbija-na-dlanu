<?php
defined('ABSPATH') || exit;

final class SND_Explore_Admin {
    public static function menu(){add_submenu_page('srbija-na-dlanu','Gradovi, reke i planine','Geografski katalozi','manage_options','snd-explore',array(__CLASS__,'page'));}
    public static function url($args=array()){return add_query_arg(array_merge(array('page'=>'snd-explore'),$args),admin_url('admin.php'));}
    private static function guard(){if(!current_user_can('manage_options')){wp_die('Nedovoljne dozvole.','',array('response'=>403));}}
    public static function page(){
        self::guard();$kind=in_array($_GET['kind']??'',SND_Kinds::EXPLORE,true)?$_GET['kind']:'city';$pool=array();foreach(SND_Explore::data()['items'] as $t){if($t['kind']===$kind){$pool[$t['id']]=$t;}}$key=is_string($_GET['item']??null)?sanitize_key($_GET['item']):'';$current=$pool[$key]??null;$search=is_string($_GET['search']??null)?sanitize_text_field(wp_unslash($_GET['search'])):'';
        echo '<div class="wrap snd-control"><h1>Gradovi, reke i planine</h1><p>Unosi se čuvaju u istoj WordPress bazi. Izvorne datoteke i prethodne partije ostaju sačuvani. Izmene važe za buduće dnevne zadatke; današnja pitanja su zamrznuta.</p>';
        if(isset($_GET['saved'])){echo '<div class="notice notice-success"><p>Katalog je sačuvan.</p></div>';}
        echo '<form method="get"><input type="hidden" name="page" value="snd-explore"><select name="kind">';foreach(SND_Kinds::EXPLORE as $k){echo '<option value="'.$k.'" '.selected($k,$kind,false).'>'.esc_html(SND_Kinds::labels()[$k]).'</option>';}echo '</select> <input type="search" name="search" value="'.esc_attr($search).'" placeholder="Pronađi naziv…"> <button class="button">Prikaži</button></form><p>U katalogu: '.count($pool).' · Kompletni dnevni zadaci: '.count(SND_Explore::targets($kind)).'. Spremna planina može imati pitanje o smeru umesto foto-pitanja.</p>';
        if($current){self::edit_form($current);}
        echo '<table class="widefat striped"><thead><tr><th>Naziv</th><th>Oblast</th><th>Dnevni fond</th><th>Fotografija</th><th>Izvor</th></tr></thead><tbody>';$shown=0;
        foreach($pool as $t){if($search && strpos(SND_Text::key($t['name'].' '.implode(' ',$t['aliases']??array())),SND_Text::key($search))===false){continue;}$shown++;echo '<tr><th><a href="'.esc_url(self::url(array('kind'=>$kind,'item'=>$t['id']))).'">'.esc_html($t['display_name']??$t['name']).'</a><br><code>'.esc_html($t['id']).'</code></th><td>'.esc_html($t['district_name']).'</td><td>'.(!SND_Explore::reviewed($t)?'Nacrt — čeka potvrdu':(!empty($t['playable'])?'Spremno':'Potvrđeno / dopuniti podatke')).'</td><td>'.(!empty($t['photo']['image'])?'Da':($t['kind']==='mountain'?'Pitanje o smeru':'Nedostaje')).'</td><td><a href="'.esc_url($t['source']).'" target="_blank" rel="noopener noreferrer">Izvor</a></td></tr>';}
        if(!$shown){echo '<tr><td colspan="5">Nema rezultata.</td></tr>';}echo '</tbody></table><hr><h2>Uvoz i izvoz kataloga</h2><p>JSON obuhvata sve tri igre, geometriju, nazive, podatke i potpise fotografija. Pre uvoza preuzmi izvoz. Nepotpune stavke ostaju van dnevnog fonda. Mape su SVG podaci putanje, bez skripti ili HTML-a.</p><p><a class="button" href="'.esc_url(wp_nonce_url(add_query_arg('action','snd_explore_export',admin_url('admin-post.php')),'snd_explore_export')).'">Izvezi katalog (JSON)</a></p><form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('snd_explore_save');echo '<input type="hidden" name="action" value="snd_explore_save"><input type="file" name="catalogue" accept=".json,application/json" required> ';submit_button('Uvezi provereni JSON','secondary','submit',false);echo '</form></div>';
    }
    private static function edit_form($t){
        echo '<h2>'.esc_html($t['name']).'</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('snd_explore_save');echo '<input type="hidden" name="action" value="snd_explore_save"><input type="hidden" name="item" value="'.esc_attr($t['id']).'"><table class="form-table">';
        $fields=array('name'=>'Naziv','region'=>'Šira geografska celina','district_name'=>'Okrug / položaj','population'=>'Stanovništvo naselja','year'=>'Godina popisa','population_source'=>'Izvor popisa','river_name'=>'Reka uz naselje (ako je potvrđeno)','river_source'=>'Izvor veze naselja i reke','peak'=>'Referentni vrh','height'=>'Visina vrha (m)','peak_scope'=>'Obuhvat pitanja o vrhu','mouth'=>'Neposredni recipijent (reka / jezero / more)','sea'=>'Morski sliv','length_km'=>'Ukupna dužina reke (km)','facts_source'=>'Izvor vrha / ušća / dužine','basin_source'=>'Izvor sliva','area_km2'=>'Površina (km²), samo ako je potvrđena','area_scope'=>'Šta tačno obuhvata navedena površina','area_source'=>'Izvor površine','source'=>'Osnovni geografski izvor');
        foreach($fields as $k=>$label){$numeric=in_array($k,array('population','year','height','length_km','area_km2'),true);echo '<tr><th><label for="snd-explore-'.esc_attr($k).'">'.esc_html($label).'</label></th><td><input id="snd-explore-'.esc_attr($k).'" class="regular-text" name="item_data['.esc_attr($k).']" type="'.($numeric?'number':'text').'" '.($numeric?'step="any" min="0"':'').' value="'.esc_attr($t[$k]??'').'"></td></tr>';}
        foreach(array('lat'=>array('Geografska širina',$t['center'][0]),'lon'=>array('Geografska dužina',$t['center'][1])) as $k=>$v){echo '<tr><th>'.esc_html($v[0]).'</th><td><input type="number" step="any" name="item_data['.$k.']" value="'.esc_attr($v[1]).'" required></td></tr>';}
        foreach(array('image'=>'Fotografija: lokalna putanja ili HTTPS URL iz WP biblioteke','credit'=>'Autor fotografije','license'=>'Licenca fotografije','license_url'=>'Veza ka tekstu licence','source_url'=>'Izvorna stranica fotografije') as $k=>$label){echo '<tr><th>'.esc_html($label).'</th><td><input class="regular-text" name="photo['.$k.']" value="'.esc_attr($t['photo'][$k]??'').'"></td></tr>';}
        echo '<tr><th>Provera naziva</th><td><label><input type="checkbox" name="reviewed" value="1" '.checked(SND_Explore::reviewed($t),true,false).'> Naziv i identitet su potvrđeni nezavisnim izvorom</label><p><input class="regular-text" type="url" name="item_data[verification_source]" placeholder="https://…" value="'.esc_attr($t['verification_source']??'').'"></p><textarea name="item_data[review_note]" rows="2" cols="60">'.esc_textarea($t['review_note']??'').'</textarea><p class="description">Nepotvrđene stavke ostaju urednički nacrt: ne nude se kao odgovori i nisu u javnoj bazi znanja.</p></td></tr>';
        echo '<tr><th>Alternativni nazivi</th><td><textarea name="aliases" rows="3" cols="60">'.esc_textarea(implode("\n",$t['aliases']??array())).'</textarea></td></tr>';
        foreach(array('sr','en','de','ru') as $lang){echo '<tr><th>Naziv: '.esc_html(SND_I18n::languages()[$lang]).'</th><td><input class="regular-text" name="labels['.$lang.']" value="'.esc_attr($t['labels'][$lang]??$t['name']).'"></td></tr>';}
        echo '<tr><th>Tok / obris (SVG podaci)</th><td><textarea name="item_data[map_path]" rows="3" cols="70">'.esc_textarea($t['map_path']).'</textarea></td></tr></table><p><label><input type="checkbox" name="playable" value="1" '.checked(!empty($t['playable']),true,false).'> Uključi u dnevni fond kada su podaci za sva pitanja kompletni</label></p><p><label><input type="checkbox" name="disabled" value="1" '.checked(!empty($t['disabled']),true,false).'> Isključi iz kataloga</label></p>';submit_button('Sačuvaj geografsku stavku');echo '</form><hr>';
    }
    public static function save(){
        self::guard();check_admin_referer('snd_explore_save');$data=SND_Explore::data();$key=is_string($_POST['item']??null)?sanitize_key($_POST['item']):'';$kind='city';
        if($key){
            $found=false;foreach($data['items'] as &$t){if($t['id']!==$key){continue;}$found=true;$kind=$t['kind'];$input=is_array($_POST['item_data']??null)?wp_unslash($_POST['item_data']):array();$t=array_merge($t,$input);$t['center']=array((float)($input['lat']??$t['center'][0]),(float)($input['lon']??$t['center'][1]));unset($t['lat'],$t['lon']);$t['point']=SND_Explore::project($t['center']);$t['aliases']=preg_split('/\r?\n/',is_string($_POST['aliases']??null)?wp_unslash($_POST['aliases']):'');$t['labels']=is_array($_POST['labels']??null)?wp_unslash($_POST['labels']):array();$t['photo']=is_array($_POST['photo']??null)?wp_unslash($_POST['photo']):array();if(empty($t['photo']['image'])){$t['photo']=array();}$t['review_status']=!empty($_POST['reviewed'])?'verified':'pending';$t['reviewed_on']=wp_date('Y-m-d');$t['playable']=!empty($_POST['playable']);$t['disabled']=!empty($_POST['disabled']);}unset($t);if(!$found){wp_die('Stavka nije pronađena.','',array('response'=>404));}
        }else{
            $f=$_FILES['catalogue']??array();if(($f['error']??1)!==UPLOAD_ERR_OK || ($f['size']??0)>8*1024*1024 || !is_uploaded_file($f['tmp_name']??'')){wp_die('Otpremi JSON do 8 MB.','',array('response'=>400));}$data=json_decode(file_get_contents($f['tmp_name']),true);
        }
        $valid=SND_Explore::validate($data);if(is_wp_error($valid)){wp_die(esc_html($valid->get_error_message()),'',array('response'=>400));}update_option('snd_explore_catalogue',$valid,false);SND_Explore::reset();wp_safe_redirect(self::url(array('saved'=>1,'kind'=>$kind,'item'=>$key)));exit;
    }
    public static function export(){self::guard();check_admin_referer('snd_explore_export');nocache_headers();header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="snd-geografski-katalozi.json"');echo wp_json_encode(SND_Explore::data(),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);exit;}
    public static function current(){if(SND_Site::view()!=='library' || !in_array($_GET['tip']??'',SND_Kinds::EXPLORE,true) || !is_string($_GET['objekat']??null)){return null;}$pool=SND_Catalogue::pool($_GET['tip']);return $pool[sanitize_key($_GET['objekat'])]??null;}
    public static function library_tabs(){SND_Catalogue::tabs();}
    public static function library(){return SND_Catalogue::library();}
    public static function detail($t){
        echo '<article class="snd-explore-detail"><h2>'.esc_html(SND_Explore::name($t)).'</h2><dl class="snd-facts">';$facts=array('Položaj'=>$t['region']);if($t['kind']==='city' && !empty($t['district_name'])){$facts['Okrug']=$t['district_name'];}
        if($t['kind']==='city'){$facts['Stanovništvo naselja']=!empty($t['population'])?SND_I18n::number($t['population']).' · '.$t['year']:'—';}
        elseif($t['kind']==='river'){$facts['Uliva se u']=$t['mouth']??'—';$facts['Morski sliv']=$t['sea']??'—';$facts['Dužina · ceo tok']=!empty($t['length_km'])?SND_I18n::number($t['length_km']).' km':'—';}
        else{
            $facts['Vrh']=$t['peak'];$facts['Visina']=$t['height'].' m';
            if(!empty($t['prominence'])){$facts['Prominencija']=$t['prominence'].' m';}
            if(!empty($t['peak_scope'])){$facts['Obuhvat']=$t['peak_scope'];}
            if(!empty($t['book_pages'])){$facts['Stranice izvora']=implode(', ',$t['book_pages']);}
            if(!empty($t['area_km2'])){$facts['Površina']=$t['area_km2'].' km² · '.$t['area_scope'];}
            $book=SND_Explore::mountain_book_entry($t);
            if($book && $book['center']===$t['center']){
                $facts['Koordinate vrha']=implode(' N, ',$book['book_coordinates']).' E';
                $facts['Strane tabele']=implode(', ',array_unique(array_column($book['book_sections'],'table_page')));
                $facts['Oblast u knjizi']=implode(' / ',array_unique(array_column($book['book_sections'],'area')));
                $groups=array_filter(array_column($book['book_sections'],'group'));
                if($groups){$facts['Podoblast u knjizi']=implode(' / ',array_unique($groups));}
            }
        }
        foreach($facts as $label=>$value){echo '<div><dt>'.esc_html(SND_I18n::t($label)).'</dt><dd>'.esc_html($value?:'—').'</dd></div>';}echo '</dl>';
        if(!empty($t['photo']['image'])){$p=$t['photo'];echo '<img src="'.esc_url(SND_Data::image_url($p['image'])).'" alt="'.esc_attr(SND_Explore::name($t)).'" loading="lazy"><p class="snd-photo-credit">'.esc_html($p['credit'].' · '.$p['license']).' · <a href="'.esc_url($p['source_url']).'" target="_blank" rel="noopener noreferrer">Izvor fotografije</a></p>';}
        if(!empty($t['verification_source'])){echo '<p class="snd-catalogue-proof">Potvrda naziva: <a href="'.esc_url($t['verification_source']).'" target="_blank" rel="noopener noreferrer">'.esc_html($t['kind']==='mountain'?'Izvor za ovu planinu':($t['kind']==='river'?'Pregled izvora za ovu reku':'Pregled izvora za ovo naselje')).' ↗</a></p>';}
        echo '<p>'.($t['kind']==='mountain'?'Pin označava položaj vrha planine.':($t['kind']==='river'?'Na mapi je deo toka na teritoriji Srbije; podatak o dužini odnosi se na celu reku.':'Stanovništvo se odnosi na naselje, ne na celu opštinu.')).'</p><p><a href="'.esc_url(!empty($t['facts_source'])?$t['facts_source']:$t['source']).'" target="_blank" rel="noopener noreferrer">Izvor podataka</a> · <a href="'.esc_url($t['source']).'" target="_blank" rel="noopener noreferrer">Geografski izvor</a></p><a class="snd-app-button" href="'.esc_url(SND_Site::url($t['kind'])).'">Igraj današnji izazov</a></article>';
    }
}
add_action('admin_menu',array('SND_Explore_Admin','menu'),30);
add_action('admin_post_snd_explore_save',array('SND_Explore_Admin','save'));
add_action('admin_post_snd_explore_export',array('SND_Explore_Admin','export'));
