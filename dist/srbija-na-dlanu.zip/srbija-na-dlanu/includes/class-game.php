<?php
defined('ABSPATH') || exit;

final class SND_Game {
    const MAX_GUESSES = 6;
    const RULESET = 4;

    public static function date() { return (new DateTimeImmutable('now', new DateTimeZone('Europe/Belgrade')))->format('Y-m-d'); }

    public static function ordered($items, $seed) {
        $items = array_values($items);
        usort($items, function ($a, $b) use ($seed) {
            $a = is_array($a) ? ($a['id'] ?? wp_json_encode($a)) : (string) $a;
            $b = is_array($b) ? ($b['id'] ?? wp_json_encode($b)) : (string) $b;
            return strcmp(hash('sha256', $seed . '|' . $a), hash('sha256', $seed . '|' . $b));
        });
        return $items;
    }

    public static function distance($a, $b) {
        $la = deg2rad($a[0]); $lb = deg2rad($b[0]);
        $v = pow(sin(($lb - $la) / 2), 2) + cos($la) * cos($lb) * pow(sin(deg2rad($b[1] - $a[1]) / 2), 2);
        return 6371.0088 * 2 * atan2(sqrt(min(1, $v)), sqrt(max(0, 1 - $v)));
    }

    public static function direction($from, $to) {
        $la = deg2rad($from[0]); $lb = deg2rad($to[0]); $dl = deg2rad($to[1] - $from[1]);
        $angle = fmod(rad2deg(atan2(sin($dl) * cos($lb), cos($la) * sin($lb) - sin($la) * cos($lb) * cos($dl))) + 360, 360);
        $i = ((int) floor(($angle + 22.5) / 45)) % 8;
        $names = array('sever', 'severoistok', 'istok', 'jugoistok', 'jug', 'jugozapad', 'zapad', 'severozapad');
        $arrows = array('↑', '↗', '→', '↘', '↓', '↙', '←', '↖');
        return array('name' => $names[$i], 'arrow' => $arrows[$i]);
    }

    private static function choice_question($type, $title, $correct, $other, $seed, $explanation, $source = '') {
        $other = array_values(array_unique(array_filter($other, function ($x) use ($correct) { return $x !== $correct && $x !== ''; })));
        $values = array_merge(array($correct), array_slice(self::ordered($other, $seed . ':decoys'), 0, 3));
        $options = array();
        foreach ($values as $value) { $options[] = array('id' => substr(hash('sha256', $seed . ':' . $value), 0, 16), 'label' => $value); }
        return array('type' => $type, 'title' => $title, 'options' => self::ordered($options, $seed . ':order'), 'correct' => $options[0]['id'], 'explanation' => $explanation, 'source' => $source);
    }

    public static function geometry_sources($territories) {
        if($territories && SND_Kinds::is_explore(reset($territories)['kind']??'')){return SND_Explore::geometry_sources($territories);}
        $kim=false;$other=false;$extra=array();
        foreach($territories as $t){if(!empty($t['boundary_source'])){$extra[$t['boundary_source']]=($t['parent_id']??'')==='m-beograd'?'MRE — granice beogradskih gradskih opština':'Granice teritorije';}elseif(($t['region']??'')==='Kosovo i Metohija'){$kim=true;}else{$other=true;}}
        $out=array();
        if($kim){$out[]=array('label'=>'MRE — granice Kosova i Metohije','url'=>'https://kro.mre.gov.rs/arcgis/rest/services/IMIS/MINING_PUBLIC/MapServer');}
        foreach($extra as $url=>$label){$out[]=array('label'=>$label,'url'=>$url);}
        if($other){$out[]=array('label'=>'geoBoundaries / OpenStreetMap — granice ostalih teritorija','url'=>'https://www.geoboundaries.org/');}
        return $out;
    }

    private static function with_geometry_sources($question,$territories) {
        $question['sources']=self::geometry_sources($territories);
        $question['source']=$question['sources'][0]['url']??'';
        return $question;
    }

    public static function distance_question($target,$pool,$seed,$subtitle='') {
        $others=array_filter($pool,function($t)use($target){return $t['id']!==$target['id'] && self::distance($target['center'],$t['center'])>25;});
        if(!$others){$others=array_filter($pool,function($t)use($target){return $t['id']!==$target['id'];});}
        $ordered=self::ordered($others,$seed.':distance-anchor');$anchor=$ordered[0];
        $km=max(1,(int)round(self::distance($target['center'],$anchor['center'])));
        $step=$km>=50?10:5;$rounded=max($step,(int)(round($km/$step)*$step));
        $label=function($n){return 'Oko '.number_format($n,0,',','.').' km';};$decoys=array();
        foreach(array(.5,.75,1.3,1.6,1.9) as $factor){$n=max($step,(int)(round($rounded*$factor/$step)*$step));if($n!==$rounded){$decoys[]=$label($n);}}
        $q=self::choice_question('distance','Koliko su približno udaljeni centri teritorija „'.$target['name'].'“ i „'.$anchor['name'].'“?',$label($rounded),$decoys,$seed.':distance','Vazdušna udaljenost između geometrijskih centara je približno '.$km.' km. Ne meri se put automobilom ni razmak između granica.');
        $q['subtitle']=$subtitle;
        return self::with_geometry_sources($q,array($target,$anchor));
    }

    public static function nearby_question($target,$pool,$seed,$subtitle='') {
        $others=array_filter($pool,function($t)use($target){return $t['id']!==$target['id'];});
        uasort($others,function($a,$b)use($target){return self::distance($target['center'],$a['center'])<=>self::distance($target['center'],$b['center']);});
        $near=reset($others);$decoys=array();$used=array($target,$near);
        foreach($others as $t){
            if(self::distance($target['center'],$t['center'])>self::distance($target['center'],$near['center'])+1){
                $decoys[]=$t['name'];$used[]=$t;if(count($decoys)>=8){break;}
            }
        }
        if(count($decoys)<3){return self::distance_question($target,$pool,$seed,$subtitle);}
        $q=self::choice_question('nearby','Koja od ovih teritorija ima centar najbliži centru tražene teritorije?',$near['name'],$decoys,$seed.':nearby','Od ponuđenih odgovora, najbliža je teritorija '.$near['name'].': približno '.round(self::distance($target['center'],$near['center'])).' km vazdušnom linijom između geometrijskih centara.');
        $q['subtitle']=$subtitle;
        return self::with_geometry_sources($q,$used);
    }

    public static function question_for($state,$index) {
        if(isset($state['question_overrides'][$index])){return $state['question_overrides'][$index];}
        $q=$state['challenge']['questions'][$index];
        if($q['type']==='region' && !isset($state['answers'][$index])){
            return self::distance_question($state['challenge']['target'],SND_Data::pool($state['challenge']['kind']),$state['challenge']['date'].':legacy:'.$state['challenge']['target']['id'].':'.$index,'Zamensko geografsko pitanje: zastava ovog mesta još nije potvrđena u bazi.');
        }
        if($q['type']==='region' && empty($q['source'])){$q['source']=add_query_arg('podela','regioni',SND_Site::url('library'));}
        if(empty($q['sources']) && in_array($q['type'],array('nearby','orientation'),true)){
            $used=array($state['challenge']['target']);$names=array_column($q['options'],'label');
            if($q['type']==='orientation' && preg_match('/„([^“]+)“/u',$q['title'],$match)){$names[]=$match[1];}
            foreach(SND_Data::pool($state['challenge']['kind']) as $t){if(in_array($t['name'],$names,true)){$used[]=$t;}}
            $q=self::with_geometry_sources($q,$used);
        }
        return $q;
    }

    public static function questions($target, $pool, $districts, $seed) {
        $q = array();
        if (!empty($target['population'])) {
            $round = function ($n) { return (int) (round($n / ($n >= 10000 ? 1000 : 100)) * ($n >= 10000 ? 1000 : 100)); };
            $correct = $round($target['population']); $decoys = array();
            foreach(array(.55,.75,1.3,1.55,1.75) as $factor){
                $n=max(100,$round($target['population']*$factor));
                if($n!==$correct){$decoys[]='Oko '.number_format($n,0,',','.');}
            }
            $q[] = self::choice_question('population', 'Koliko približno stanovnika ima cela teritorija?', 'Oko ' . number_format($correct, 0, ',', '.'), $decoys, $seed . ':population', 'Prema Popisu ' . $target['year'] . ', cela teritorija ima ' . number_format($target['population'], 0, ',', '.') . ' stanovnika. Podatak se ne odnosi samo na naselje.', $target['population_source']);
            $q[0]['subtitle'] = 'Popis ' . $target['year'] . ' · stanovništvo cele teritorije';
        } else {
            $anchors = array_filter($pool, function ($t) use ($target) { return $t['id'] !== $target['id'] && self::distance($t['center'], $target['center']) > 10; });
            if (!$anchors) { $anchors = array_filter($pool, function ($t) use ($target) { return $t['id'] !== $target['id']; }); }
            $anchors = self::ordered($anchors, $seed . ':anchor'); $anchor = $anchors[0];
            $direction = self::direction($target['center'], $anchor['center']);
            $reason = $target['region'] === 'Kosovo i Metohija' ? 'Popis RZS 2022. nije sproveden na teritoriji Kosova i Metohije; zato je ovde geografsko pitanje.' : 'Za ovu teritoriju u bazi nije naveden uporediv podatak o stanovništvu, pa je postavljeno geografsko pitanje.';
            $q[] = self::choice_question('orientation', 'U kom smeru je centar teritorije „' . $anchor['name'] . '“ u odnosu na ovu teritoriju?', ucfirst($direction['name']), array('Sever', 'Severoistok', 'Istok', 'Jugoistok', 'Jug', 'Jugozapad', 'Zapad', 'Severozapad'), $seed . ':orientation', 'Od centra teritorije ' . $target['name'] . ' ka centru teritorije ' . $anchor['name'] . ' kreće se u smeru: ' . $direction['name'] . '. ' . $reason, $target['region'] === 'Kosovo i Metohija' ? 'https://kro.mre.gov.rs/arcgis/rest/services/IMIS/MINING_PUBLIC/MapServer' : 'https://www.geoboundaries.org/');
            $q[0]=self::with_geometry_sources($q[0],array($target,$anchor));
        }
        if ($target['kind'] === 'district' && in_array($target['id'], array('rs-25', 'rs-26', 'rs-27', 'rs-28', 'rs-29'), true)) {
            $municipalities = SND_Data::pool('municipality'); $inside = array(); $outside = array();
            foreach ($municipalities as $m) { if ($m['district_id'] === $target['id']) { $inside[] = $m['name']; } else { $outside[] = $m['name']; } }
            $inside = self::ordered($inside, $seed . ':member');
            $q[] = self::choice_question('membership', 'Koja od ovih opština pripada ovom okrugu?', $inside[0], $outside, $seed . ':membership', 'Opština ' . $inside[0] . ' pripada celini: ' . $target['name'] . ', prema podeli na pet upravnih okruga na Kosovu i Metohiji.', 'https://kro.mre.gov.rs/arcgis/rest/services/IMIS/MINING_PUBLIC/MapServer');
        } elseif ($target['kind'] === 'district' && $target['id'] !== 'rs-00') {
            $q[] = self::choice_question('seat', 'Koje je sedište ovog okruga?', $target['seat'], array_column($districts, 'seat'), $seed . ':seat', 'Sedište okruga je ' . $target['seat'] . '.', $target['region']==='Kosovo i Metohija'?'https://kro.mre.gov.rs/arcgis/rest/services/IMIS/MINING_PUBLIC/MapServer':'https://www.srbija.gov.rs/sekcija/329/okruzi.php');
        } elseif (!empty($target['parent_id'])) {
            $city=$target['parent_name']??'Beograd';$alternatives=array_values(array_diff(array('Beograd','Niš','Požarevac','Vranje','Užice','Novi Sad','Kragujevac'),array($city)));$q[]=self::choice_question('city_membership','Kom gradu pripada ova gradska opština?',$city,$alternatives,$seed.':city','Gradska opština '.$target['name'].' pripada gradu '.$city.'.','https://www.stat.gov.rs/sr-latn/oblasti/registar-prostornih-jedinica-i-gis/administrativno-teritorijalna-podela-i-nstj-nivoi-1-2-3/');
        } elseif ($target['kind'] === 'municipality' && $target['district_id'] !== 'rs-00') {
            $parent = $districts[$target['district_id']];
            $q[] = self::choice_question('district', 'Kojem okrugu pripada ova teritorija?', $parent['name'], array_column($districts, 'name'), $seed . ':district', $target['name'] . ' pripada administrativnoj celini: ' . $parent['name'] . '.', $target['region']==='Kosovo i Metohija'?'https://kro.mre.gov.rs/arcgis/rest/services/IMIS/MINING_PUBLIC/MapServer':'https://www.srbija.gov.rs/sekcija/329/okruzi.php');
        } else {
            $q[] = self::choice_question('river', 'Na ušću kojih reka se nalazi Beograd?', 'Save i Dunava', array('Tise i Dunava', 'Drine i Save', 'Južne i Zapadne Morave'), $seed . ':river', 'Beograd se nalazi na ušću Save u Dunav.', 'https://www.tob.rs/');
        }
        $landmarks = array();
        foreach (array_merge(array_values($districts), array_values($pool)) as $t) { if (!empty($t['landmark']['name'])) { $landmarks[] = $t['landmark']['name']; } }
        if (!empty($target['landmark']['image']) && count(array_unique($landmarks)) >= 4) {
            $l = $target['landmark'];
            $last = self::choice_question('landmark', 'Koja je znamenitost na fotografiji?', $l['name'], $landmarks, $seed . ':landmark', $l['fact'], $l['source_url']);
            $last['image'] = SND_Data::image_url($l['image']);
            $last['image_source'] = $l['source_url'];
            $last['credit'] = $l['credit']; $last['license'] = $l['license'];
            $q[] = $last;
        } else {
            $q[]=self::nearby_question($target,$pool,$seed,'Zamensko geografsko pitanje: fotografija znamenitosti nije dostupna u bazi.');
        }
        $flag = SND_Flags::question($target, $seed, (bool)SND_Settings::get('flag_fallback'));
        if(!$flag){$flag=self::distance_question($target,$pool,$seed.':flag-replacement','Zamensko geografsko pitanje: zastava ovog mesta još nije potvrđena u bazi.');}
        array_splice($q, 2, 0, array($flag));
        return $q;
    }

    public static function challenge($kind, $mode) {
        $data = SND_Data::get(); $pool = SND_Data::pool($kind); $districts = SND_Data::pool('district');$targets=SND_Kinds::is_explore($kind)?SND_Explore::targets($kind):$pool;
        if (count($targets) < 4 || count($districts) < 4) { return new WP_Error('snd_empty', 'Nema dovoljno aktivnih teritorija. Obratite se administratoru.', array('status' => 503)); }
        $date = self::date(); $key = 'snd_day_v'.self::RULESET.'_' . str_replace('-', '', $date) . '_' . $kind;
        if ($mode === 'daily') { $saved = get_option($key); if ($saved) { return $saved; } }
        $lock=$mode==='daily'?'snd_challenge_lock_'.$key:'';$lease=$lock?SND_Lock::acquire($lock):true;
        if(!$lease){return new WP_Error('snd_busy','Dnevni izazov se priprema. Pokušaj ponovo.',array('status'=>409));}
        try {
        if($mode==='daily'){$saved=get_option($key);if($saved){return $saved;}}
        $days = (int) (new DateTimeImmutable('2026-01-01'))->diff(new DateTimeImmutable($date))->format('%r%a');
        $cycle = (int) floor($days / count($targets));
        $order = self::ordered($targets, $kind . ':' . $cycle);
        $target = $mode === 'daily' ? $order[(($days % count($targets)) + count($targets)) % count($targets)] : $order[random_int(0, count($targets) - 1)];
        $seed = $mode === 'daily' ? $date . ':' . $kind : bin2hex(random_bytes(16));
        $catalog = array();
        foreach ($pool as $t) { $catalog[$t['id']] = array_intersect_key($t, array_flip(array('id', 'kind', 'name', 'center', 'aliases', 'map_path','point','labels','display_name','district_name'))); }
        $challenge = array('date' => $date, 'kind' => $kind, 'mode' => $mode, 'ruleset' => self::RULESET, 'storage_key' => $key, 'number' => max(1, $days + 1), 'target' => $target, 'catalog' => $catalog, 'revision' => SND_Kinds::is_explore($kind)?SND_Explore::revision():$data['revision'], 'questions' => SND_Kinds::is_explore($kind)?SND_Explore::questions($target,$pool,$seed):self::questions($target, $pool, $districts, $seed));
        $challenge['scoring']=SND_Scoring::rules();
        $challenge['options']=SND_Settings::game_options();$slots=array('population','administration','flag','landmark');$selected=array();
        foreach($challenge['questions'] as $i=>$question){if(SND_Kinds::is_explore($kind)?in_array($i,SND_Settings::get('explore_rounds',array(0,1,2,3)),true):in_array($slots[$i],$challenge['options']['rounds'],true)){$selected[]=$question;}}$challenge['questions']=$selected;
        if ($mode === 'daily') { add_option($key, $challenge, '', false); return get_option($key); }
        return $challenge;
        } finally {if($lock){SND_Lock::release($lock,$lease);}}
    }

    public static function create($kind, $mode) {
        $c = self::challenge($kind, $mode); if (is_wp_error($c)) { return $c; }
        $token = bin2hex(random_bytes(24));
        $state = array('challenge' => $c, 'stage' => 'guess', 'guesses' => array(), 'hint' => false, 'solved' => false, 'answers' => array(), 'question_index' => 0, 'revision' => 0, 'owner' => get_current_user_id(), 'game_id' => bin2hex(random_bytes(16)), 'recorded' => false,'started_at'=>time(),'activity_log'=>array(array('at'=>gmdate('c'),'action'=>'start')));
        $state['privacy_epoch']=get_current_user_id()?get_user_meta(get_current_user_id(),'snd_privacy_epoch',true):'';
        $state['scoring']=SND_Scoring::current_hint_policy(SND_Scoring::for_challenge($c));
        // Fresh sessions can restore a real flag round from an older cached day.
        // Already started sessions keep their questions and answer identifiers.
        $slots=$c['options']['rounds']??array('population','administration','flag','landmark');$flag_index=array_search('flag',$slots,true);
        if(!SND_Kinds::is_explore($kind) && $flag_index!==false && SND_Settings::get('flag_fallback') && isset($c['questions'][$flag_index]) && $c['questions'][$flag_index]['type']!=='flag'){
            $flag=SND_Flags::question($c['target'],$c['date'].':'.$c['kind'].':restored-flag',true);if($flag){$state['question_overrides'][$flag_index]=$flag;}
        }
        // New sessions use the reviewed church photo even if today's target is cached.
        // Existing sessions keep their original questions and answer identifiers.
        if(in_array($c['target']['id'],array('rs-00','m-beograd'),true) && ($c['target']['landmark']['name']??'')==='Beogradska tvrđava'){
            $current=SND_Data::get()['territories'][$c['target']['id']]??null;
            if(($current['landmark']['name']??'')==='Hram Svetog Save'){
                $questions=self::questions($current,SND_Data::pool($kind),SND_Data::pool('district'),$c['date'].':'.$kind.':church-425');
                foreach($c['questions'] as $i=>$question){
                    if($question['type']==='landmark' && strpos($question['image_source']??'','Belgrade_Fortress_Kalemegdan-9878')!==false){$state['question_overrides'][$i]=$questions[3];}
                }
            }
        }
        $state['rank_eligible']=SND_Ranking::reserve($state);
        self::persist($token, $state);
        SND_Progress::remember(get_current_user_id(), $kind, $mode, $token);
        return array('token' => $token, 'state' => self::public_state($state));
    }

    public static function persist($token, $state) {
        SND_Analytics::capture($state);
        if ($state['challenge']['mode'] === 'daily') {
            $state['challenge_key'] = $state['challenge']['storage_key'] ?? ('snd_day_' . str_replace('-', '', $state['challenge']['date']) . '_' . $state['challenge']['kind']);
            unset($state['challenge']);
        }
        set_transient('snd_session_' . $token, $state, (!empty($state['owner']) ? 30 : 3) * DAY_IN_SECONDS);
    }

    public static function load($token) {
        if (!is_string($token) || !preg_match('/^[a-f0-9]{48}$/D', $token)) { return new WP_Error('snd_token', 'Partija nije pronađena. Pokreni novu.', array('status' => 404)); }
        $s = get_transient('snd_session_' . $token);
        if (!$s) { return new WP_Error('snd_expired', 'Sačuvana partija je istekla. Pokreni novu.', array('status' => 410)); }
        if (!empty($s['owner']) && (int) $s['owner'] !== get_current_user_id()) { return new WP_Error('snd_owner', 'Ova partija pripada drugom nalogu.', array('status' => 403)); }
        if(!empty($s['owner']) && (($s['privacy_epoch']??'')!==get_user_meta($s['owner'],'snd_privacy_epoch',true))){return new WP_Error('snd_expired','Sačuvana partija je istekla. Pokreni novu.',array('status'=>410));}
        if (!isset($s['challenge']) && isset($s['challenge_key'])) { $s['challenge'] = get_option($s['challenge_key']); }
        if (empty($s['challenge'])) { return new WP_Error('snd_expired', 'Podaci ove partije više nisu dostupni. Pokreni novu.', array('status' => 410)); }
        // Pending guesses adopt the requested split cost; completed scores keep their snapshot.
        if($s['stage']==='guess' && !empty($s['scoring'])){$s['scoring']=SND_Scoring::current_hint_policy($s['scoring']);}
        if ($s['challenge']['mode'] === 'daily' && $s['challenge']['date'] !== self::date()) { return new WP_Error('snd_new_day', 'Stigao je novi dnevni izazov. Pokreni današnju partiju.', array('status' => 410)); }
        foreach($s['challenge']['questions'] as $i=>$q){if(!isset($s['answers'][$i]) && ($q['type']??'')==='explore_city_river' && !isset($s['question_overrides'][$i])){$s['question_overrides'][$i]=SND_Explore::safe_decoys($q,$s['challenge']['date'].':'.$i);}}
        return $s;
    }

    public static function act(&$s, $action, $value) {
        $c = $s['challenge'];$options=SND_Settings::options_for($c);$before_index=$s['question_index'];
        if ($action === 'guess' && $s['stage'] === 'guess') {
            if(SND_Kinds::is_explore($c['kind']) && is_string($value) && !SND_Explore::approved_id($value)){return new WP_Error('snd_guess','Izaberi naziv iz proverenog spiska.',array('status'=>400));}
            if (!is_string($value) || !isset($c['catalog'][$value])) { return new WP_Error('snd_guess', 'Izaberi teritoriju iz ponuđene liste.', array('status' => 400)); }
            foreach ($s['guesses'] as $guess) { if ($guess['id'] === $value) { return new WP_Error('snd_duplicate', 'Ovu teritoriju si već pokušao/la.', array('status' => 400)); } }
            $from = $c['catalog'][$value]; $correct = $value === $c['target']['id'];
            $s['guesses'][] = array('id' => $value, 'name' => $from['name'], 'km' => (int) round(self::distance($from['center'], $c['target']['center'])), 'direction' => self::direction($from['center'], $c['target']['center']), 'correct' => $correct);
            if ($correct || count($s['guesses']) >= $options['max_guesses']) { $s['stage'] = 'reveal'; $s['solved'] = $correct; }
        } elseif ($action === 'hint' && $s['stage'] === 'guess' && $options['hint_enabled'] && count($s['guesses']) >= $options['hint_after'] && SND_Hints::level($s)<2) {
            $s['hint_level']=SND_Hints::level($s)+1;$s['hint'] = true;
        } elseif ($action === 'giveup' && $s['stage'] === 'guess') {
            $s['stage'] = 'reveal';
        } elseif ($action === 'next' && $s['stage'] === 'reveal') {
            $s['stage'] = $c['questions']?'quiz':'complete';
        } elseif ($action==='source' && $s['stage']==='quiz' && !isset($s['answers'][$s['question_index']])) {
            if(!$options['source_help_enabled']){return new WP_Error('snd_help_disabled','Ova pomoć je isključena u podešavanjima igre.',array('status'=>403));}
            $q=self::question_for($s,$s['question_index']);
            if(($q['type']!=='explore_photo' && empty($q['image'])) || empty($q['image_source'])){return new WP_Error('snd_source','Izvor slike sada nije dostupan.',array('status'=>409));}
            $s['source_help']=true;$s['source_help_questions'][$s['question_index']]=true;
        } elseif ($action==='media_unavailable' && $s['stage']==='quiz' && !isset($s['answers'][$s['question_index']])) {
            if(!$options['media_fallback']){return new WP_Error('snd_fallback_disabled','Zamensko pitanje je isključeno u podešavanjima igre.',array('status'=>403));}
            $q=self::question_for($s,$s['question_index']);
            if(empty($q['image']) && !in_array($q['type'],array('flag','explore_photo'),true)){return new WP_Error('snd_media','Ovo pitanje ne koristi slike.',array('status'=>409));}
            $target=$c['target'];$pool=SND_Data::pool($c['kind']);
            $s['question_overrides'][$s['question_index']]=SND_Kinds::is_explore($c['kind'])?SND_Explore::questions($target,$pool,$c['date'].':media:'.$s['question_index'])[0]:self::distance_question($target,$pool,$c['date'].':'.$target['id'].':media:'.$s['question_index'],'Zamensko geografsko pitanje: slika nije mogla da se učita. Prethodni pokušaji nisu potrošeni.');
            $s['technical_replacements'][$s['question_index']]=true;
        } elseif (($action === 'answer' || $action === 'skip') && $s['stage'] === 'quiz' && !isset($s['answers'][$s['question_index']])) {
            $q = self::question_for($s,$s['question_index']);
            if($q!==$c['questions'][$s['question_index']]){$s['question_overrides'][$s['question_index']]=$q;}
            if ($action === 'answer' && !in_array($value, array_column($q['options'], 'id'), true)) { return new WP_Error('snd_choice', 'Izaberi jedan ponuđeni odgovor.', array('status' => 400)); }
            $s['answers'][$s['question_index']] = array('choice' => $action === 'skip' ? null : $value, 'correct' => $action === 'answer' && $value === $q['correct'], 'skipped' => $action === 'skip');
        } elseif ($action === 'next' && $s['stage'] === 'quiz' && isset($s['answers'][$s['question_index']])) {
            $s['question_index']++;
            if ($s['question_index'] >= count($c['questions'])) { $s['stage'] = 'complete'; }
        } elseif ($action === 'finish' && in_array($s['stage'], array('reveal', 'quiz'), true)) {
            foreach ($c['questions'] as $i => $q) { if (!isset($s['answers'][$i])) { $s['answers'][$i] = array('choice' => null, 'correct' => false, 'skipped' => true); } }
            $s['stage'] = 'complete';
        } else { return new WP_Error('snd_action', 'Ovaj potez sada nije dostupan. Osveži prikaz partije.', array('status' => 409)); }
        $s['activity_log'][]=array('at'=>gmdate('c'),'action'=>$action,'stage'=>$s['stage'],'question'=>$before_index+1,'value'=>in_array($action,array('guess','answer'),true)?$value:null);
        $s['activity_log']=array_slice($s['activity_log'],-100);
        if($s['stage']==='complete' && empty($s['completed_at'])){$s['completed_at']=time();}
        $s['revision']++;
        return true;
    }

    public static function public_state($s) {
        $c = $s['challenge'];$options=SND_Settings::options_for($c);
        $out = array_intersect_key($s, array_flip(array('stage', 'guesses', 'hint', 'solved', 'question_index', 'revision', 'source_help')));
        $out += array('date' => $c['date'], 'number' => $c['number'], 'kind' => $c['kind'], 'mode' => $c['mode'], 'shape' => $c['target']['path'], 'max_guesses' => $options['max_guesses'],'hint_after'=>$options['hint_after'],'hint_enabled'=>$options['hint_enabled'],'source_help_enabled'=>$options['source_help_enabled'],'media_fallback'=>$options['media_fallback'], 'question_count' => count($c['questions']));
        if(SND_Kinds::is_explore($c['kind'])){$out['explore_map']=SND_Explore::map_state($s);}
        $public_catalog=$c['catalog'];if(SND_Kinds::is_explore($c['kind'])){$public_catalog=array_filter($public_catalog,function($t){return SND_Explore::approved_id($t['id']);});}
        if($s['stage']==='guess'){$out['catalog'] = array_map(function ($t) { return array_intersect_key($t, array_flip(array('id', 'name', 'aliases'))); }, array_values($public_catalog));}
        $out['hint_level']=SND_Hints::level($s);
        $out['hint_costs']=SND_Scoring::hint_prices($s);$out['hint_spent']=SND_Scoring::hint_spent($s);
        if ($s['stage'] !== 'guess') {
            $out['territory'] = array_intersect_key($c['target'], array_flip(array('id', 'name', 'region', 'map_path')));
            if(in_array($s['stage'],array('reveal','complete'),true)){$out['map'] = array_map(function ($t) { return array_intersect_key($t, array_flip(array('id', 'name', 'map_path','point'))); }, array_values($public_catalog));}
        }
        if ($s['stage'] === 'quiz') {
            $i = $s['question_index']; $q = SND_I18n::question(self::question_for($s,$i),$c['target']);
            if(!isset($s['answers'][$i])){
                unset($q['correct'],$q['correct_label'],$q['explanation'],$q['source'],$q['sources'],$q['credits']);
                if(empty($s['source_help_questions'][$i])){unset($q['image_source']);}
            }
            $q['source_help_used']=!empty($s['source_help_questions'][$i]);
            if(isset($s['answers'][$i])){$q['answer']=$s['answers'][$i];}
            if($q['type']==='explore_photo' && !isset($s['answers'][$i]) && empty($s['source_help_questions'][$i])){foreach($q['attribution'] as &$credit){unset($credit['source']);}unset($credit);}
            $out['question'] = $q;
        }
        $out['score'] = count(array_filter($s['answers'], function ($a) { return $a['correct']; }));
        $out['scoring_rules']=$s['scoring']??null;
        $out['rank_eligible']=!empty($s['rank_eligible']);
        if($s['stage']==='complete'){$out['points']=SND_Scoring::calculate($s);}
        if ($s['stage'] === 'complete') {
            $out['review'] = array();
            foreach($c['questions'] as $i=>$unused){
                $q=SND_I18n::question(self::question_for($s,$i),$c['target']);$answer=$s['answers'][$i]??array('correct'=>false,'skipped'=>true,'choice'=>null);
                $correct=array();$chosen=array();
                foreach($q['options'] as $o){if($o['id']===$q['correct']){$correct=$o;}if($o['id']===($answer['choice']??null)){$chosen=$o;}}
                $out['review'][]=array('title'=>$q['title'],'type'=>$q['type'],'correct_label'=>$q['correct_label']??($correct['label']??''),'correct_image'=>$correct['image']??($q['image']??''),'choice_label'=>$chosen['label']??'','choice_image'=>$chosen['image']??'','explanation'=>$q['explanation'],'source'=>$q['source'],'sources'=>$q['sources']??array(),'credits'=>$q['credits']??($q['attribution']??array()),'credit'=>$q['credit']??'','license'=>$q['license']??'','image_source'=>$q['image_source']??'','answer'=>$answer,'source_help_used'=>!empty($s['source_help_questions'][$i]),'technical_replacement'=>!empty($s['technical_replacements'][$i]));
            }
        }
        foreach($out['guesses'] as &$guess){$t=$c['catalog'][$guess['id']]??null;if($t){$guess['name']=SND_I18n::territory_name($t);}$guess['direction']['name']=SND_I18n::direction($guess['direction']['name']);}unset($guess);
        if(isset($out['catalog'])){foreach($out['catalog'] as &$entry){$original=$entry['name'];$t=$c['catalog'][$entry['id']];$entry['name']=SND_I18n::territory_name($t);$aliases=$entry['aliases']??array();$aliases[]=$original;foreach(array('sr','en','de','ru') as $language){$aliases[]=SND_I18n::t($original,array(),$language);}if($original==='Beograd'){$aliases=array_merge($aliases,array('Belgrade','Belgrad','Белград'));}$entry['aliases']=array_values(array_unique($aliases));}unset($entry);}
        if($c['kind']==='river' && !empty($out['catalog'])){
            $names=array_count_values(array_column($out['catalog'],'name'));
            foreach($out['catalog'] as &$entry){
                if($names[$entry['name']]>1){$entry['location']=SND_I18n::text($c['catalog'][$entry['id']]['district_name']??'');}
            }
            unset($entry);
        }
        if(isset($out['territory'])){$out['territory']['name']=SND_I18n::territory_name($c['target']);}
        if(isset($out['map'])){foreach($out['map'] as &$entry){$entry['name']=SND_I18n::territory_name($c['catalog'][$entry['id']]);}unset($entry);}
        if($s['hint']){$out['name_hint']=SND_Hints::describe($s);$out['hint_text']=SND_I18n::t('Počinje slovom {letter}.',array('letter'=>$out['name_hint']['first']));}
        return $out;
    }

    public static function cleanup() {
        global $wpdb;
        $threshold = (new DateTimeImmutable(self::date()))->modify('-14 days')->format('Ymd');
        $names = $wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like('snd_day_') . '%'));
        foreach ($names as $name) { if (preg_match('/^snd_day_(?:v[0-9]+_)?([0-9]{8})_/', $name, $m) && $m[1] < $threshold) { delete_option($name); } }
    }
}
