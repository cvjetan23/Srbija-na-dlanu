<?php
defined('ABSPATH') || exit;

final class SND_Text {
    public static function days($n) {
        $n=max(0,(int)$n);$a=abs($n);return $n.(($a%10===1 && $a%100!==11)?' dan':' dana');
    }
    public static function key($text) {
        $map = array('А'=>'a','Б'=>'b','В'=>'v','Г'=>'g','Д'=>'d','Ђ'=>'dj','Е'=>'e','Ж'=>'z','З'=>'z','И'=>'i','Ј'=>'j','К'=>'k','Л'=>'l','Љ'=>'lj','М'=>'m','Н'=>'n','Њ'=>'nj','О'=>'o','П'=>'p','Р'=>'r','С'=>'s','Т'=>'t','Ћ'=>'c','У'=>'u','Ф'=>'f','Х'=>'h','Ц'=>'c','Ч'=>'c','Џ'=>'dz','Ш'=>'s','а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','ђ'=>'dj','е'=>'e','ж'=>'z','з'=>'z','и'=>'i','ј'=>'j','к'=>'k','л'=>'l','љ'=>'lj','м'=>'m','н'=>'n','њ'=>'nj','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','ћ'=>'c','у'=>'u','ф'=>'f','х'=>'h','ц'=>'c','ч'=>'c','џ'=>'dz','ш'=>'s','Đ'=>'Dj','đ'=>'dj');
        return trim(preg_replace('/[^a-z0-9]+/', '-', strtolower(remove_accents(strtr((string) $text, $map)))) , '-');
    }
}
