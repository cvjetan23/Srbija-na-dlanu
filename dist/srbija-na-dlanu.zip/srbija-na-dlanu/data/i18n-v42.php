<?php
defined('ABSPATH') || exit;
return json_decode(<<<'SND_V42_LANGUAGES'
{
  "Igra dana": {
    "en": "Today's game",
    "de": "Tagesaufgabe",
    "ru": "Игра дня"
  },
  "Dnevni izazov": {
    "en": "Today's game",
    "de": "Tagesaufgabe",
    "ru": "Игра дня",
    "sr": "Igra dana"
  },
  "Današnji izazov": {
    "en": "Today's game",
    "de": "Tagesaufgabe",
    "ru": "Игра дня",
    "sr": "Igra dana"
  },
  "Nastavi današnji izazov": {
    "en": "Continue today's game",
    "de": "Tagesaufgabe fortsetzen",
    "ru": "Продолжить игру дня"
  },
  "Tvoje geografsko putovanje": {
    "en": "Your geography journey",
    "de": "Deine geografische Reise",
    "ru": "Твоё географическое путешествие"
  },
  "Sačuvaj svoje rezultate": {
    "en": "Save your results",
    "de": "Speichere deine Ergebnisse",
    "ru": "Сохрани свои результаты"
  },
  "Nastavi započete igre i prati svoj napredak.": {
    "en": "Resume your games and follow your progress.",
    "de": "Setze begonnene Spiele fort und verfolge deinen Fortschritt.",
    "ru": "Продолжай начатые игры и следи за успехами."
  },
  "Prijavi se, nastavi igru na drugom uređaju i pronađi se na rang listi.": {
    "en": "Sign in, continue on another device and find your place on the leaderboard.",
    "de": "Melde dich an, spiele auf einem anderen Gerät weiter und finde deinen Platz in der Rangliste.",
    "ru": "Войди, продолжи игру на другом устройстве и найди себя в рейтинге."
  },
  "Pomoć za naziv": {
    "en": "Name hints",
    "de": "Hinweise zum Namen",
    "ru": "Подсказки к названию"
  },
  "Počinje slovom {letter}.": {
    "en": "Starts with {letter}.",
    "de": "Beginnt mit {letter}.",
    "ru": "Начинается с {letter}."
  },
  "Broj slova: {count}": {
    "en": "Letters: {count}",
    "de": "Buchstaben: {count}",
    "ru": "Букв: {count}"
  },
  "Otkrij prvo slovo": {
    "en": "Reveal the first letter",
    "de": "Ersten Buchstaben anzeigen",
    "ru": "Открыть первую букву"
  },
  "Prikaži polja za slova": {
    "en": "Show letter slots",
    "de": "Buchstabenfelder anzeigen",
    "ru": "Показать поля для букв"
  },
  "Želiš još igre? Vežbanje ne utiče na rang listu.": {
    "en": "Want to keep playing? Practice does not affect your ranking.",
    "de": "Noch eine Runde? Üben beeinflusst die Rangliste nicht.",
    "ru": "Хочешь ещё? Тренировка не влияет на рейтинг."
  },
  "Vežbaj bez ograničenja": {
    "en": "Practice without limits",
    "de": "Unbegrenzt üben",
    "ru": "Тренировка без ограничений"
  },
  "Za plasman odigraj igru dana.": {
    "en": "Play today's game to enter the leaderboard.",
    "de": "Spiele die Tagesaufgabe für die Rangliste.",
    "ru": "Для рейтинга сыграй в игру дня."
  },
  "Vrati se na igru dana": {
    "en": "Back to today's game",
    "de": "Zurück zur Tagesaufgabe",
    "ru": "Вернуться к игре дня"
  },
  "Prijavi se da sačuvaš rezultat na rang listi.": {
    "en": "Sign in to save your leaderboard result.",
    "de": "Melde dich an, um dein Ergebnis für die Rangliste zu speichern.",
    "ru": "Войди, чтобы сохранить результат в рейтинге."
  },
  "Pomoći za naziv ukupno oduzimaju {hint} poena. Pitanje uz pomoć izvora ne donosi poene.": {
    "en": "Name hints cost {hint} points in total. An answer revealed by its source earns no question points.",
    "de": "Die Namenshinweise kosten insgesamt {hint} Punkte. Eine mit Quellenhilfe gelöste Frage bringt keine Punkte.",
    "ru": "Подсказки к названию отнимают всего {hint} очков. Ответ с помощью источника не приносит очков за вопрос."
  },
  "Prijavom poveži dnevnu partiju sa nalogom i sačuvaj plasman.": {
    "en": "Sign in to link your daily game to your account and save your ranking.",
    "de": "Melde dich an, um die Tagespartie mit deinem Konto zu verbinden und die Platzierung zu speichern.",
    "ru": "Войди, чтобы связать игру дня с аккаунтом и сохранить место в рейтинге."
  },
  "Igra dana #{number}": {
    "en": "Today's game #{number}",
    "de": "Tagesaufgabe Nr. {number}",
    "ru": "Игра дня №{number}"
  },
  "Igra dana je ista za sve. Vežbanje možeš igrati koliko želiš.": {
    "en": "Today's game is the same for everyone. Practice as often as you like.",
    "de": "Die Tagesaufgabe ist für alle gleich. Üben kannst du beliebig oft.",
    "ru": "Игра дня одинакова для всех. Тренироваться можно сколько угодно."
  },
  "Prva pomoć otkriva prvo slovo. Druga prikazuje broj slova i prazna polja.": {
    "en": "The first hint reveals the first letter. The second shows the letter count and empty slots.",
    "de": "Der erste Hinweis zeigt den Anfangsbuchstaben. Der zweite zeigt die Anzahl und leere Buchstabenfelder.",
    "ru": "Первая подсказка открывает начальную букву. Вторая показывает число букв и пустые поля."
  },
  "Ilustracija Srbije sa okruzima, rekama i planinama": {
    "en": "Illustration of Serbia with districts, rivers and mountains",
    "de": "Illustration Serbiens mit Bezirken, Flüssen und Bergen",
    "ru": "Иллюстрация Сербии с округами, реками и горами"
  },
  "Istraži i nauči": {
    "en": "Explore and learn",
    "de": "Entdecken und lernen",
    "ru": "Исследуй и узнавай"
  },
  "Istraži okruge, gradove, reke i planine. Pronađi zanimljivosti, upoznaj mesta i spremi se za sledeću igru.": {
    "en": "Explore districts, towns, rivers and mountains. Discover interesting facts and get ready for your next game.",
    "de": "Erkunde Bezirke, Städte, Flüsse und Berge. Entdecke Wissenswertes und bereite dich auf das nächste Spiel vor.",
    "ru": "Исследуй округа, города, реки и горы. Узнавай интересные факты и готовься к следующей игре."
  },
  "Tvoje mesto na mapi": {
    "en": "Your place on the map",
    "de": "Dein Platz auf der Karte",
    "ru": "Твоё место на карте"
  },
  "Nastavi svoje putovanje": {
    "en": "Continue your journey",
    "de": "Setze deine Reise fort",
    "ru": "Продолжи своё путешествие"
  },
  "Sačuvaj svoj napredak": {
    "en": "Keep your progress",
    "de": "Speichere deinen Fortschritt",
    "ru": "Сохрани свой прогресс"
  },
  "Sve tvoje partije i rezultati na jednom mestu.": {
    "en": "All your games and results in one place.",
    "de": "Alle deine Spiele und Ergebnisse an einem Ort.",
    "ru": "Все твои игры и результаты в одном месте."
  },
  "Jedan nalog za sve tvoje geografske izazove.": {
    "en": "One account for all your geography games.",
    "de": "Ein Konto für alle deine Geografiespiele.",
    "ru": "Один аккаунт для всех географических игр."
  },
  "Nastavi na drugom uređaju": {
    "en": "Continue on another device",
    "de": "Auf einem anderen Gerät weiterspielen",
    "ru": "Продолжай на другом устройстве"
  },
  "Sačuvaj rezultate": {
    "en": "Save your results",
    "de": "Ergebnisse speichern",
    "ru": "Сохраняй результаты"
  },
  "Prati plasman": {
    "en": "Follow your ranking",
    "de": "Platzierung verfolgen",
    "ru": "Следи за рейтингом"
  },
  "Fotografija: autor i licenca": {
    "en": "Photo: author and licence",
    "de": "Foto: Urheber und Lizenz",
    "ru": "Фото: автор и лицензия"
  },
  "Pomoći za naziv ukupno oduzimaju {hint} poena.": {
    "en": "Name hints cost {hint} points in total.",
    "de": "Die Namenshinweise kosten insgesamt {hint} Punkte.",
    "ru": "Подсказки к названию отнимают всего {hint} очков."
  },
  "Spisak sadrži potvrđene nazive sa osnovnim podacima.": {
    "en": "This list contains verified entries with essential facts.",
    "de": "Die Liste enthält bestätigte Einträge mit grundlegenden Angaben.",
    "ru": "В списке — подтверждённые объекты с основными сведениями."
  },
  "Pomoći iskorišćene": {
    "en": "Hints used",
    "de": "Hinweise genutzt",
    "ru": "Подсказки использованы"
  },
  "Pomoć · −{points}": {
    "en": "Hint · −{points}",
    "de": "Hilfe · −{points}",
    "ru": "Подсказка · −{points}"
  },
  "Prvo slovo · −{points}": {
    "en": "First letter · −{points}",
    "de": "Anfangsbuchstabe · −{points}",
    "ru": "Первая буква · −{points}"
  },
  "Broj slova · −{points}": {
    "en": "Letter count · −{points}",
    "de": "Buchstaben · −{points}",
    "ru": "Число букв · −{points}"
  },
  "Pomoć trenutno nije dostupna.": {
    "en": "Hints are currently unavailable.",
    "de": "Hinweise sind derzeit nicht verfügbar.",
    "ru": "Подсказки сейчас недоступны."
  },
  "Pomoć se otključava posle {count}. pokušaja.": {
    "en": "Hints unlock after attempt {count}.",
    "de": "Hinweise werden nach Versuch {count} freigeschaltet.",
    "ru": "Подсказки доступны после попытки № {count}."
  },
  "Pomoći: −{points} poena.": {
    "en": "Hints: −{points} points.",
    "de": "Hinweise: −{points} Punkte.",
    "ru": "Подсказки: −{points} очков."
  },
  "Prva pomoć oduzima {first}, a druga još {second} poena.": {
    "en": "The first hint costs {first} points and the second another {second}.",
    "de": "Der erste Hinweis kostet {first} Punkte, der zweite weitere {second}.",
    "ru": "Первая подсказка стоит {first} очков, вторая — ещё {second}."
  },
  "Meni": {
    "en": "Menu",
    "de": "Menü",
    "ru": "Меню"
  },
  "Otvori meni": {
    "en": "Open menu",
    "de": "Menü öffnen",
    "ru": "Открыть меню"
  },
  "Zatvori meni": {
    "en": "Close menu",
    "de": "Menü schließen",
    "ru": "Закрыть меню"
  },
  "Pomoći 2/2": {
    "en": "Hints 2/2",
    "de": "Hilfen 2/2",
    "ru": "Подсказки 2/2"
  },
  "Sledeće pitanje": {
    "en": "Next question",
    "de": "Nächste Frage",
    "ru": "Следующий вопрос"
  },
  "Vidi rezultat": {
    "en": "View result",
    "de": "Ergebnis ansehen",
    "ru": "Посмотреть результат"
  },
  "Pitanje {number}/{total}": {
    "en": "Question {number}/{total}",
    "de": "Frage {number}/{total}",
    "ru": "Вопрос {number}/{total}"
  },
  "Mapa i pokušaji": {
    "en": "Map and guesses",
    "de": "Karte und Versuche",
    "ru": "Карта и попытки"
  },
  "Koji je ovo okrug?": {
    "en": "Which district is this?",
    "de": "Welcher Bezirk ist das?",
    "ru": "Какой это округ?"
  },
  "Koja je ovo opština?": {
    "en": "Which municipality is this?",
    "de": "Welche Gemeinde ist das?",
    "ru": "Какая это община?"
  },
  "Naziv opštine": {
    "en": "Municipality name",
    "de": "Name der Gemeinde",
    "ru": "Название общины"
  },
  "Unesi opštinu…": {
    "en": "Enter a municipality…",
    "de": "Gemeinde eingeben…",
    "ru": "Введите название общины…"
  },
  "Prepoznaj opštinu po obrisu.": {
    "en": "Identify the municipality by its outline.",
    "de": "Erkenne die Gemeinde an ihrem Umriss.",
    "ru": "Угадай общину по контуру."
  },
  "Opštine: {name}": {
    "en": "Municipalities: {name}",
    "de": "Gemeinden: {name}",
    "ru": "Общины: {name}"
  },
  "Prema popisu iz {year}. godine, teritorija ima {population} stanovnika.": {
    "en": "According to the {year} census, the area has {population} residents.",
    "de": "Laut der Volkszählung von {year} hat das Gebiet {population} Einwohner.",
    "ru": "По переписи {year} года на этой территории живёт {population} человек."
  },
  "Smer od centra teritorije „{name}“ ka centru teritorije „{anchor}“: {direction}.": {
    "en": "Direction from the center of “{name}” to the center of “{anchor}”: {direction}.",
    "de": "Richtung vom Zentrum von „{name}“ zum Zentrum von „{anchor}“: {direction}.",
    "ru": "Направление от центра территории «{name}» к центру территории «{anchor}»: {direction}."
  },
  "Upravni okrug teritorije „{name}“ je „{district}“.": {
    "en": "The administrative district of “{name}” is “{district}”.",
    "de": "Das Gebiet „{name}“ gehört zum Verwaltungsbezirk „{district}“.",
    "ru": "Территория «{name}» относится к округу «{district}»."
  },
  "Prema prikazanoj podeli, opština „{member}“ pripada okrugu „{name}“.": {
    "en": "In the division shown, the municipality of “{member}” belongs to “{name}”.",
    "de": "In der dargestellten Gliederung gehört die Gemeinde „{member}“ zum Bezirk „{name}“.",
    "ru": "По показанному делению община «{member}» входит в округ «{name}»."
  },
  "Kojem gradu pripada ova gradska opština?": {
    "en": "Which city does this urban municipality belong to?",
    "de": "Zu welcher Stadt gehört diese Stadtgemeinde?",
    "ru": "К какому городу относится эта городская община?"
  },
  "Grad kojem pripada opština „{name}“ je „{city}“.": {
    "en": "The municipality of “{name}” belongs to the city of “{city}”.",
    "de": "Die Gemeinde „{name}“ gehört zur Stadt „{city}“.",
    "ru": "Община «{name}» относится к городу «{city}»."
  },
  "Na sastavu kojih reka se nalazi Beograd?": {
    "en": "Which two rivers meet in Belgrade?",
    "de": "Welche beiden Flüsse treffen in Belgrad zusammen?",
    "ru": "Какие две реки сливаются в Белграде?"
  },
  "Zastava mesta „{place}“": {
    "en": "Flag of “{place}”",
    "de": "Flagge von „{place}“",
    "ru": "Флаг «{place}»"
  },
  "Prikazana je zastava mesta „{place}“.": {
    "en": "This is the flag of “{place}”.",
    "de": "Hier ist die Flagge von „{place}“ zu sehen.",
    "ru": "На изображении флаг «{place}»."
  },
  "Udaljenost između centara je približno {km} km vazdušnom linijom.": {
    "en": "The centers are about {km} km apart in a straight line.",
    "de": "Die Zentren liegen etwa {km} km Luftlinie auseinander.",
    "ru": "Расстояние между центрами по прямой составляет около {km} км."
  },
  "Čiji je centar najbliži centru teritorije „{name}“?": {
    "en": "Which of these areas has its center closest to the center of “{name}”?",
    "de": "Welches dieser Gebiete hat sein Zentrum am nächsten beim Zentrum von „{name}“?",
    "ru": "Центр какой из этих территорий ближе всего к центру «{name}»?"
  },
  "Najbliži je centar teritorije „{nearby}“, udaljen približno {km} km vazdušnom linijom.": {
    "en": "The closest center is in “{nearby}”, about {km} km away in a straight line.",
    "de": "Am nächsten liegt das Zentrum von „{nearby}“, etwa {km} km Luftlinie entfernt.",
    "ru": "Ближе всего центр территории «{nearby}», примерно в {km} км по прямой."
  },
  "Kojoj administrativnoj celini pripada ovo naselje?": {
    "en": "Which administrative area does this settlement belong to?",
    "de": "Zu welchem Verwaltungsgebiet gehört dieser Ort?",
    "ru": "К какой административной единице относится этот населённый пункт?"
  },
  "Administrativna celina naselja „{name}“: {answer}.": {
    "en": "Administrative area of “{name}”: {answer}.",
    "de": "Verwaltungsgebiet des Ortes „{name}“: {answer}.",
    "ru": "Административная единица населённого пункта «{name}»: {answer}."
  },
  "Prema popisu iz {year}. godine, naselje ima {value} stanovnika.": {
    "en": "According to the {year} census, the settlement has {value} residents.",
    "de": "Laut der Volkszählung von {year} hat der Ort {value} Einwohner.",
    "ru": "По переписи {year} года в населённом пункте живёт {value} человек."
  },
  "U kom smeru je planina „{anchor}“ od vrha planine „{name}“?": {
    "en": "In which direction is “{anchor}” from the peak of “{name}”?",
    "de": "In welcher Richtung liegt „{anchor}“ vom Gipfel von „{name}“ aus?",
    "ru": "В каком направлении от вершины «{name}» находится гора «{anchor}»?"
  },
  "Smer od vrha planine „{name}“ ka planini „{anchor}“: {answer}.": {
    "en": "Direction from the peak of “{name}” to “{anchor}”: {answer}.",
    "de": "Richtung vom Gipfel von „{name}“ nach „{anchor}“: {answer}.",
    "ru": "Направление от вершины «{name}» к горе «{anchor}»: {answer}."
  },
  "U kom smeru je naselje „{anchor}“ od naselja „{name}“?": {
    "en": "In which direction is “{anchor}” from “{name}”?",
    "de": "In welcher Richtung liegt der Ort „{anchor}“ vom Ort „{name}“ aus?",
    "ru": "В каком направлении от населённого пункта «{name}» находится «{anchor}»?"
  },
  "Smer od naselja „{name}“ ka naselju „{anchor}“: {answer}.": {
    "en": "Direction from “{name}” to “{anchor}”: {answer}.",
    "de": "Richtung vom Ort „{name}“ nach „{anchor}“: {answer}.",
    "ru": "Направление от населённого пункта «{name}» к «{anchor}»: {answer}."
  },
  "Reka uz naselje „{name}“: {answer}.": {
    "en": "River near “{name}”: {answer}.",
    "de": "Fluss am Ort „{name}“: {answer}.",
    "ru": "Река у населённого пункта «{name}»: {answer}."
  },
  "Referentni vrh planine „{name}“ je „{answer}“. {scope}": {
    "en": "The reference peak of “{name}” is “{answer}”. {scope}",
    "de": "Der Referenzgipfel von „{name}“ ist „{answer}“. {scope}",
    "ru": "Опорная вершина горы «{name}» — «{answer}». {scope}"
  },
  "U kojoj oblasti se nalazi referentni vrh ove planine?": {
    "en": "Which region is the reference peak of this mountain in?",
    "de": "In welcher Region liegt der Referenzgipfel dieses Berges?",
    "ru": "В какой области находится опорная вершина этой горы?"
  },
  "Oblast u kojoj se nalazi vrh planine „{name}“: {answer}.": {
    "en": "Region of the peak of “{name}”: {answer}.",
    "de": "Region des Gipfels von „{name}“: {answer}.",
    "ru": "Область, где находится вершина горы «{name}»: {answer}."
  },
  "Ušće reke „{name}“: {answer}.": {
    "en": "Mouth of the “{name}” river: {answer}.",
    "de": "Mündung des Flusses „{name}“: {answer}.",
    "ru": "Устье реки «{name}»: {answer}."
  },
  "Koja reka nastaje na ovom sastavu?": {
    "en": "Which river is formed at this confluence?",
    "de": "Welcher Fluss entsteht an diesem Zusammenfluss?",
    "ru": "Какая река образуется в этом месте слияния?"
  },
  "Reka „{name}“ jedna je od sastavnica reke „{answer}“.": {
    "en": "The “{name}” river is one of the streams that form “{answer}”.",
    "de": "Der Fluss „{name}“ ist einer der Quellflüsse von „{answer}“.",
    "ru": "Река «{name}» — один из водотоков, образующих реку «{answer}»."
  },
  "Koja reka nastaje kada se ovaj tok spoji sa rekom „{partner}“?": {
    "en": "Which river forms when this stream joins “{partner}”?",
    "de": "Welcher Fluss entsteht, wenn dieser Wasserlauf auf „{partner}“ trifft?",
    "ru": "Какая река образуется при слиянии этого водотока с рекой «{partner}»?"
  },
  "Sastav reka „{name}“ i „{partner}“: {answer}.": {
    "en": "The “{name}” and “{partner}” rivers form “{answer}”.",
    "de": "„{name}“ und „{partner}“ bilden „{answer}“.",
    "ru": "Реки «{name}» и «{partner}» образуют реку «{answer}»."
  },
  "Koje dve reke primaju krakove ove reke?": {
    "en": "Which two rivers receive the branches of this river?",
    "de": "In welche zwei Flüsse münden die Arme dieses Flusses?",
    "ru": "В какие две реки впадают рукава этой реки?"
  },
  "Krakovi reke „{name}“ ulivaju se u dve reke. To su {answer}.": {
    "en": "The branches of the “{name}” river flow into {answer}.",
    "de": "Die Arme des Flusses „{name}“ münden in {answer}.",
    "ru": "Рукава реки «{name}» впадают в две реки. Это {answer}."
  },
  "Kojim morskim slivovima pripadaju krakovi ove reke?": {
    "en": "Which seas do the branches of this river drain into?",
    "de": "In welche Meere entwässern die Arme dieses Flusses?",
    "ru": "К бассейнам каких морей относятся рукава этой реки?"
  },
  "Morski sliv reke „{name}“: {answer}.": {
    "en": "Sea basin of the “{name}” river: {answer}.",
    "de": "Meeresbecken des Flusses „{name}“: {answer}.",
    "ru": "Морской бассейн реки «{name}»: {answer}."
  },
  "Morski slivovi reke „{name}“: {answer}.": {
    "en": "Sea basins of the “{name}” river: {answer}.",
    "de": "Meeresbecken des Flusses „{name}“: {answer}.",
    "ru": "Морские бассейны реки «{name}»: {answer}."
  },
  "Crno more i Egejsko more": {
    "en": "Black Sea and Aegean Sea",
    "de": "Schwarzes Meer und Ägäis",
    "ru": "Чёрное и Эгейское моря"
  },
  "Crno more i Jadransko more": {
    "en": "Black Sea and Adriatic Sea",
    "de": "Schwarzes Meer und Adria",
    "ru": "Чёрное и Адриатическое моря"
  },
  "Jadransko more i Egejsko more": {
    "en": "Adriatic Sea and Aegean Sea",
    "de": "Adria und Ägäis",
    "ru": "Адриатическое и Эгейское моря"
  },
  "Crno more i Baltičko more": {
    "en": "Black Sea and Baltic Sea",
    "de": "Schwarzes Meer und Ostsee",
    "ru": "Чёрное и Балтийское моря"
  },
  "Kolika je približna dužina Timoka od Zaječara do Dunava?": {
    "en": "Approximately how long is the Timok from Zaječar to the Danube?",
    "de": "Wie lang ist der Timok ungefähr von Zaječar bis zur Donau?",
    "ru": "Какова примерная длина Тимока от Заечара до Дуная?"
  },
  "Od sastava Belog i Crnog Timoka do Dunava.": {
    "en": "From the confluence of the White and Black Timok to the Danube.",
    "de": "Vom Zusammenfluss des Weißen und Schwarzen Timok bis zur Donau.",
    "ru": "От слияния Белого и Чёрного Тимока до Дуная."
  },
  "U kojoj oblasti Srbije je deo toka prikazan na mapi?": {
    "en": "In which region of Serbia is the stretch shown on the map?",
    "de": "In welcher Region Serbiens liegt der auf der Karte gezeigte Abschnitt?",
    "ru": "В каком регионе Сербии находится показанный на карте участок?"
  },
  "Položaj prikazanog toka reke „{name}“: {answer}.": {
    "en": "Location of the stretch of “{name}” shown: {answer}.",
    "de": "Lage des gezeigten Abschnitts des Flusses „{name}“: {answer}.",
    "ru": "Расположение показанного участка реки «{name}»: {answer}."
  },
  "istočni položaj": {
    "en": "eastern location",
    "de": "östliche Lage",
    "ru": "восточная точка"
  },
  "zapadni položaj": {
    "en": "western location",
    "de": "westliche Lage",
    "ru": "западная точка"
  },
  "jugozapadni položaj": {
    "en": "southwestern location",
    "de": "südwestliche Lage",
    "ru": "юго-западная точка"
  },
  "severoistočni položaj": {
    "en": "northeastern location",
    "de": "nordöstliche Lage",
    "ru": "северо-восточная точка"
  },
  "Kolika je približna visina referentnog vrha ove planine?": {
    "en": "What is the approximate elevation of this mountain’s reference peak?",
    "de": "Wie hoch ist der Referenzgipfel dieses Berges ungefähr?",
    "ru": "Какова примерная высота опорной вершины этой горы?"
  },
  "Koliko približno stanovnika ima ova opština?": {
    "en": "What is the approximate population of this municipality?",
    "de": "Wie viele Einwohner hat diese Gemeinde ungefähr?",
    "ru": "Сколько примерно жителей в этой общине?"
  },
  "Koliko približno stanovnika ima ovaj okrug?": {
    "en": "What is the approximate population of this district?",
    "de": "Wie viele Einwohner hat dieser Bezirk ungefähr?",
    "ru": "Сколько примерно жителей в этом округе?"
  },
  "Koliko približno stanovnika ima administrativno područje Beograda?": {
    "en": "What is the approximate population of the administrative area of Belgrade?",
    "de": "Wie viele Einwohner hat das Verwaltungsgebiet von Belgrad ungefähr?",
    "ru": "Сколько примерно жителей на административной территории Белграда?"
  },
  "Lepenac i Sitnica": {
    "en": "Lepenac and Sitnica",
    "de": "Lepenac und Sitnica",
    "ru": "Лепенац и Ситница"
  },
  "Lepenac i Beli Drim": {
    "en": "Lepenac and White Drin",
    "de": "Lepenac und Weißer Drin",
    "ru": "Лепенац и Белый Дрин"
  },
  "Sitnica i Binačka Morava": {
    "en": "Sitnica and Binačka Morava",
    "de": "Sitnica und Binačka Morava",
    "ru": "Ситница и Биначка-Морава"
  },
  "Beli Drim i Ibar": {
    "en": "White Drin and Ibar",
    "de": "Weißer Drin und Ibar",
    "ru": "Белый Дрин и Ибар"
  },
  "Kako se zove vrh označen na mapi?": {
    "en": "What is the name of the peak marked on the map?",
    "de": "Wie heißt der auf der Karte markierte Gipfel?",
    "ru": "Как называется вершина, отмеченная на карте?"
  },
  "U kojoj oblasti se nalazi označeni vrh?": {
    "en": "Which region is the marked peak in?",
    "de": "In welcher Region liegt der markierte Gipfel?",
    "ru": "В каком регионе находится отмеченная вершина?"
  },
  "Koji je najviši vrh ove planine?": {
    "en": "What is the highest peak of this mountain?",
    "de": "Welcher ist der höchste Gipfel dieses Berges?",
    "ru": "Какая вершина этой горы самая высокая?"
  },
  "Kolika je približna visina najvišeg vrha?": {
    "en": "What is the approximate elevation of the highest peak?",
    "de": "Wie hoch ist der höchste Gipfel ungefähr?",
    "ru": "Какова примерная высота самой высокой вершины?"
  },
  "U kojoj oblasti se nalazi najviši vrh ove planine?": {
    "en": "Which region is the highest peak of this mountain in?",
    "de": "In welcher Region liegt der höchste Gipfel dieses Berges?",
    "ru": "В каком регионе находится высшая вершина этой горы?"
  },
  "Koji je najviši vrh ove planine u Srbiji?": {
    "en": "What is this mountain’s highest peak in Serbia?",
    "de": "Welcher Gipfel dieses Berges ist in Serbien der höchste?",
    "ru": "Какая вершина этой горы самая высокая в Сербии?"
  },
  "Kolika je približna visina njenog najvišeg vrha u Srbiji?": {
    "en": "What is the approximate elevation of its highest peak in Serbia?",
    "de": "Wie hoch ist ihr höchster Gipfel in Serbien ungefähr?",
    "ru": "Какова примерная высота её высшей вершины в Сербии?"
  },
  "U kojoj oblasti je najviši vrh ove planine u Srbiji?": {
    "en": "Which region is this mountain’s highest peak in Serbia in?",
    "de": "In welcher Region liegt der höchste Gipfel dieses Berges in Serbien?",
    "ru": "В каком регионе находится высшая вершина этой горы в Сербии?"
  },
  "Vrh planine „{name}“ iz kataloga je „{answer}“. {scope}": {
    "en": "The listed peak of “{name}” is “{answer}”. {scope}",
    "de": "Der aufgeführte Gipfel von „{name}“ ist „{answer}“. {scope}",
    "ru": "В каталоге для горы «{name}» указана вершина «{answer}». {scope}"
  },
  "U bazi je izbor većih i poznatijih reka u Srbiji.": {
    "en": "The database lists a selection of Serbia’s larger and better-known rivers.",
    "de": "Die Datenbank enthält eine Auswahl größerer und bekannterer Flüsse in Serbien.",
    "ru": "В базе собраны некоторые крупные и известные реки Сербии."
  },
  "Pogledaj spisak reka": {
    "en": "Browse the river list",
    "de": "Flussliste ansehen",
    "ru": "Посмотреть список рек"
  },
  "Uvećana zastava": {
    "en": "Enlarged flag",
    "de": "Vergrößerte Flagge",
    "ru": "Увеличенный флаг"
  },
  "Pin označava položaj vrha planine.": {
    "en": "The pin marks the location of the mountain peak.",
    "de": "Der Pin markiert die Lage des Berggipfels.",
    "ru": "Метка показывает расположение вершины горы."
  },
  "Vrh": {
    "en": "Peak",
    "de": "Gipfel",
    "ru": "Вершина"
  },
  "Prominencija": {
    "en": "Topographic prominence",
    "de": "Schartenhöhe",
    "ru": "Относительная высота"
  },
  "Koordinate vrha": {
    "en": "Peak coordinates",
    "de": "Gipfelkoordinaten",
    "ru": "Координаты вершины"
  },
  "Strane tabele": {
    "en": "Table pages",
    "de": "Tabellenseiten",
    "ru": "Страницы таблицы"
  },
  "Oblast u knjizi": {
    "en": "Region in the book",
    "de": "Region im Buch",
    "ru": "Регион в книге"
  },
  "Podoblast u knjizi": {
    "en": "Subregion in the book",
    "de": "Teilregion im Buch",
    "ru": "Подрегион в книге"
  }
}
SND_V42_LANGUAGES
,true);
