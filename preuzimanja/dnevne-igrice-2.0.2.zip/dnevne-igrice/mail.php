<?php
defined('ABSPATH') || exit;

function dnevne_igrice_mail_layout($heading, $body, $action = '', $url = '', $note = '') {
    $logo = plugins_url('assets/favicon.png', __FILE__);
    $home = home_url('/');
    $lang = class_exists('SND_I18n') ? SND_I18n::html_lang() : 'sr-Latn';
    ob_start();
    ?>
<!doctype html>
<html lang="<?php echo esc_attr($lang); ?>">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head>
<body style="margin:0;background:#f7f5fc;color:#241737;font-family:Arial,sans-serif">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" bgcolor="#f7f5fc">
<tr><td align="center" style="padding:24px 12px">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:560px;border:1px solid #e5ddef;border-radius:18px;background:#ffffff">
    <tr><td bgcolor="#27164c" style="padding:22px 26px;border-radius:18px 18px 0 0;color:#ffffff">
        <a href="<?php echo esc_url($home); ?>" style="color:#ffffff;text-decoration:none;font-size:21px;font-weight:bold">
            <img src="<?php echo esc_url($logo); ?>" width="38" height="38" alt="" style="vertical-align:middle;margin-right:8px;border:0"> Dnevne igre
        </a>
    </td></tr>
    <tr><td style="padding:26px;font-size:16px;line-height:1.55;color:#241737;overflow-wrap:anywhere">
        <h1 style="margin:0 0 12px;font-size:25px;line-height:1.2;color:#241737"><?php echo esc_html($heading); ?></h1>
        <div style="color:#574b65"><?php echo $body; ?></div>
        <?php if ($action && $url) : ?>
            <table role="presentation" cellspacing="0" cellpadding="0" style="margin-top:22px">
            <tr><td bgcolor="#e3fb8d" style="border-radius:9px">
                <a href="<?php echo esc_url($url); ?>" style="display:inline-block;padding:13px 19px;border-radius:9px;color:#241737;font-weight:bold;text-decoration:none"><?php echo esc_html($action); ?></a>
            </td></tr></table>
        <?php endif; ?>
        <?php if ($note) : ?><p style="margin:20px 0 0;color:#574b65;font-size:14px"><?php echo esc_html($note); ?></p><?php endif; ?>
    </td></tr>
    <tr><td style="padding:15px 26px;border-top:1px solid #e5ddef">
        <a href="<?php echo esc_url($home); ?>" style="color:#592cc5;font-size:14px">dnevneigre.rs</a>
    </td></tr>
    </table>
</td></tr>
</table>
</body>
</html>
    <?php
    return trim(ob_get_clean());
}

function dnevne_igrice_game_account_mail($email, $heading, $body, $url, $note = '') {
    $headers = $email['headers'] ?? array();
    if (is_string($headers)) {
        $headers = preg_split('/\r?\n/', trim($headers), -1, PREG_SPLIT_NO_EMPTY);
    }
    $email['headers'] = array_values(array_filter($headers, static function ($header) {
        return stripos($header, 'Content-Type:') !== 0;
    }));
    $email['headers'][] = 'Content-Type: text/html; charset=UTF-8';
    $email['message'] = dnevne_igrice_mail_layout($heading, esc_html($body), $heading, $url, $note);
    return $email;
}

add_filter('retrieve_password_notification_email', static function ($email, $key, $login) {
    if (!class_exists('SND_Site') || SND_Site::view() !== 'login') {
        return $email;
    }
    $url = add_query_arg(array('mode' => 'reset', 'key' => $key, 'login' => $login), SND_Site::url('login'));
    return dnevne_igrice_game_account_mail($email, SND_I18n::t('Nova lozinka'),
        SND_I18n::t('Za nalog {login} zatražena je nova lozinka.', array('login' => $login)), $url,
        SND_I18n::t('Ako nisi zatražio/la promenu, zanemari ovu poruku.'));
}, 20, 3);

add_filter('wp_new_user_notification_email', static function ($email, $user) {
    if (!class_exists('SND_Site') || SND_Site::view() !== 'login') {
        return $email;
    }
    preg_match_all('~https?://[^\s<>]+~', $email['message'], $matches);
    foreach ($matches[0] as $link) {
        parse_str(wp_parse_url($link, PHP_URL_QUERY) ?: '', $query);
        if (($query['mode'] ?? '') !== 'reset' || ($query['login'] ?? '') !== $user->user_login
            || !is_string($query['key'] ?? null)) {
            continue;
        }
        $url = add_query_arg(array('mode' => 'reset', 'key' => $query['key'], 'login' => $user->user_login), SND_Site::url('login'));
        return dnevne_igrice_game_account_mail($email, SND_I18n::t('Napravi nalog'),
            SND_I18n::t('Dobro došao/la, {login}. Postavi lozinku preko ovog linka:', array('login' => $user->user_login)), $url);
    }
    return $email;
}, 20, 2);

add_filter('wpcf7_contact_form_property_mail', static function ($mail, $form) {
    if (!$form->id() || (int) $form->id() !== dnevne_igrice_contact_id()
        || !empty($mail['use_html']) || empty($mail['body'])) {
        return $mail;
    }
    $mail['body'] = dnevne_igrice_mail_layout('Nova poruka sa sajta', nl2br(esc_html($mail['body']), false));
    $mail['use_html'] = true;
    return $mail;
}, 20, 2);
