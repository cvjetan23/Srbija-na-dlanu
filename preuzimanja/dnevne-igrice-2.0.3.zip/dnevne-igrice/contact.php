<?php
defined('ABSPATH') || exit;

function dnevne_igrice_contact_id() {
    return (int) get_option('dnevne_igrice_contact_id', 0);
}

function dnevne_igrice_contact_quiz() {
    return '<fieldset class="contact-quiz"><legend>Brza zagonetka</legend>[quiz di-quiz maxlength:3 "Koliko slova ima reč igra? (upiši broj)|4" "Koliko polja ima red u klasičnom sudokuu? (upiši broj)|9" "Koliko dnevnih izazova stane u jednu sedmicu? (upiši broj)|7"]</fieldset>';
}

function dnevne_igrice_contact_message_template() {
    return "Razlog poruke: [di-purpose]\nIme: [di-name]\nE-pošta: [di-email]\nNaziv igre: [di-game-name]\nLink: [di-game-url]\n\n[di-message]";
}

function dnevne_igrice_create_contact() {
    if (!class_exists('WPCF7_ContactForm') || !current_user_can('manage_options')) {
        return;
    }
    $existing = dnevne_igrice_contact_id();
    if ($existing && get_post_type($existing) === WPCF7_ContactForm::post_type) {
        $saved = WPCF7_ContactForm::get_instance($existing);
        $properties = $saved ? $saved->get_properties() : array();
        if (isset($properties['form']) && strpos($properties['form'], '<div class="contact-quiz"><label>Brza zagonetka ') !== false) {
            $properties['form'] = preg_replace('~<div class="contact-quiz"><label>Brza zagonetka (\[quiz di-quiz [^\]]+\])</label></div>~',
                '<fieldset class="contact-quiz"><legend>Brza zagonetka</legend>$1</fieldset>', $properties['form']);
            $saved->set_properties($properties);
            $saved->save();
        }
        if (isset($properties['form']) && strpos($properties['form'], '[quiz di-quiz') === false) {
            if (strpos($properties['form'], '[response]') !== false) {
                $marker = '[response]';
            } elseif (strpos($properties['form'], '<div class="contact-submit">') !== false) {
                $marker = '<div class="contact-submit">';
            } else {
                preg_match('/\[submit\b/', $properties['form'], $matches);
                $marker = $matches[0] ?? '';
            }
            if ($marker !== '') {
                $properties['form'] = str_replace($marker, dnevne_igrice_contact_quiz() . "\n" . $marker, $properties['form']);
                $properties['messages']['quiz_answer_not_correct'] = 'Proveri odgovor na zagonetku i upiši broj.';
                $saved->set_properties($properties);
                $saved->save();
            }
        }
        return;
    }

    $form = WPCF7_ContactForm::get_template(array(
        'title' => 'Dnevne igre – predlog i kontakt',
        'locale' => 'sr_RS',
    ));
    $fields = <<<'FORM'
<div class="contact-fields">
<label>Razlog poruke [select* di-purpose "Predlog nove igre" "Kontakt"]</label>
<div class="proposal-fields" data-proposal>
<label>Naziv igre [text di-game-name maxlength:120]</label>
<label>Link do igre [url di-game-url maxlength:500 placeholder "https://"]</label>
</div>
<div class="contact-pair">
<label>Ime [text* di-name autocomplete:name maxlength:120]</label>
<label>E-pošta [email* di-email autocomplete:email maxlength:254]</label>
</div>
<label>Poruka [textarea* di-message minlength:3 maxlength:3000 40x5]</label>
<div hidden aria-hidden="true"><label>Ostavi prazno [text di-site-check tabindex:-1 autocomplete:off]</label></div>
[di-quiz-slot]
[response]
<div class="contact-submit">[submit "Pošalji poruku"]</div>
</div>
FORM;
    $properties = $form->get_properties();
    $form->set_properties(array(
        'form' => str_replace('[di-quiz-slot]', dnevne_igrice_contact_quiz(), $fields),
        'mail' => array_merge($properties['mail'], array(
            'subject' => '[di-purpose] | Dnevne igre',
            'sender' => 'Dnevne igre <wordpress@' . preg_replace('/^www\./', '', wp_parse_url(home_url('/'), PHP_URL_HOST)) . '>',
            'recipient' => 'djordjecvjetan@gmail.com',
            'additional_headers' => 'Reply-To: [di-email]',
            'body' => dnevne_igrice_contact_message_template(),
            'attachments' => '',
            'use_html' => false,
            'exclude_blank' => true,
        )),
        'mail_2' => array_merge($properties['mail_2'], array('active' => false)),
        'additional_settings' => "do_not_store: true",
        'messages' => array_merge($properties['messages'], array(
            'mail_sent_ok' => 'Poruka je poslata. Hvala!',
            'mail_sent_ng' => 'Poruka nije poslata. Pokušaj ponovo malo kasnije.',
            'validation_error' => 'Proveri označena polja i pokušaj ponovo.',
            'spam' => 'Poruka nije poslata. Pokušaj ponovo malo kasnije.',
            'invalid_required' => 'Popuni ovo polje.',
            'invalid_email' => 'Unesi važeću adresu e-pošte.',
            'invalid_url' => 'Unesi važeći link.',
            'invalid_too_short' => 'Unesi malo duži tekst.',
            'invalid_too_long' => 'Skrati tekst u ovom polju.',
            'quiz_answer_not_correct' => 'Proveri odgovor na zagonetku i upiši broj.',
        )),
    ));
    $id = $form->save();
    if ($id) {
        update_option('dnevne_igrice_contact_id', $id, false);
    }
}
add_action('admin_init', 'dnevne_igrice_create_contact', 20);

function dnevne_igrice_render_contact($id) {
    // The saved form already has its own layout. Keep paired labels as direct grid items.
    $manual_layout = static function () { return false; };
    // Older saved forms still rely on Contact Form 7's default response placement.
    $place_response = static function ($markup) use ($id) {
        $form = wpcf7_get_current_contact_form();
        if (!$form || $form->id() !== (int) $id || strpos($markup, 'wpcf7-response-output') !== false) {
            return $markup;
        }
        $submit = strpos($markup, '<div class="contact-submit">');
        if ($submit === false) {
            return $markup;
        }
        return substr_replace($markup, $form->form_response_output(), $submit, 0);
    };
    add_filter('wpcf7_autop_or_not', $manual_layout, 99);
    add_filter('wpcf7_form_elements', $place_response);
    try {
        return do_shortcode('[contact-form-7 id="' . (int) $id . '"]');
    } finally {
        remove_filter('wpcf7_form_elements', $place_response);
        remove_filter('wpcf7_autop_or_not', $manual_layout, 99);
    }
}

function dnevne_igrice_own_submission($submission) {
    $id = dnevne_igrice_contact_id();
    return $id && $submission && $submission->get_contact_form()->id() === $id;
}

function dnevne_igrice_validate_proposal($result, $tag) {
    if (!in_array($tag->name, array('di-purpose', 'di-game-name', 'di-game-url'), true)) {
        return $result;
    }
    $submission = WPCF7_Submission::get_instance();
    if (!dnevne_igrice_own_submission($submission)) {
        return $result;
    }
    $purpose = $submission->get_posted_string('di-purpose');
    if ($tag->name === 'di-purpose') {
        if (!in_array($purpose, array('Predlog nove igre', 'Kontakt'), true)) {
            $result->invalidate($tag, 'Izaberi razlog poruke.');
        }
        return $result;
    }
    if ($purpose !== 'Predlog nove igre') {
        return $result;
    }
    $value = trim($submission->get_posted_string($tag->name));
    if ($value === '') {
        $result->invalidate($tag, $tag->name === 'di-game-name' ? 'Unesi naziv igre.' : 'Unesi link do igre.');
    }
    return $result;
}
add_filter('wpcf7_validate_text', 'dnevne_igrice_validate_proposal', 20, 2);
add_filter('wpcf7_validate_url', 'dnevne_igrice_validate_proposal', 20, 2);
add_filter('wpcf7_validate_select*', 'dnevne_igrice_validate_proposal', 20, 2);

function dnevne_igrice_contact_spam($spam, $submission) {
    if ($spam || !dnevne_igrice_own_submission($submission)) {
        return $spam;
    }
    if (trim($submission->get_posted_string('di-site-check')) !== '') {
        return true;
    }
    $ip = $submission->get_meta('remote_ip');
    if (!$ip) {
        return false;
    }
    $key = 'di_contact_' . wp_hash($ip);
    $attempts = (int) get_transient($key);
    if ($attempts >= 5) {
        return true;
    }
    set_transient($key, $attempts + 1, 10 * MINUTE_IN_SECONDS);
    return false;
}
add_filter('wpcf7_spam', 'dnevne_igrice_contact_spam', 20, 2);
