<?php
/**
 * Plugin Name: Dnevne igre
 * Description: Katalog dnevnih igara, kvizova i logičkih izazova.
 * Version: 2.0.3
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Text Domain: dnevne-igrice
 */

defined('ABSPATH') || exit;

require_once __DIR__ . '/contact.php';
require_once __DIR__ . '/catalogue.php';
require_once __DIR__ . '/seo.php';
require_once __DIR__ . '/mail.php';
require_once __DIR__ . '/game-hub.php';
require_once __DIR__ . '/game-stats.php';
require_once __DIR__ . '/game-dashboard.php';

define('DNEVNE_IGRICE_VERSION', '2.0.3');

function dnevne_igrice_is_legacy_site() {
    return wp_parse_url(home_url('/'), PHP_URL_HOST) === 'cvjetan.dev';
}

function dnevne_igrice_game_link($url) {
    if (strpos($url, '/srbija-na-dlanu/') === 0) {
        $native = apply_filters('dnevne_igre_native_games', array());
        if (!empty($native['srbija-na-dlanu']['url'])) {
            return home_url($url);
        }
        return 'https://cvjetan.dev' . $url;
    }
    return strpos($url, '/') === 0 ? home_url($url) : $url;
}

function dnevne_igrice_page_id() {
    return (int) get_option('dnevne_igrice_page_id', 0);
}

function dnevne_igrice_activate() {
    $slug = dnevne_igrice_is_legacy_site() ? 'dnevne-igrice' : 'dnevne-igre';
    $page = get_page_by_path($slug, OBJECT, 'page');
    if ($page && !get_post_meta($page->ID, '_dnevne_igrice_catalogue', true)) {
        wp_die(esc_html("Putanja /{$slug}/ je zauzeta postojećom stranicom."));
    }
    DI_Game_Hub::install((bool) dnevne_igrice_page_id());
    if ($page) {
        update_option('dnevne_igrice_page_id', $page->ID, false);
        return;
    }

    $id = wp_insert_post(array(
        'post_type' => 'page',
        'post_status' => 'publish',
        'post_name' => $slug,
        'post_title' => 'Dnevne igre',
        'post_content' => 'Katalog dnevnih igara, kvizova i logičkih izazova.',
        'meta_input' => array('_dnevne_igrice_catalogue' => '1'),
    ), true);
    if (is_wp_error($id)) {
        wp_die(esc_html($id->get_error_message()));
    }
    update_option('dnevne_igrice_page_id', $id, false);
}
register_activation_hook(__FILE__, 'dnevne_igrice_activate');
register_deactivation_hook(__FILE__, static function () { wp_clear_scheduled_hook('dnevne_igrice_rounds_cleanup'); });

function dnevne_igrice_template($template) {
    if (apply_filters('dnevne_igre_native_page', false)) {
        return $template;
    }
    $catalogue = is_page(dnevne_igrice_page_id());
    $site_page = wp_parse_url(home_url('/'), PHP_URL_HOST) === 'dnevneigre.rs'
        && (is_404() || is_singular(array('post', 'page')) || is_archive() || is_search() || is_home());
    if (!is_feed() && !is_embed() && ($catalogue || $site_page)) {
        remove_action('wp_head', '_wp_render_title_tag', 1);
        remove_action('wp_head', '_block_template_render_title_tag', 1);
        remove_action('wp_head', 'rel_canonical');
        if (defined('WPSEO_VERSION')) {
            add_filter('wpseo_frontend_presenter_classes', static function ($presenters) {
                return array_diff($presenters, array('Yoast\\WP\\SEO\\Presenters\\Title_Presenter'));
            });
        }
        return __DIR__ . '/page.php';
    }
    return $template;
}
add_filter('template_include', 'dnevne_igrice_template', 99);

function dnevne_igrice_redirect_legacy() {
    if (dnevne_igrice_is_legacy_site() && is_page() && get_queried_object_id() === dnevne_igrice_page_id()) {
        wp_redirect('https://dnevneigre.rs/', 301, 'Dnevne igre');
        exit;
    }
}
add_action('template_redirect', 'dnevne_igrice_redirect_legacy', 1);

function dnevne_igrice_menu_link($items, $args) {
    if (($args->theme_location ?? '') !== 'primary') {
        return $items;
    }
    $id = dnevne_igrice_page_id();
    if (!$id || get_post_status($id) !== 'publish') {
        return $items;
    }
    $url = dnevne_igrice_is_legacy_site() ? 'https://dnevneigre.rs/' : esc_url(get_permalink($id));
    if (!$url || strpos($items, 'href="' . $url . '"') !== false) {
        return $items;
    }
    return $items . '<li class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-link" href="' . $url . '">Dnevne igre</a></li>';
}
add_filter('wp_nav_menu_items', 'dnevne_igrice_menu_link', 10, 2);
