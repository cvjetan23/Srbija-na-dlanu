(() => {
    const storageKey = 'dnevne-igrice-tema';
    const theme = document.getElementById('tema');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    const currentTheme = () => document.documentElement.dataset.theme || (prefersDark.matches ? 'dark' : 'light');
    const describeTheme = () => {
        const isDark = currentTheme() === 'dark';
        const next = isDark ? 'Uključi svetlu temu' : 'Uključi tamnu temu';
        theme.dataset.icon = isDark ? 'sun' : 'moon';
        theme.setAttribute('aria-label', next);
        theme.title = next;
    };
    theme.hidden = false;
    describeTheme();
    prefersDark.addEventListener('change', describeTheme);
    theme.addEventListener('click', () => {
        const chosen = currentTheme() === 'dark' ? 'light' : 'dark';
        theme.dataset.animated = '';
        document.documentElement.dataset.theme = chosen;
        try { localStorage.setItem(storageKey, chosen); } catch {}
        describeTheme();
    });
    setTimeout(() => document.documentElement.classList.remove('di-loading'), 180);

    const search = document.getElementById('pretraga');
    if (!search) return;

    const alphabet = 'абвгдђежзијклљмнњопрстћуфхцчџш';
    const latin = ['a','b','v','g','d','dj','e','z','z','i','j','k','l','lj','m','n','nj','o','p','r','s','t','c','u','f','h','c','c','dz','s'];
    const normalize = value => value.toLowerCase()
        .replace(/[а-шђјљњћџ]/g, char => latin[alphabet.indexOf(char)] ?? char)
        .replace(/đ/g, 'dj')
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();

    const cards = Array.from(document.querySelectorAll('[data-game]'), node => {
        const link = node.querySelector('h3 a');
        return {
            node,
            link,
            sortName: (node.querySelector('h3')?.textContent || '').trim().toLowerCase()
                .replace(/[а-шђјљњћџ]/g, char => char === 'ђ' ? 'đ' : (latin[alphabet.indexOf(char)] ?? char)),
            search: normalize(node.dataset.search),
            url: node.dataset.status === 'dnevna' && node.dataset.platform === 'pregledac' ? link?.href : '',
        };
    });
    const grid = document.getElementById('igre');
    const order = document.getElementById('redosled');
    const collator = new Intl.Collator('sr-Latn', {sensitivity: 'base', numeric: true});
    const alphabetical = [...cards].sort((a, b) => collator.compare(a.sortName, b.sortName));
    const shuffled = [...cards];
    for (let index = shuffled.length - 1; index > 0; --index) {
        const pick = Math.floor(Math.random() * (index + 1));
        [shuffled[index], shuffled[pick]] = [shuffled[pick], shuffled[index]];
    }
    const orders = {default: cards, random: shuffled, asc: alphabetical, desc: [...alphabetical].reverse()};
    let orderedCards = orders.default;
    const buttons = Array.from(document.querySelectorAll('[data-category]')).filter(node => node.tagName === 'BUTTON');
    const random = document.getElementById('nasumicno');
    const message = document.getElementById('rezultati');
    const empty = document.getElementById('prazno');
    const more = document.getElementById('jos');
    const chunk = 12;
    const noun = { one: 'igra', few: 'igre', other: 'igara' };
    const plural = new Intl.PluralRules('sr');
    let category = 'sve';
    let limit = chunk;
    let destinations = [];
    let initial = true;

    function showGames() {
        const query = normalize(search.value).split(/\s+/).filter(Boolean);
        destinations = [];
        let matches = 0;
        let firstNew = null;
        for (const {node, search: text, url} of orderedCards) {
            const meta = node.dataset;
            const matching = (category === 'sve' || category === meta.category)
                && query.every(token => text.includes(token));
            if (matching) {
                matches += 1;
                if (url) destinations.push(url);
            }
            const hide = !matching || matches > limit;
            if (!hide && node.hidden && !firstNew) firstNew = node;
            node.classList.toggle('is-entering', !hide && (initial || node.hidden));
            node.hidden = hide;
        }
        message.textContent = matches > limit ? `Prikazano ${limit} od ${matches} igara` : `${matches} ${noun[plural.select(matches)]}`;
        empty.hidden = matches > 0;
        more.hidden = matches <= limit;
        random.disabled = !destinations.length;
        initial = false;
        return firstNew;
    }

    function changeCategory(next) {
        category = next;
        for (const button of buttons) button.setAttribute('aria-pressed', String(button.dataset.category === next));
    }
    function filter() {
        limit = chunk;
        showGames();
    }

    for (const button of buttons) {
        button.addEventListener('click', () => {
            changeCategory(button.dataset.category);
            filter();
        });
    }
    search.addEventListener('input', filter);
    order.value = 'default';
    order.addEventListener('change', () => {
        orderedCards = orders[order.value] || orders.default;
        grid.append(...orderedCards.map(card => card.node));
        filter();
    });
    random.addEventListener('click', () => {
        if (!destinations.length) return;
        const choice = Math.floor(Math.random() * destinations.length);
        window.open(destinations[choice], '_blank', 'noopener');
    });
    document.getElementById('ponisti').addEventListener('click', () => {
        changeCategory('sve');
        search.value = '';
        filter();
        search.focus();
    });
    more.addEventListener('click', () => {
        limit += chunk;
        const next = showGames();
        if (next) {
            next.tabIndex = -1;
            next.focus();
        }
    });
    document.getElementById('filteri').hidden = false;
    showGames();

    function initializeFavorites(panel) {
        const key = 'dnevne-igrice-omiljene';
        const max = Number(panel.dataset.limit);
        const list = document.getElementById('lista-omiljenih');
        const noFavorites = document.getElementById('nema-omiljenih');
        const count = document.getElementById('broj-omiljenih');
        const heading = document.getElementById('naslov-omiljene');
        const template = document.getElementById('omiljena-igra');
        const notice = document.getElementById('status-omiljenih');
        const available = new Map();
        let noticeTimer;

        for (const {node, link} of cards) {
            const control = node.querySelector('[data-favorite]');
            if (!control || !link) continue;
            const id = node.dataset.gameId;
            available.set(id, {control, name: link.textContent.trim(), href: link.href, label: control.querySelector('span')});
            control.hidden = false;
            control.addEventListener('click', () => toggle(id));
        }

        function decode(value) {
            try {
                const ids = JSON.parse(value);
                if (Array.isArray(ids)) return [...new Set(ids.filter(id => available.has(id)))].slice(0, max);
            } catch {}
            return [];
        }

        let favorites = [];
        try { favorites = decode(localStorage.getItem(key)); } catch {}

        function announce(text, visible = false) {
            clearTimeout(noticeTimer);
            notice.textContent = text;
            notice.className = visible ? 'favorite-notice' : 'sr-only';
            if (visible) noticeTimer = setTimeout(() => { notice.className = 'sr-only'; }, 5500);
        }

        function render() {
            count.textContent = favorites.length;
            list.hidden = favorites.length === 0;
            noFavorites.hidden = !list.hidden;
            for (const [id, {control, name, label}] of available) {
                const saved = favorites.includes(id);
                control.classList.toggle('is-saved', saved);
                label.textContent = saved ? 'U omiljenim' : 'Dodaj u omiljene';
                control.setAttribute('aria-label', saved
                    ? `U omiljenim. Ukloni igru „${name}“ iz omiljenih.`
                    : `Dodaj u omiljene: ${name}`);
            }
            list.replaceChildren(...favorites.map((id, index) => {
                const {name, href} = available.get(id);
                const entry = template.content.firstElementChild.cloneNode(true);
                const link = entry.querySelector('a');
                link.textContent = name;
                link.href = href;
                const remove = entry.querySelector('button');
                remove.setAttribute('aria-label', `Ukloni igru „${name}“ iz omiljenih`);
                remove.addEventListener('click', () => {
                    toggle(id);
                    const next = list.children[Math.min(index, favorites.length - 1)]?.querySelector('button');
                    (next || heading).focus();
                });
                return entry;
            }));
        }

        function toggle(id) {
            const saved = favorites.includes(id);
            if (!saved && favorites.length >= max) {
                announce(`Možeš da sačuvaš najviše ${max} igara. Ukloni jednu da dodaš drugu.`, true);
                return;
            }
            favorites = saved ? favorites.filter(game => game !== id) : [...favorites, id];
            render();
            const name = available.get(id).name;
            try {
                localStorage.setItem(key, JSON.stringify(favorites));
                announce(saved ? `Uklonjeno iz omiljenih: ${name}.` : `Dodato u omiljene: ${name}.`);
            } catch {
                announce('Pregledač ne dozvoljava čuvanje. Izbor važi dok je ova stranica otvorena.', true);
            }
        }

        window.addEventListener('storage', event => {
            if (event.storageArea !== localStorage || (event.key !== key && event.key !== null)) return;
            favorites = decode(event.newValue);
            render();
        });
        render();
        panel.hidden = false;
    }

    const favoritesPanel = document.getElementById('omiljene');
    if (favoritesPanel) initializeFavorites(favoritesPanel);

    const contact = document.querySelector('#kontakt form');
    if (contact) {
        const quiz = contact.querySelector('input.wpcf7-quiz');
        if (quiz) {
            quiz.inputMode = 'numeric';
            quiz.addEventListener('input', () => {
                if (!quiz.classList.contains('wpcf7-not-valid')) return;
                // Clear the old message while typing so the submit button cannot move on blur.
                quiz.closest('.wpcf7-form-control-wrap').querySelector('.wpcf7-not-valid-tip')?.remove();
                quiz.classList.remove('wpcf7-not-valid');
                quiz.setCustomValidity('');
                quiz.setAttribute('aria-invalid', 'false');
                quiz.removeAttribute('aria-describedby');
            });
        }
        const reason = contact.querySelector('[name="di-purpose"]');
        const proposal = contact.querySelector('[data-proposal]');
        const fields = proposal.querySelectorAll('input');
        const sync = () => {
            const show = reason.value === 'Predlog nove igre';
            proposal.hidden = !show;
            for (const field of fields) {
                field.disabled = !show;
                field.setAttribute('aria-required', String(show));
            }
        };
        reason.addEventListener('change', sync);
        contact.addEventListener('reset', () => setTimeout(sync, 0));
        sync();
    }

})();
