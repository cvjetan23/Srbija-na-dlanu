(() => {
    if (!location.hash.startsWith('#prenos=')) return;
    const known = ['snd:v1:stats', 'snd:v1:daily-results', 'snd:v1:preferences', 'snd:theme', 'dnevne-igrice-omiljene'];
    const paths = {'oko-kustosa':'/oko-kustosa/', 'srbija-na-dlanu':'/srbija-na-dlanu/', catalogue:'/'};
    try {
        const {data,target} = JSON.parse(decodeURIComponent(location.hash.slice(8)));
        const path = Object.hasOwn(paths,target) ? paths[target] : '/';
        for (const [key,value] of Object.entries(data)) {
            if ((known.includes(key) || /^oko-kustosa:v1:\d{4}-\d{2}-\d{2}:[a-f0-9]{12}$/.test(key))
                && typeof value === 'string' && value.length <= 10000 && localStorage.getItem(key) === null) {
                localStorage.setItem(key,value);
            }
        }
        history.replaceState(null,'','/');
        if (path !== '/') location.replace(path);
    } catch (_) {
        history.replaceState(null,'',location.pathname + location.search);
    }
})();
