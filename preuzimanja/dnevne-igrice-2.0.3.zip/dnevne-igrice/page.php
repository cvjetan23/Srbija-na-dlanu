<?php
defined('ABSPATH') || exit;

$catalogue_page = is_page(dnevne_igrice_page_id());
$not_found = is_404();
$standalone = is_singular();
$games = $catalogue_page ? dnevne_igrice_games() : array();
$categories = dnevne_igrice_categories();
$labels = array('uskoro' => 'Najavljeno', 'nedostupno' => 'Nedostupan link');
$assets = plugin_dir_url(__FILE__) . 'assets/';
$url = $standalone ? wp_get_canonical_url() : '';
$home = get_permalink(dnevne_igrice_page_id()) ?: home_url('/');
$privacy_url = get_privacy_policy_url();
$heading = $standalone ? get_the_title(get_queried_object_id()) : 'Objave';
if ($not_found) {
    $heading = 'Stranica nije pronađena';
} elseif (is_search()) {
    $heading = sprintf('Pretraga za „%s“', get_search_query(false));
} elseif (is_archive()) {
    $heading = wp_strip_all_tags(get_the_archive_title());
}
$seo = dnevne_igrice_seo_defaults();
$yoast = defined('WPSEO_VERSION');
$title = $yoast ? html_entity_decode(wp_get_document_title(), ENT_QUOTES, 'UTF-8') : ($seo['title'] ?? $heading . ' | Dnevne igre');
$description = $seo['description'] ?? '';
$contact_id = dnevne_igrice_contact_id();
$contact_available = $contact_id && shortcode_exists('contact-form-7') && get_post_status($contact_id) === 'publish';
$has_contact = $catalogue_page && $contact_available;
$asset_version = '?ver=' . DNEVNE_IGRICE_VERSION;
$favorites_limit = 10;
$heart_icon = '<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20.8 5.7a5.1 5.1 0 0 0-7.2 0L12 7.3l-1.6-1.6a5.1 5.1 0 0 0-7.2 7.2l1.6 1.6L12 21l7.2-6.5 1.6-1.6a5.1 5.1 0 0 0 0-7.2Z"/></svg>';

$featured_labels = array(
    1 => array('Okruzi', 'Pogodi okrug prema obliku njegovih granica.',
        '<path d="m4.5 5 5.2-2.5 4.5 2.2 4.9-.6 2.1 6-2.7 3.5.6 4.2-5.1 3.4-3.5-2.2-4.4.4-3.4-4.8 2.2-3.5Z"/><path d="m9.7 2.5 1 5.8-3.8 3.5 3.6 2.9v4.1m.2-10.5 4.6 2.1 5.8-.3m-5.8.3-.2 5.2 3.9 2.2m-3.9-2.2-4.6-.9"/>'),
    'native-vukov-vez' => array('Vukov vez', 'Spoj stare reči sa njihovim značenjima.',
        '<path d="M12 2v3m0 14v3M2 12h3m14 0h3m-10-7 2.5 2.5h2v2L19 12l-2.5 2.5v2h-2L12 19l-2.5-2.5h-2v-2L5 12l2.5-2.5v-2h2Z"/><path d="m12 9 3 3-3 3-3-3Z"/>'),
    3 => array('Gradovi i naselja', 'Na osnovu položaja otkrij grad ili selo.',
        '<path d="M18.4 8.8c0 4.2-6.4 9.9-6.4 9.9S5.6 13 5.6 8.8a6.4 6.4 0 1 1 12.8 0Z"/><circle cx="12" cy="8.8" r="2.1"/><path d="M7.1 17.1c-2 .5-3.4 1.2-3.4 2.1 0 1.4 3.7 2.6 8.3 2.6s8.3-1.2 8.3-2.6c0-.9-1.4-1.6-3.4-2.1"/>'),
    'native-oko-kustosa' => array('Oko kustosa', 'Otkrij autora, godinu i motiv slike dana.',
        '<rect x="2.5" y="4" width="19" height="16" rx="1.5"/><path d="M5.5 12s2.5-3.5 6.5-3.5 6.5 3.5 6.5 3.5-2.5 3.5-6.5 3.5S5.5 12 5.5 12Z"/><circle cx="12" cy="12" r="1.5"/>'),
    4 => array('Reke', 'Prati tok i pogodi ime reke.',
        '<path d="M19.8 3.2c-1.4 4-8.2 2.5-11.1 5.2-2.7 2.4-.6 4.8 2.9 5.9 2.7.8 4.3 2.9 2.6 4.5-1.4 1.2-3.5 1-6.7 2.2M14.5 3c-2.1 1.4-6.3 1-8.9 3.1-4.1 3.4-2.1 8.5 3.4 10.1 1.6.5 2 1.6.1 2.2l-5.4 1.5M21 9.4c-3.5.2-5.6 1.5-6.4 3.1"/>'),
    5 => array('Planine', 'Istraži gde se uzdižu planine Srbije.',
        '<path d="m2.7 19.6 7-11 2.5 4 3.5-7.9 5.7 14.9Z"/><path d="m6.4 13.8 3.4 1.6 2.4-2.8m1.7-3.9 2 1.6 1.7-1.2M4.7 6.2h3m-1.5-1.5v3"/>'),
);
$games_by_id = array_column($games, null, 'id');
$recommended_ids = array('native-oko-kustosa', 'native-vukov-vez', 6, 136, 24, 33, 28, 75, 134, 61);
$first_cards = array_fill_keys($recommended_ids, null);
$remaining_cards = array();
foreach ($games as $game) {
    if (array_key_exists($game['id'], $first_cards)) {
        $first_cards[$game['id']] = $game;
    } else {
        $remaining_cards[] = $game;
    }
}
$catalogue = array_merge(array_filter(array_values($first_cards)), $remaining_cards);
?>
<!doctype html>
<html lang="sr-Latn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo esc_html($title); ?></title>
<?php if (!$yoast && !defined('SLIM_SEO_VER')) : ?>
<?php if ($description) : ?><meta name="description" content="<?php echo esc_attr($description); ?>"><?php endif; ?>
<?php if ($url) : ?>
<link rel="canonical" href="<?php echo esc_url($url); ?>">
<meta property="og:title" content="<?php echo esc_attr($seo['social_title'] ?? $heading); ?>">
<meta property="og:type" content="<?php echo is_single() ? 'article' : 'website'; ?>">
<meta property="og:site_name" content="Dnevne igre">
<meta property="og:url" content="<?php echo esc_url($url); ?>">
<?php if ($description) : ?><meta property="og:description" content="<?php echo esc_attr($description); ?>"><?php endif; ?>
<meta property="og:image" content="<?php echo esc_url(dnevne_igrice_share_image()); ?>">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:image" content="<?php echo esc_url(dnevne_igrice_share_image()); ?>">
<?php endif; ?>
<?php if ($catalogue_page) : ?>
<script type="application/ld+json"><?php echo wp_json_encode(array('@context' => 'https://schema.org', '@type' => 'WebSite', 'name' => 'Dnevne igre', 'url' => $home, 'description' => $description, 'inLanguage' => 'sr-Latn'), JSON_HEX_TAG | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?></script>
<?php endif; ?>
<?php endif; ?>
<script id="dnevne-igrice-boot" data-noptimize="1">
try {
    const chosen = localStorage.getItem('dnevne-igrice-tema');
    if (chosen === 'light' || chosen === 'dark') document.documentElement.dataset.theme = chosen;
} catch {}
<?php if ($catalogue_page) : ?>
if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.documentElement.classList.add('di-loading');
    setTimeout(() => document.documentElement.classList.remove('di-loading'), 1200);
}
<?php endif; ?>
</script>
<?php if ($catalogue_page && !dnevne_igrice_is_legacy_site()) : ?>
<script src="<?php echo esc_url($assets . 'transfer.js' . $asset_version); ?>"></script>
<?php endif; ?>
<?php wp_head(); ?>
<?php if (!has_site_icon()) : ?>
    <link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url($assets . 'favicon.png'); ?>">
    <link rel="apple-touch-icon" href="<?php echo esc_url($assets . 'favicon.png'); ?>">
<?php endif; ?>
<link rel="stylesheet" href="<?php echo esc_url($assets . 'fonts.css' . $asset_version); ?>">
<link rel="stylesheet" href="<?php echo esc_url($assets . 'site.css' . $asset_version); ?>">
<script defer src="<?php echo esc_url($assets . 'site.js' . $asset_version); ?>"></script>
</head>
<body id="vrh" <?php body_class($catalogue_page ? 'di-catalogue-page' : 'di-content-page'); ?>>
<?php wp_body_open(); ?>
<?php if ($catalogue_page) : ?>
<div class="site-loader" aria-hidden="true">
    <span class="brand-mark"><i></i><i></i><i></i><i></i></span>
</div>
<?php endif; ?>
<a class="skip-link" href="<?php echo $catalogue_page ? '#katalog' : '#sadrzaj'; ?>"><?php echo $catalogue_page ? 'Preskoči na katalog' : 'Preskoči na sadržaj'; ?></a>
<header class="site-header">
    <div class="wrap header-inner">
        <a class="brand" href="<?php echo esc_url($home); ?>">
            <span class="brand-mark" aria-hidden="true"><i></i><i></i><i></i><i></i></span>
            Dnevne igre
        </a>
        <nav aria-label="Glavni meni">
            <a class="nav-catalogue" href="<?php echo esc_url(($catalogue_page ? '' : $home) . '#katalog'); ?>">Katalog</a>
            <?php if ($contact_available) : ?><a href="<?php echo esc_url(($catalogue_page ? '' : $home) . '#kontakt'); ?>">Kontakt</a><?php endif; ?>
            <a href="<?php echo esc_url(dnevne_igrice_game_link('/srbija-na-dlanu/?lang=sr')); ?>" target="_blank" rel="noopener">Srbija na dlanu</a>
        </nav>
        <button type="button" class="theme-button" id="tema" aria-label="Uključi tamnu temu" hidden>
            <svg class="theme-glyph" viewBox="0 0 40 40" aria-hidden="true" focusable="false">
                <defs>
                    <mask id="di-eclipse" maskUnits="userSpaceOnUse" x="0" y="0" width="40" height="40">
                        <path fill="#fff" d="M0 0h40v40H0z"/>
                        <circle class="theme-shadow" cx="20" cy="20" r="10.5" fill="#000"/>
                    </mask>
                </defs>
                <g class="theme-rays" fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.8">
                    <path d="M20 5v3.4m0 23.2V35M5 20h3.4m23.2 0H35M9.4 9.4l2.4 2.4m16.4 16.4 2.4 2.4m0-21.2-2.4 2.4M11.8 28.2l-2.4 2.4"/>
                </g>
                <g mask="url(#di-eclipse)"><circle class="theme-disc" cx="20" cy="20" r="7.8" fill="currentColor"/></g>
                <path class="theme-sparks" d="m30 9 1.1 2.9L34 13l-2.9 1.1L30 17l-1.1-2.9L26 13l2.9-1.1ZM33 21l.7 1.8 1.8.7-1.8.7L33 26l-.7-1.8-1.8-.7 1.8-.7Z" fill="currentColor"/>
            </svg>
        </button>
    </div>
</header>
<main class="wrap" id="sadrzaj" tabindex="-1">
    <?php if ($not_found) : ?>
        <section class="missing-page" aria-labelledby="naslov-greske">
            <div class="missing-copy">
                <p class="missing-code">Greška 404</p>
                <h1 id="naslov-greske">Stranica nije pronađena</h1>
                <p>Proveri adresu ili izaberi igru iz kataloga.</p>
                <a class="hero-button" href="<?php echo esc_url($home . '#katalog'); ?>">Nazad na katalog</a>
            </div>
            <img class="missing-art" src="<?php echo esc_url($assets . 'puzzle-hero-mobile.webp'); ?>" alt="" width="960" height="720">
        </section>
    <?php elseif (!$catalogue_page && $standalone) : ?>
        <article class="content-panel" aria-labelledby="naslov-stranice">
            <h1 id="naslov-stranice"><?php echo esc_html($heading); ?></h1>
            <?php while (have_posts()) : the_post(); the_content(); wp_link_pages(); endwhile; ?>
        </article>
    <?php elseif (!$catalogue_page) : ?>
        <section class="content-panel" aria-labelledby="naslov-stranice">
            <h1 id="naslov-stranice"><?php echo esc_html($heading); ?></h1>
            <?php if (have_posts()) : ?>
                <ul class="entry-list">
                    <?php while (have_posts()) : the_post(); ?>
                        <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                    <?php endwhile; ?>
                </ul>
                <?php the_posts_pagination(array('prev_text' => 'Prethodna', 'next_text' => 'Sledeća', 'screen_reader_text' => 'Stranice rezultata')); ?>
            <?php else : ?>
                <p>Nema rezultata. <a href="<?php echo esc_url($home . '#katalog'); ?>">Pogledaj katalog igara.</a></p>
            <?php endif; ?>
        </section>
    <?php else : ?>
    <section class="hero" aria-labelledby="naslov">
        <div class="hero-copy">
            <h1 id="naslov">Dnevne<br>igre<span aria-hidden="true">.</span></h1>
            <p>Pronađi svoju sledeću dnevnu igru.<br>Od reči i mapa do kvizova i logičkih izazova.</p>
            <a class="hero-button" href="#katalog">Istraži igre</a>
        </div>
        <picture class="hero-art">
            <source media="(max-width: 700px)" srcset="<?php echo esc_url($assets . 'puzzle-hero-mobile.webp'); ?>" width="960" height="720">
            <img src="<?php echo esc_url($assets . 'puzzle-hero.webp'); ?>" alt="" width="1200" height="800" fetchpriority="high">
        </picture>
    </section>

    <div class="game-shelves" data-nosnippet>
        <section class="game-shelf" aria-labelledby="naslov-izdvojene">
            <div class="section-heading">
                <h2 id="naslov-izdvojene">Izdvojene igre</h2>
            </div>
            <div class="featured-links">
                <?php foreach ($featured_labels as $id => [$featured_title, $featured_description, $featured_icon]) :
                    if (!isset($games_by_id[$id]) || $games_by_id[$id]['status'] !== 'dnevna') { continue; }
                    $game = $games_by_id[$id];
                    $featured_id = esc_attr((string) $id);
                    ?>
                    <a class="featured-link" href="<?php echo esc_url(dnevne_igrice_game_link($game['url'])); ?>" target="_blank" rel="noopener" aria-labelledby="featured-title-<?php echo $featured_id; ?>" aria-describedby="featured-description-<?php echo $featured_id; ?>">
                        <span class="geo-mark geo-<?php echo $featured_id; ?>" aria-hidden="true">
                            <svg viewBox="0 0 24 24" width="24" height="24" focusable="false" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><?php echo $featured_icon; ?></svg>
                        </span>
                        <span class="featured-copy">
                            <span id="featured-title-<?php echo $featured_id; ?>"><?php echo esc_html($featured_title); ?></span>
                            <span class="featured-description" id="featured-description-<?php echo $featured_id; ?>"><?php echo esc_html($featured_description); ?></span>
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
        <section class="game-shelf favorites" id="omiljene" aria-labelledby="naslov-omiljene" data-limit="<?php echo (int) $favorites_limit; ?>" hidden>
            <div class="section-heading favorites-heading">
                <h2 id="naslov-omiljene" tabindex="-1">Omiljene igre</h2>
                <span class="favorites-count"><span id="broj-omiljenih">0</span><span aria-hidden="true"> / </span><span class="sr-only"> od </span><?php echo (int) $favorites_limit; ?></span>
            </div>
            <div class="favorites-empty" id="nema-omiljenih">
                <span class="favorites-empty-mark"><?php echo $heart_icon; ?></span>
                <div>
                    <p>Trenutno nema omiljenih igara.</p>
                    <a href="#katalog">Pronađi igru u katalogu</a>
                </div>
            </div>
            <ul class="favorites-list" id="lista-omiljenih" hidden></ul>
            <template id="omiljena-igra">
                <li class="favorite-game">
                    <a target="_blank" rel="noopener"></a>
                    <button class="favorite-remove" type="button"><?php echo $heart_icon; ?></button>
                </li>
            </template>
        </section>
    </div>
    <p class="sr-only" id="status-omiljenih" role="status"></p>

    <section class="catalogue" id="katalog" tabindex="-1" aria-labelledby="naslov-katalog">
        <div class="section-heading catalogue-heading">
            <h2 id="naslov-katalog">Katalog igara</h2>
            <p>Dnevni kvizovi, igre reči, sudoku i geografski izazovi na jednom mestu. Otvori igru na izvornom sajtu.</p>
        </div>
        <div id="filteri" class="filters" hidden>
            <div class="categories" role="group" aria-label="Kategorija">
                <button type="button" data-category="sve" aria-pressed="true">Sve igre</button>
                <?php foreach ($categories as $slug => $category) : ?>
                    <button type="button" data-category="<?php echo esc_attr($slug); ?>" aria-pressed="false"><?php echo esc_html($category[0]); ?></button>
                <?php endforeach; ?>
            </div>
            <div class="filter-row">
                <label class="search">
                    <span class="search-mark" aria-hidden="true"></span>
                    <span class="sr-only">Pronađi igru</span>
                    <input type="search" id="pretraga" placeholder="Pronađi igru ili autora…" autocomplete="off">
                </label>
                <label class="game-sort">
                    <span class="sr-only">Redosled igara</span>
                    <select id="redosled">
                        <option value="default" selected>Podrazumevano</option>
                        <option value="random">Nasumičan redosled</option>
                        <option value="asc">Abecedno A–Ž</option>
                        <option value="desc">Abecedno Ž–A</option>
                    </select>
                </label>
                <button class="random-button" type="button" id="nasumicno">Zaigraj nasumično</button>
            </div>
            <p class="results" id="rezultati" role="status"></p>
        </div>
        <div class="game-grid" id="igre" data-nosnippet>
            <?php foreach ($catalogue as $game) :
                $category = $categories[$game['category']];
                $link = dnevne_igrice_game_link($game['url']);
                $status = $labels[$game['status']] ?? '';
                ?>
                <article class="game-card tone-<?php echo esc_attr($game['category']); ?>"
                    data-game data-game-id="<?php echo esc_attr($game['id']); ?>" data-category="<?php echo esc_attr($game['category']); ?>"
                    data-platform="<?php echo esc_attr($game['platform']); ?>"
                    data-status="<?php echo esc_attr($game['status']); ?>"
                    data-search="<?php echo esc_attr($game['name'] . ' ' . $game['provider'] . ' ' . $game['description'] . ' ' . $category[0]); ?>">
                    <div class="card-top">
                        <span class="game-mark" aria-hidden="true"><?php echo esc_html($category[1]); ?></span>
                        <span class="card-category"><?php echo esc_html($category[0]); ?></span>
                    </div>
                    <h3><?php if ($game['status'] === 'nedostupno') : ?>
                        <?php echo esc_html($game['name']); ?>
                    <?php else : ?>
                        <a href="<?php echo esc_url($link); ?>" target="_blank" rel="noopener"><?php echo esc_html($game['name']); ?></a>
                    <?php endif; ?></h3>
                    <p><?php echo esc_html($game['description']); ?></p>
                    <div class="card-footer">
                        <div class="card-meta">
                            <span><?php echo esc_html($game['provider']); ?></span>
                            <?php if ($status || $game['platform'] === 'aplikacija') : ?>
                                <span><?php echo esc_html($status ?: 'Aplikacija'); ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if ($game['status'] !== 'nedostupno' && $link) : ?>
                            <button class="favorite-toggle" type="button" data-favorite hidden>
                                <?php echo $heart_icon; ?><span>Dodaj u omiljene</span>
                            </button>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <div class="empty" id="prazno" hidden>
            <h3>Nema igara za ovaj izbor</h3>
            <p>Probaj drugi naziv ili ukloni filtere.</p>
            <button type="button" id="ponisti">Poništi filtere</button>
        </div>
        <button type="button" class="more" id="jos" hidden>Prikaži još igara</button>
    </section>
    <section class="catalogue-about" aria-labelledby="naslov-o-igrama">
        <div class="catalogue-about-title">
            <span class="brand-mark" aria-hidden="true"><i></i><i></i><i></i><i></i></span>
            <h2 id="naslov-o-igrama">Kako funkcionišu dnevne igre?</h2>
        </div>
        <div class="catalogue-about-copy">
            <p>Na jednom mestu možeš da pronađeš kratke kvizove i zagonetke. Pogodi reč, reši sudoku, prepoznaj umetninu ili pronađi mesto na mapi.</p>
            <p>Izaberi igru u katalogu i dodaj je u omiljene ako želiš da joj se vratiš. Igre označene kao dnevni izazovi svakog dana imaju novi zadatak.</p>
        </div>
    </section>
    <?php if ($has_contact) : ?>
        <section class="contact" id="kontakt" aria-labelledby="naslov-kontakt">
            <div class="section-heading">
                <h2 id="naslov-kontakt">Predloži igru ili piši</h2>
                <p>Pošalji predlog za katalog ili nam se javi.</p>
            </div>
            <?php echo dnevne_igrice_render_contact($contact_id); ?>
        </section>
    <?php endif; ?>
    <?php endif; ?>
</main>
<footer class="wrap footer">
    <a class="brand footer-brand" href="<?php echo esc_url($home); ?>">
        <span class="brand-mark" aria-hidden="true"><i></i><i></i><i></i><i></i></span>
        Dnevne igre
    </a>
    <nav class="footer-links" aria-label="Podnožje">
        <?php if ($contact_available) : ?><a href="<?php echo esc_url(($catalogue_page ? '' : $home) . '#kontakt'); ?>">Kontakt</a><?php endif; ?>
        <?php if ($privacy_url) : ?><a href="<?php echo esc_url($privacy_url); ?>">Politika privatnosti</a><?php endif; ?>
    </nav>
    <a class="footer-author" href="https://cvjetan.dev/" aria-label="Đorđe Cvjetan, cvjetan.dev">
        <span class="footer-author-mark" aria-hidden="true"></span>
        <span>cvjetan.dev</span>
    </a>
</footer>
<?php wp_footer(); ?>
</body>
</html>
