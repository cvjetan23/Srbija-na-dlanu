<?php
defined('ABSPATH') || exit;

function dnevne_igrice_categories() {
    return array(
        'reci' => array('Reči i enigmatika', 'Aa'),
        'geografija' => array('Geografija', '◎'),
        'logika' => array('Logika', '◈'),
        'kvizovi' => array('Kvizovi', '?'),
        'brojevi' => array('Brojevi', '×'),
        'istorija' => array('Istorija', '◷'),
        'sah' => array('Šah', '♞'),
    );
}

function dnevne_igrice_game_choices() {
    return array(
        'category' => array_map(function ($category) { return $category[0]; }, dnevne_igrice_categories()),
        'status' => array('dnevna' => 'Dnevna igra', 'provera' => 'Za proveru', 'uskoro' => 'Najavljena', 'nedostupno' => 'Nedostupan link'),
        'platform' => array('pregledac' => 'Pregledač', 'aplikacija' => 'Aplikacija'),
    );
}

function dnevne_igrice_default_games() {
    return json_decode(file_get_contents(__DIR__ . '/data/catalogue.json'), true);
}

function dnevne_igrice_register_games() {
    register_post_type('di_game', array(
        'labels' => array(
            'name' => 'Dnevne igre',
            'singular_name' => 'Dnevna igra',
            'add_new' => 'Dodaj igru',
            'add_new_item' => 'Dodaj dnevnu igru',
            'edit_item' => 'Izmeni igru',
            'all_items' => 'Sve igre',
            'search_items' => 'Pretraži igre',
            'not_found' => 'Nema pronađenih igara.',
            'not_found_in_trash' => 'Korpa je prazna.',
        ),
        'public' => false,
        'show_ui' => true,
        'menu_icon' => 'dashicons-games',
        'supports' => array('title'),
        'capabilities' => array_fill_keys(array(
            'create_posts', 'edit_posts', 'edit_others_posts', 'edit_post',
            'delete_posts', 'delete_post', 'publish_posts', 'read_post', 'read_private_posts',
        ), 'manage_options'),
        'map_meta_cap' => false,
        'rewrite' => false,
    ));
}
add_action('init', 'dnevne_igrice_register_games');

function dnevne_igrice_import_games() {
    if (get_option('dnevne_igrice_catalogue_imported')) {
        return;
    }
    $lock = 'dnevne_igrice_catalogue_import_lock';
    $locked_at = (int) get_option($lock);
    if ($locked_at && time() - $locked_at > 300) {
        delete_option($lock);
    }
    if (!add_option($lock, time(), '', false)) {
        return;
    }
    try {
        $existing = get_posts(array(
            'post_type' => 'di_game',
            'post_status' => array('publish', 'draft', 'pending', 'private', 'trash'),
            'posts_per_page' => -1,
        ));
        $imported = array();
        foreach ($existing as $post) {
            $id = get_post_meta($post->ID, '_di_seed_id', true);
            if ($id) {
                $imported[$id] = true;
            }
        }
        foreach (dnevne_igrice_default_games() as $game) {
            $id = $game['id'];
            if (isset($imported[$id])) {
                continue;
            }
            $details = array_intersect_key($game, array_flip(array('url', 'provider', 'description', 'category', 'status', 'platform')));
            $post_id = wp_insert_post(wp_slash(array(
                'post_type' => 'di_game',
                'post_status' => 'publish',
                'post_title' => $game['name'],
                'menu_order' => $id,
                'meta_input' => array('_di_seed_id' => $id, '_di_game_details' => $details),
            )), true);
            if (!$post_id || is_wp_error($post_id)) {
                return;
            }
        }
        update_option('dnevne_igrice_catalogue_imported', true, false);
    } finally {
        delete_option($lock);
    }
}

function dnevne_igrice_initialize_admin_catalogue() {
    $screen = get_current_screen();
    if ($screen && $screen->post_type === 'di_game' && current_user_can('manage_options')) {
        dnevne_igrice_import_games();
    }
}
add_action('load-edit.php', 'dnevne_igrice_initialize_admin_catalogue');
add_action('load-post-new.php', 'dnevne_igrice_initialize_admin_catalogue');

function dnevne_igrice_external_games() {
    if (!get_option('dnevne_igrice_catalogue_imported')) {
        return dnevne_igrice_default_games();
    }
    $posts = get_posts(array(
        'post_type' => 'di_game',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'orderby' => array('menu_order' => 'ASC', 'ID' => 'DESC'),
    ));
    $categories = dnevne_igrice_categories();
    $games = array();
    foreach ($posts as $post) {
        $details = get_post_meta($post->ID, '_di_game_details', true);
        if (!is_array($details) || empty($details['url']) || !isset($categories[$details['category'] ?? ''])) {
            continue;
        }
        $seed_id = get_post_meta($post->ID, '_di_seed_id', true);
        $games[] = array_merge($details, array(
            'id' => $seed_id ? (int) $seed_id : 'wp-' . $post->ID,
            'name' => $post->post_title,
        ));
    }
    return $games;
}

function dnevne_igrice_games() {
    $games = array();
    $registered = DI_Game_Hub::games();
    $matched = array();
    foreach (dnevne_igrice_external_games() as $game) {
        $slug = DI_Game_Hub::match_url($game['url'], $registered);
        if ($slug) {
            $matched[$slug] = true;
            if (DI_Game_Hub::status($slug) !== 'active') {
                continue;
            }
            $game['url'] = $registered[$slug]['url'];
            $game['status'] = 'dnevna';
        }
        $games[] = $game;
    }
    foreach ($registered as $slug => $game) {
        if (isset($matched[$slug]) || DI_Game_Hub::status($slug) !== 'active') {
            continue;
        }
        $games[] = array(
            'id' => 'native-' . $slug,
            'name' => $game['name'], 'url' => $game['url'],
            'description' => $game['description'], 'provider' => 'Dnevne igre',
            'category' => $game['category'], 'status' => 'dnevna',
            'platform' => 'pregledac',
        );
    }
    return $games;
}

add_action('add_meta_boxes_di_game', function () {
    add_meta_box('di-game-details', 'Podaci o igri', 'dnevne_igrice_game_editor', 'di_game', 'normal', 'high');
});

function dnevne_igrice_game_editor($post) {
    $details = get_post_meta($post->ID, '_di_game_details', true) ?: array();
    wp_nonce_field('di_save_game', 'di_game_nonce');
    ?>
    <p><label for="di-url"><strong>Link do igre</strong></label><br>
        <input name="di_game[url]" id="di-url" class="large-text" type="text" inputmode="url" required value="<?php echo esc_attr($details['url'] ?? ''); ?>" placeholder="https://…">
    </p>
    <p><label for="di-provider"><strong>Autor ili izdavač</strong></label><br>
        <input name="di_game[provider]" id="di-provider" class="regular-text" type="text" required value="<?php echo esc_attr($details['provider'] ?? ''); ?>">
    </p>
    <p><label for="di-description"><strong>Kratak opis</strong></label><br>
        <textarea name="di_game[description]" id="di-description" class="large-text" rows="3" required><?php echo esc_textarea($details['description'] ?? ''); ?></textarea>
    </p>
    <?php
    $labels = array('category' => 'Kategorija', 'status' => 'Status igre', 'platform' => 'Platforma');
    foreach (dnevne_igrice_game_choices() as $field => $choices) : ?>
        <p><label for="di-<?php echo esc_attr($field); ?>"><strong><?php echo esc_html($labels[$field]); ?></strong></label><br>
            <select name="di_game[<?php echo esc_attr($field); ?>]" id="di-<?php echo esc_attr($field); ?>">
                <?php foreach ($choices as $value => $name) : ?>
                    <option value="<?php echo esc_attr($value); ?>" <?php selected($details[$field] ?? '', $value); ?>><?php echo esc_html($name); ?></option>
                <?php endforeach; ?>
            </select>
        </p>
    <?php endforeach;
}

function dnevne_igrice_game_url($input) {
    $url = trim($input);
    $parts = wp_parse_url($url);
    if (!$parts || strpbrk($url, "\r\n\t\\") !== false) {
        return '';
    }
    if (strpos($url, '/') === 0 && strpos($url, '//') !== 0) {
        return esc_url_raw($url);
    }
    if (empty($parts['host']) || empty($parts['scheme']) || isset($parts['user']) || isset($parts['pass'])) {
        return '';
    }
    return esc_url_raw($url, array('http', 'https'));
}

function dnevne_igrice_save_game($post_id) {
    if (!isset($_POST['di_game_nonce'], $_POST['di_game']) || !is_string($_POST['di_game_nonce']) || !is_array($_POST['di_game'])
        || !current_user_can('edit_post', $post_id) || wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)
        || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['di_game_nonce'])), 'di_save_game')) {
        return;
    }
    $input = array_filter(wp_unslash($_POST['di_game']), 'is_string');
    $details = array(
        'url' => dnevne_igrice_game_url($input['url'] ?? ''),
        'provider' => sanitize_text_field($input['provider'] ?? ''),
        'description' => sanitize_textarea_field($input['description'] ?? ''),
    );
    foreach (dnevne_igrice_game_choices() as $field => $choices) {
        $value = sanitize_key($input[$field] ?? '');
        $details[$field] = isset($choices[$value]) ? $value : array_key_first($choices);
    }
    if ($details['url'] === '' || $details['provider'] === '' || $details['description'] === '') {
        add_filter('redirect_post_location', function ($url) {
            return add_query_arg('di_game_error', '1', $url);
        });
        return;
    }
    update_post_meta($post_id, '_di_game_details', wp_slash($details));
}
add_action('save_post_di_game', 'dnevne_igrice_save_game');

add_action('admin_notices', function () {
    $screen = get_current_screen();
    if ($screen && $screen->post_type === 'di_game' && isset($_GET['di_game_error'])) {
        echo '<div class="notice notice-error"><p>Podaci o igri nisu sačuvani. Unesi ispravan link, autora i kratak opis.</p></div>';
    }
});

add_filter('enter_title_here', function ($placeholder, $post) {
    return $post->post_type === 'di_game' ? 'Naziv igre' : $placeholder;
}, 10, 2);

add_filter('manage_di_game_posts_columns', function ($columns) {
    return array_intersect_key($columns, array('cb' => true, 'title' => true)) + array(
        'di_category' => 'Kategorija', 'di_status' => 'Status igre', 'di_url' => 'Link',
    );
});

add_action('manage_di_game_posts_custom_column', function ($column, $post_id) {
    $details = get_post_meta($post_id, '_di_game_details', true);
    if (!$details) {
        return;
    }
    if ($column === 'di_url') {
        $url = $details['url'];
        $link = dnevne_igrice_game_link($url);
        printf('<a href="%s" target="_blank" rel="noopener noreferrer">%s</a>', esc_url($link), esc_html($url));
    } elseif ($column === 'di_category') {
        echo esc_html(dnevne_igrice_categories()[$details['category']][0] ?? '');
    } elseif ($column === 'di_status') {
        echo esc_html(dnevne_igrice_game_choices()['status'][$details['status']] ?? '');
    }
}, 10, 2);
