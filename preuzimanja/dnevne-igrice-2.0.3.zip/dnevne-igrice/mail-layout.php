<?php
defined('ABSPATH') || exit;

$action_url = !empty($content['action']) ? esc_url($content['url'] ?? '') : '';
?>
<!doctype html>
<html lang="<?php echo esc_attr($content['lang'] ?? 'sr-Latn'); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo esc_html($content['heading']); ?> | Dnevne igre</title>
</head>
<body style="margin:0;padding:0;background:#f5f1fa;color:#241737;font-family:Arial,sans-serif">
<?php if (!empty($content['preview'])) : ?>
    <div style="display:none;max-height:0;max-width:0;overflow:hidden;opacity:0;mso-hide:all;color:transparent"><?php echo esc_html($content['preview']); ?></div>
<?php endif; ?>
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" bgcolor="#f5f1fa" style="background:#f5f1fa">
    <tr><td align="center" style="padding:24px 10px">
        <!--[if mso]><table role="presentation" width="580" cellspacing="0" cellpadding="0"><tr><td><![endif]-->
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" bgcolor="#ffffff" style="max-width:580px;table-layout:fixed;background:#ffffff;border:1px solid #e5ddef;border-radius:20px">
            <tr><td bgcolor="#261647" style="padding:24px 24px 28px;border-radius:19px 19px 0 0;background:#261647;background-image:linear-gradient(123deg,#231645,#412057);color:#ffffff">
                <table role="presentation" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="padding-right:10px"><img src="<?php echo esc_url($logo); ?>" width="40" height="40" alt="" style="display:block;width:40px;height:40px;border:0"></td>
                        <td><a href="<?php echo esc_url($home); ?>" style="color:#ffffff;text-decoration:none;font-size:20px;font-weight:bold">Dnevne igre</a></td>
                    </tr>
                </table>
                <p style="margin:25px 0 7px;color:#e3fb8d;font-size:14px;font-weight:bold;line-height:1.35"><?php echo esc_html($content['eyebrow']); ?></p>
                <h1 style="margin:0;color:#ffffff;font-size:32px;font-weight:bold;line-height:1.15;word-wrap:break-word;overflow-wrap:anywhere"><?php echo esc_html($content['heading']); ?></h1>
            </td></tr>
            <tr><td style="padding:25px 24px;color:#443652;font-size:16px;line-height:1.6;word-wrap:break-word;overflow-wrap:anywhere">
                <?php echo $content['body']; // Generated markup or the existing Contact Form 7 mail body. ?>
                <?php if ($action_url) : ?>
                    <table role="presentation" cellspacing="0" cellpadding="0" style="margin-top:20px;max-width:100%">
                        <tr><td bgcolor="#e3fb8d" style="border-radius:10px;background:#e3fb8d;mso-padding-alt:12px 18px">
                            <a href="<?php echo $action_url; ?>" style="display:inline-block;padding:12px 18px;color:#241737;font-size:16px;font-weight:bold;line-height:1.35;text-decoration:none;mso-padding-alt:0"><?php echo esc_html($content['action']); ?></a>
                        </td></tr>
                    </table>
                    <p style="margin:20px 0 3px;color:#574b65;font-size:13px;line-height:1.45"><?php echo esc_html($content['fallback']); ?></p>
                    <p style="margin:0;font-size:13px;line-height:1.45"><a href="<?php echo $action_url; ?>" style="color:#592cc5;word-break:break-all"><?php echo esc_html($content['url']); ?></a></p>
                <?php endif; ?>
                <?php if (!empty($content['note'])) : ?>
                    <p style="margin:21px 0 0;padding-top:14px;border-top:1px solid #e5ddef;color:#574b65;font-size:14px;line-height:1.5"><?php echo esc_html($content['note']); ?></p>
                <?php endif; ?>
            </td></tr>
            <tr><td bgcolor="#faf7ff" style="padding:14px 24px;border-top:1px solid #e5ddef;border-radius:0 0 19px 19px;background:#faf7ff">
                <a href="<?php echo esc_url($home); ?>" style="color:#592cc5;font-size:14px;font-weight:bold;text-decoration:underline">dnevneigre.rs</a>
            </td></tr>
        </table>
        <!--[if mso]></td></tr></table><![endif]-->
    </td></tr>
</table>
</body>
</html>
