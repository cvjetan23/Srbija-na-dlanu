<?php
defined('ABSPATH') || exit;

function dnevne_igrice_seo_defaults() {
    if (is_page(dnevne_igrice_page_id())) {
        return array(
            'title' => 'Dnevne igre – novi kvizovi, sudoku i igre reči',
            'social_title' => 'Dnevne igre – novi izazov svaki dan',
            'description' => 'Svaki dan te čeka nova zagonetka. Pogodi reč, reši sudoku ili isprobaj kviz iz geografije i umetnosti. Izaberi igru i zaigraj u pregledaču.',
            'image' => 'share-dnevne-igre.jpg',
        );
    }
    if (is_privacy_policy()) {
        return array(
            'title' => 'Politika privatnosti | Dnevne igre',
            'description' => 'Saznaj gde se čuvaju omiljene igre i izbor teme, kako se koriste podaci iz kontakt forme i kako da postaviš pitanje o privatnosti.',
            'image' => 'share-privatnost.jpg',
        );
    }
    if (is_page('style-guide')) {
        return array(
            'title' => 'Vodič za stil | Dnevne igre',
            'description' => 'Pogledaj paletu boja za svetlu i tamnu temu, tipografiju, dugmad i kartice, uz smernice za mobilni prikaz i pristupačnost sajta Dnevne igre.',
            'image' => 'share-vodic.jpg',
        );
    }
    return array();
}

function dnevne_igrice_share_image() {
    $defaults = dnevne_igrice_seo_defaults();
    return plugins_url('assets/' . ($defaults['image'] ?? 'share-dnevne-igre.jpg'), __FILE__);
}

function dnevne_igrice_yoast_description($description) {
    if (is_page(dnevne_igrice_page_id())) {
        return dnevne_igrice_seo_defaults()['description'];
    }
    return $description ?: (dnevne_igrice_seo_defaults()['description'] ?? '');
}
add_filter('wpseo_metadesc', 'dnevne_igrice_yoast_description');
add_filter('slim_seo_meta_description', 'dnevne_igrice_yoast_description');

add_filter('slim_seo_meta_title', function ($title) {
    return dnevne_igrice_seo_defaults()['title'] ?? $title;
});

add_filter('slim_seo_open_graph_title', function ($title) {
    $defaults = dnevne_igrice_seo_defaults();
    return $defaults['social_title'] ?? $defaults['title'] ?? $title;
});

foreach (array('image', 'image_width', 'image_height') as $property) {
    add_filter('slim_seo_open_graph_' . $property, static function ($value) use ($property) {
        if (!dnevne_igrice_seo_defaults()) {
            return $value;
        }
        $values = array('image' => dnevne_igrice_share_image(), 'image_width' => 1200, 'image_height' => 630);
        return $values[$property];
    });
}

add_filter('slim_seo_twitter_card_image', function ($image) {
    return dnevne_igrice_seo_defaults() ? dnevne_igrice_share_image() : $image;
});

add_filter('wpseo_opengraph_desc', function ($description, $presentation) {
    if (is_page(dnevne_igrice_page_id())) {
        return dnevne_igrice_seo_defaults()['description'];
    }
    if (empty($presentation->model->open_graph_description)) {
        return dnevne_igrice_seo_defaults()['description'] ?? $description;
    }
    return $description;
}, 10, 2);

add_filter('wpseo_opengraph_title', function ($title, $presentation) {
    if (is_page(dnevne_igrice_page_id())) {
        return dnevne_igrice_seo_defaults()['social_title'];
    }
    if (is_404()) {
        return 'Stranica nije pronađena | Dnevne igre';
    }
    if (is_search()) {
        return sprintf('Pretraga za „%s“ | Dnevne igre', get_search_query(false));
    }
    if (empty($presentation->model->open_graph_title)) {
        $defaults = dnevne_igrice_seo_defaults();
        return $defaults['social_title'] ?? $defaults['title'] ?? $title;
    }
    return $title;
}, 10, 2);

add_filter('wpseo_title', function ($title, $presentation) {
    if (is_page(dnevne_igrice_page_id())) {
        return dnevne_igrice_seo_defaults()['title'];
    }
    if (is_404()) {
        return 'Stranica nije pronađena | Dnevne igre';
    }
    if (is_search()) {
        return sprintf('Pretraga za „%s“ | Dnevne igre', get_search_query(false));
    }
    if (empty($presentation->model->title)) {
        return dnevne_igrice_seo_defaults()['title'] ?? $title;
    }
    return $title;
}, 10, 2);

add_filter('wpseo_add_opengraph_images', function ($images) {
    if (dnevne_igrice_seo_defaults() && !get_post_meta(get_queried_object_id(), '_yoast_wpseo_opengraph-image', true)) {
        $images->add_image(array('url' => dnevne_igrice_share_image(), 'width' => 1200, 'height' => 630, 'type' => 'image/jpeg'));
    }
    return $images;
});

add_filter('wpseo_twitter_image', function ($image) {
    if (dnevne_igrice_seo_defaults() && !get_post_meta(get_queried_object_id(), '_yoast_wpseo_twitter-image', true)) {
        return get_post_meta(get_queried_object_id(), '_yoast_wpseo_opengraph-image', true) ?: dnevne_igrice_share_image();
    }
    return $image;
});

add_filter('wpseo_twitter_card_type', function ($type) {
    return dnevne_igrice_seo_defaults() ? 'summary_large_image' : $type;
});

add_filter('wpseo_opengraph_type', function ($type) {
    return dnevne_igrice_seo_defaults() ? 'website' : $type;
});

add_filter('wpseo_robots_array', function ($robots) {
    if (is_page('style-guide')) {
        $robots['index'] = 'noindex';
    }
    return $robots;
});

add_filter('wpseo_exclude_from_sitemap_by_post_ids', function ($ids) {
    $guide = get_page_by_path('style-guide');
    if ($guide) {
        $ids[] = $guide->ID;
    }
    return $ids;
});

add_filter('wpseo_schema_graph', function ($graph) {
    if (wp_parse_url(home_url('/'), PHP_URL_HOST) !== 'dnevneigre.rs') {
        return $graph;
    }
    $defaults = dnevne_igrice_seo_defaults();
    $canonical = wp_get_canonical_url();
    foreach ($graph as &$node) {
        if (isset($node['inLanguage'])) {
            $node['inLanguage'] = 'sr-Latn';
        }
        if ($defaults && $canonical && ($node['url'] ?? '') === $canonical
            && array_intersect((array) $node['@type'], array('WebPage', 'CollectionPage'))) {
            $node['name'] = html_entity_decode(wp_get_document_title(), ENT_QUOTES, 'UTF-8');
            $node['description'] = is_page(dnevne_igrice_page_id()) ? $defaults['description'] : ($node['description'] ?? $defaults['description']);
        }
    }
    return $graph;
});
