<?php
defined('ABSPATH') || exit;

function dnevne_igrice_mail_layout($content) {
    $home = get_permalink(dnevne_igrice_page_id()) ?: home_url('/');
    $logo = plugins_url('assets/favicon.png', __FILE__);
    ob_start();
    require __DIR__ . '/mail-layout.php';
    return trim(ob_get_clean());
}

function dnevne_igrice_mail_paragraph($text) {
    return '<p style="margin:0;line-height:1.6">' . esc_html($text) . '</p>';
}

function dnevne_igrice_game_mail_request() {
    return !dnevne_igrice_is_legacy_site() && class_exists('SND_Site') && SND_Site::view() === 'login';
}

function dnevne_igrice_game_mail_copy($type) {
    $copy = array(
        'sr' => array(
            'fallback' => 'Ako dugme ne radi, otvori ovu adresu.',
            'welcome' => array(
                'subject' => 'Dnevne igre | Nalog za Srbiju na dlanu',
                'heading' => 'Tvoj nalog je spreman',
                'preview' => 'Postavi lozinku i sačuvaj rezultate u igri Srbija na dlanu.',
                'text' => 'Postavi lozinku za nalog „{login}“ i možeš da čuvaš rezultate i nastaviš igru na drugom uređaju.',
                'action' => 'Postavi lozinku',
                'note' => 'Ako ti je ovaj mejl stigao greškom, slobodno ga zanemari.',
            ),
            'reset' => array(
                'subject' => 'Dnevne igre | Promena lozinke',
                'heading' => 'Postavi novu lozinku',
                'preview' => 'Link za obnovu pristupa nalogu u igri Srbija na dlanu.',
                'text' => 'Primili smo zahtev za novu lozinku za nalog „{login}“ u igri Srbija na dlanu.',
                'action' => 'Izaberi novu lozinku',
                'note' => 'Ako zahtev nije tvoj, zanemari ovaj mejl. Tvoja lozinka ostaje ista.',
            ),
        ),
        'en' => array(
            'fallback' => 'If the button does not work, open this address.',
            'welcome' => array(
                'subject' => 'Dnevne igre | Your Srbija na dlanu account',
                'heading' => 'Your account is ready',
                'preview' => 'Set a password to save your results in Srbija na dlanu.',
                'text' => 'Set a password for “{login}” so you can save your results and keep playing on another device.',
                'action' => 'Set a password',
                'note' => 'If you received this email by mistake, you can ignore it.',
            ),
            'reset' => array(
                'subject' => 'Dnevne igre | Reset your password',
                'heading' => 'Set a new password',
                'preview' => 'Use this link to regain access to your Srbija na dlanu account.',
                'text' => 'We received a password reset request for your Srbija na dlanu account “{login}”.',
                'action' => 'Choose a new password',
                'note' => 'If you did not request this, ignore this email. Your password will stay the same.',
            ),
        ),
        'de' => array(
            'fallback' => 'Falls die Schaltfläche nicht funktioniert, öffne diese Adresse.',
            'welcome' => array(
                'subject' => 'Dnevne igre | Dein Konto für Srbija na dlanu',
                'heading' => 'Dein Konto ist bereit',
                'preview' => 'Lege ein Passwort fest, um deine Ergebnisse in Srbija na dlanu zu speichern.',
                'text' => 'Lege ein Passwort für „{login}“ fest, damit du deine Ergebnisse speichern und auf einem anderen Gerät weiterspielen kannst.',
                'action' => 'Passwort festlegen',
                'note' => 'Wenn du diese E-Mail versehentlich erhalten hast, kannst du sie ignorieren.',
            ),
            'reset' => array(
                'subject' => 'Dnevne igre | Passwort zurücksetzen',
                'heading' => 'Lege ein neues Passwort fest',
                'preview' => 'Mit diesem Link erhältst du wieder Zugriff auf dein Konto für Srbija na dlanu.',
                'text' => 'Wir haben eine Anfrage erhalten, das Passwort für dein Konto „{login}“ in Srbija na dlanu zurückzusetzen.',
                'action' => 'Neues Passwort wählen',
                'note' => 'Falls die Anfrage nicht von dir stammt, ignoriere diese E-Mail. Dein Passwort bleibt unverändert.',
            ),
        ),
        'ru' => array(
            'fallback' => 'Если кнопка не работает, откройте этот адрес.',
            'welcome' => array(
                'subject' => 'Dnevne igre | Ваш аккаунт в игре Srbija na dlanu',
                'heading' => 'Ваш аккаунт готов',
                'preview' => 'Создайте пароль, чтобы сохранять результаты в игре Srbija na dlanu.',
                'text' => 'Создайте пароль для аккаунта «{login}», чтобы сохранять результаты и продолжать игру на другом устройстве.',
                'action' => 'Создать пароль',
                'note' => 'Если вы получили это письмо по ошибке, просто проигнорируйте его.',
            ),
            'reset' => array(
                'subject' => 'Dnevne igre | Сброс пароля',
                'heading' => 'Установите новый пароль',
                'preview' => 'По этой ссылке можно восстановить доступ к аккаунту в игре Srbija na dlanu.',
                'text' => 'Мы получили запрос на сброс пароля для аккаунта «{login}» в игре Srbija na dlanu.',
                'action' => 'Выбрать новый пароль',
                'note' => 'Если вы не отправляли запрос, проигнорируйте это письмо. Ваш пароль останется прежним.',
            ),
        ),
    );
    $language = SND_I18n::lang();
    $localized = $copy[$language] ?? $copy['sr'];
    return $localized[$type] + array('fallback' => $localized['fallback'], 'lang' => SND_I18n::html_lang());
}

function dnevne_igrice_mail_message($email, $content) {
    $headers = $email['headers'] ?? array();
    if (is_string($headers)) {
        $headers = preg_split('/\r\n|\r|\n/', trim($headers), -1, PREG_SPLIT_NO_EMPTY);
    }
    $email['headers'] = array_values(array_filter((array) $headers, static function ($header) {
        return stripos(ltrim($header), 'Content-Type:') !== 0;
    }));
    $email['headers'][] = 'Content-Type: text/html; charset=UTF-8';
    $email['subject'] = $content['subject'];
    $email['message'] = dnevne_igrice_mail_layout($content);
    return $email;
}

function dnevne_igrice_account_mail($email, $type, $login, $key) {
    $copy = dnevne_igrice_game_mail_copy($type);
    $copy['eyebrow'] = 'Srbija na dlanu';
    $copy['body'] = dnevne_igrice_mail_paragraph(str_replace('{login}', $login, $copy['text']));
    $copy['url'] = add_query_arg(array('mode' => 'reset', 'key' => rawurlencode($key), 'login' => rawurlencode($login)), SND_Site::url('login'));
    return dnevne_igrice_mail_message($email, $copy);
}

add_filter('retrieve_password_notification_email', static function ($email, $key, $login) {
    return dnevne_igrice_game_mail_request()
        ? dnevne_igrice_account_mail($email, 'reset', $login, $key) : $email;
}, 20, 3);

add_filter('wp_new_user_notification_email', static function ($email, $user) {
    if (!dnevne_igrice_game_mail_request()) {
        return $email;
    }
    preg_match_all('~https?://[^\s<>]+~', $email['message'], $matches);
    foreach ($matches[0] as $link) {
        parse_str(wp_parse_url(html_entity_decode($link, ENT_QUOTES, 'UTF-8'), PHP_URL_QUERY) ?: '', $query);
        if (($query['mode'] ?? '') !== 'reset' || ($query['login'] ?? '') !== $user->user_login
            || !is_string($query['key'] ?? null) || $query['key'] === '') {
            continue;
        }
        return dnevne_igrice_account_mail($email, 'welcome', $user->user_login, $query['key']);
    }
    return $email;
}, 20, 2);

add_filter('wp_password_change_notification_email', static function ($email, $user) {
    if (!dnevne_igrice_game_mail_request()) {
        return $email;
    }
    return dnevne_igrice_mail_message($email, array(
        'subject' => 'Dnevne igre | Ažurirana lozinka naloga',
        'heading' => 'Lozinka naloga je ažurirana',
        'eyebrow' => 'Obaveštenje za administraciju',
        'preview' => 'Obaveštenje o postavljanju lozinke za nalog u igri Srbija na dlanu.',
        'body' => dnevne_igrice_mail_paragraph(sprintf('Za nalog „%s“ postavljena je nova lozinka preko stranice za prijavu u igru Srbija na dlanu.', $user->user_login)),
    ));
}, 20, 2);

function dnevne_igrice_contact_mail($form, $abort, $submission) {
    if ($abort || dnevne_igrice_is_legacy_site() || !dnevne_igrice_own_submission($submission)) {
        return;
    }
    $mail = $form->prop('mail');
    if (empty($mail['body'])) {
        return;
    }
    $default_body = dnevne_igrice_contact_message_template();
    $saved_body = str_replace(array("\r\n", "\r"), "\n", trim($mail['body']));
    // Older versions could save their rendered default body during a form update.
    $old_default = strpos($saved_body, '<h1') !== false && strpos($saved_body, 'Nova poruka sa sajta') !== false
        && strpos($saved_body, nl2br(esc_html($default_body), false)) !== false;
    $proposal = $submission->get_posted_string('di-purpose') === 'Predlog nove igre';
    if ($saved_body === $default_body || $old_default) {
        $rows = '<p style="margin:0 0 5px"><strong>Pošiljalac</strong> &nbsp;[di-name]</p>' . "\n"
            . '<p style="margin:0"><strong>E-pošta</strong> &nbsp;[di-email]</p>';
        if ($proposal) {
            $rows .= "\n" . '<p style="margin:12px 0 5px"><strong>Igra</strong> &nbsp;[di-game-name]</p>'
                . "\n" . '<p style="margin:0"><strong>Link</strong> &nbsp;[di-game-url]</p>';
        }
        $body = '<div style="margin:0 0 24px;padding:14px 16px;background:#f5effb;border-radius:10px;line-height:1.5">' . $rows . '</div>'
            . '<h2 style="margin:0 0 8px;font-size:16px;color:#241737">Poruka</h2>' . "\n"
            . '<div style="white-space:pre-wrap">[di-message]</div>';
    } else {
        if (!empty($mail['use_html']) && preg_match('~<html[>\s]~i', $saved_body)) {
            return;
        }
        $body = !empty($mail['use_html']) ? $saved_body : nl2br(esc_html($saved_body), false);
    }
    $heading = $proposal ? 'Predlog za katalog' : 'Poruka iz kontakt forme';
    if ($mail['subject'] === '[di-purpose] | Dnevne igre') {
        $mail['subject'] = 'Dnevne igre | ' . $heading;
    }
    $mail['body'] = dnevne_igrice_mail_layout(array(
        'heading' => $heading,
        'eyebrow' => 'Kontakt forma',
        'preview' => $proposal ? 'Stigao je novi predlog igre za katalog.' : 'Stigla je nova poruka sa dnevneigre.rs.',
        'body' => $body,
        'note' => stripos($mail['additional_headers'] ?? '', 'Reply-To:') !== false
            ? 'Odgovori na ovaj mejl da se javiš pošiljaocu.' : '',
    ));
    $mail['use_html'] = true;
    $form->set_properties(array('mail' => $mail));
}
add_action('wpcf7_before_send_mail', 'dnevne_igrice_contact_mail', 20, 3);
