<?php
defined('ABSPATH') || exit;

final class DI_Game_Dashboard {
    const SLUG = 'dnevne-igrice-nase-igre';

    public static function register() {
        if (dnevne_igrice_is_legacy_site()) {
            return;
        }
        $screen = add_submenu_page('edit.php?post_type=di_game', 'Naše igre', 'Naše igre', 'manage_options', self::SLUG, array(__CLASS__, 'render'));
        add_action('load-' . $screen, static function () {
            wp_enqueue_style('di-game-dashboard', plugins_url('assets/game-dashboard.css', __FILE__), array(), DNEVNE_IGRICE_VERSION);
        });
    }

    private static function url($args = array()) {
        return add_query_arg(array('post_type'=>'di_game', 'page'=>self::SLUG) + $args, admin_url('edit.php'));
    }

    private static function period($value) {
        return is_scalar($value) && in_array((string) $value, array('1','7','30','90'), true) ? (int) $value : 7;
    }

    public static function save() {
        if (!current_user_can('manage_options') || dnevne_igrice_is_legacy_site()) {
            wp_die('Nedovoljne dozvole.', '', array('response'=>403));
        }
        $game = isset($_POST['game']) && is_string($_POST['game']) ? sanitize_key(wp_unslash($_POST['game'])) : '';
        check_admin_referer('di_save_game_status_' . $game);
        $status = isset($_POST['status']) && is_string($_POST['status']) ? sanitize_key(wp_unslash($_POST['status'])) : '';
        $games = DI_Game_Hub::games();
        if (!isset($games[$game], DI_Game_Hub::STATUSES[$status])) {
            wp_die('Nepoznata igra ili status.', '', array('response'=>400));
        }
        if ($status !== DI_Game_Hub::status($game)) {
            update_option(DI_Game_Hub::STATUS_OPTION . '_' . $game, $status, false);
            clean_post_cache($games[$game]['page_id']);
            do_action('dnevne_igrice_game_status_changed', $game, $status);
        }
        wp_safe_redirect(self::url(array('days'=>self::period($_POST['days'] ?? null), 'saved'=>$game)));
        exit;
    }

    private static function percent($finished, $started) {
        return $started ? number_format_i18n(100 * $finished / $started, 1) . '%' : '—';
    }

    public static function render() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $guide = ($_GET['tab'] ?? '') === 'obrazac';
        ?>
        <div class="wrap di-admin-hub">
            <header class="di-admin-hero">
                <div class="di-admin-heading">
                    <img src="<?php echo esc_url(plugins_url('assets/favicon.png', __FILE__)); ?>" alt="" width="46" height="46">
                    <div><h1>Naše igre</h1><p>Objave i partije autorskih igara na dnevneigre.rs.</p></div>
                </div>
            </header>
            <hr class="wp-header-end">
            <nav class="di-admin-tabs" aria-label="Naše igre">
                <a href="<?php echo esc_url(self::url()); ?>"<?php if (!$guide) : ?> aria-current="page"<?php endif; ?>>Igre i analitika</a>
                <a href="<?php echo esc_url(self::url(array('tab'=>'obrazac'))); ?>"<?php if ($guide) : ?> aria-current="page"<?php endif; ?>>Obrazac za novu igru</a>
            </nav>
            <?php if ($guide) {
                require __DIR__ . '/game-guide.php';
            } else {
                self::render_games();
            } ?>
        </div>
        <?php
    }

    private static function render_games() {
        $games = DI_Game_Hub::games();
        $days = self::period($_GET['days'] ?? null);
        $stats = DI_Game_Stats::all($days);
        $started = $finished = 0;
        foreach ($games as $slug=>$game) {
            $started += (int) ($stats[$slug]->started ?? 0);
            $finished += (int) ($stats[$slug]->finished ?? 0);
        }
        $last_saved = isset($_GET['saved']) && is_string($_GET['saved']) ? sanitize_key(wp_unslash($_GET['saved'])) : '';
        ?>
        <?php if (isset($games[$last_saved])) : ?>
            <p class="di-admin-notice" role="status"><?php echo esc_html('Status igre „' . $games[$last_saved]['name'] . '“ je sačuvan.'); ?></p>
        <?php endif; ?>
        <form class="di-admin-filter" action="<?php echo esc_url(admin_url('edit.php')); ?>" method="get">
            <input type="hidden" name="post_type" value="di_game">
            <input type="hidden" name="page" value="<?php echo esc_attr(self::SLUG); ?>">
            <label for="di-stats-days">Period</label>
            <select id="di-stats-days" name="days">
                <?php foreach (array(1=>'Danas',7=>'Poslednjih 7 dana',30=>'Poslednjih 30 dana',90=>'Poslednjih 90 dana') as $value=>$label) : ?>
                    <option value="<?php echo esc_attr($value); ?>"<?php selected($days, $value); ?>><?php echo esc_html($label); ?></option>
                <?php endforeach; ?>
            </select>
            <button class="button" type="submit">Prikaži</button>
        </form>
        <dl class="di-admin-totals">
            <div><dt>Započete partije</dt><dd><?php echo esc_html(number_format_i18n($started)); ?></dd></div>
            <div><dt>Završene partije</dt><dd><?php echo esc_html(number_format_i18n($finished)); ?></dd></div>
            <div><dt>Stopa završavanja</dt><dd><?php echo esc_html(self::percent($finished, $started)); ?></dd></div>
        </dl>
        <p class="di-admin-explainer">Završene partije se računaju među partijama započetim u izabranom periodu. Vremenska zona je Europe/Belgrade.</p>
        <div class="di-admin-table-wrap" tabindex="0" role="region" aria-label="Statusi i statistika igara">
            <table class="di-admin-table">
                <caption class="screen-reader-text">Autorske igre i broj partija</caption>
                <thead><tr><th scope="col">Igra</th><th scope="col">Započete</th><th scope="col">Završene</th><th scope="col">Nezavršene</th><th scope="col">Stopa završavanja</th><th scope="col">Status objave</th></tr></thead>
                <tbody>
                <?php foreach ($games as $slug=>$game) :
                    $status = DI_Game_Hub::status($slug);
                    $start = (int) ($stats[$slug]->started ?? 0);
                    $done = (int) ($stats[$slug]->finished ?? 0);
                    $id = 'di-game-status-' . $slug; ?>
                    <tr>
                        <th scope="row">
                            <span class="di-admin-game-name"><?php echo esc_html($game['name']); ?></span>
                            <span class="di-admin-path"><?php echo esc_html(wp_parse_url($game['url'], PHP_URL_PATH)); ?></span>
                            <?php if ($status === 'active') : ?><a href="<?php echo esc_url($game['url']); ?>" target="_blank" rel="noopener">Otvori stranicu ↗</a><?php endif; ?>
                            <?php if ($status === 'test' && $game['description']) : ?><span class="di-admin-game-description"><?php echo esc_html($game['description']); ?></span><?php endif; ?>
                        </th>
                        <td><?php echo esc_html(number_format_i18n($start)); ?></td>
                        <td><?php echo esc_html(number_format_i18n($done)); ?></td>
                        <td><?php echo esc_html(number_format_i18n(max(0, $start - $done))); ?></td>
                        <td><?php echo esc_html(self::percent($done, $start)); ?></td>
                        <td>
                            <form class="di-admin-status" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                                <input type="hidden" name="action" value="di_save_game_status">
                                <input type="hidden" name="game" value="<?php echo esc_attr($slug); ?>">
                                <input type="hidden" name="days" value="<?php echo esc_attr($days); ?>">
                                <?php wp_nonce_field('di_save_game_status_' . $slug); ?>
                                <label class="screen-reader-text" for="<?php echo esc_attr($id); ?>"><?php echo esc_html('Status igre ' . $game['name']); ?></label>
                                <select name="status" id="<?php echo esc_attr($id); ?>" data-status="<?php echo esc_attr($status); ?>">
                                    <?php foreach (DI_Game_Hub::STATUSES as $value=>$label) : ?>
                                        <option value="<?php echo esc_attr($value); ?>"<?php selected($status, $value); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="button">Sačuvaj</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$games) : ?><tr><td colspan="6">Nema registrovanih autorskih igara.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="di-admin-details">
            <section><h2>Statusi</h2><p>Aktivna igra je dostupna za igranje. Igre u testiranju i neaktivne igre vidljive su ovde administratorima. Nove igre se instaliraju kao neaktivne.</p></section>
            <section><h2>Obuhvat analitike</h2><p>Srbija na dlanu i Vukov vez koriste postojeću istoriju i njene rokove čuvanja. Za Oko kustosa i buduće igre koje koriste zajedničko beleženje brojevi počinju od uključivanja analitike. Broj partija meri aktivnost u igri. Za igre drugih autora dostupne su samo veze iz kataloga.</p></section>
        </div>
        <?php
    }
}

add_action('admin_menu', array('DI_Game_Dashboard','register'));
add_action('admin_post_di_save_game_status', array('DI_Game_Dashboard','save'));
// Initialize the management page and tables after updating an already active plugin.
add_action('admin_init', static function () {
    if (current_user_can('manage_options') && !dnevne_igrice_is_legacy_site()
        && (DI_Game_Hub::public_directory_exists() || (int) get_option(DI_Game_Stats::SCHEMA) !== 1
            || get_option(DI_Game_Hub::STATUS_OPTION, null) === null)) {
        DI_Game_Hub::install((bool) dnevne_igrice_page_id());
    }
});
