<?php
defined('ABSPATH') || exit;

final class DI_Game_Stats {
    const COOKIE = 'di_oko_play';
    const SCHEMA = 'dnevne_igrice_rounds_schema';
    const RETENTION_DAYS = 90;

    private static function table() {
        global $wpdb;
        return $wpdb->prefix . 'di_native_rounds';
    }

    public static function today() {
        return new DateTimeImmutable('today', new DateTimeZone('Europe/Belgrade'));
    }

    public static function install() {
        if ((int) get_option(self::SCHEMA) !== 1) {
            global $wpdb;
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            $table = self::table();
            $collate = $wpdb->get_charset_collate();
            dbDelta("CREATE TABLE $table (
                game_key varchar(64) NOT NULL,
                round_key char(64) NOT NULL,
                played_on date NOT NULL,
                finished tinyint(1) unsigned NOT NULL DEFAULT 0,
                PRIMARY KEY  (game_key,round_key),
                KEY game_day (game_key,played_on),
                KEY played_on (played_on)
            ) $collate;");
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) === $table) {
                update_option(self::SCHEMA, 1, false);
            }
        }
        if (!wp_next_scheduled('dnevne_igrice_rounds_cleanup')) {
            wp_schedule_event(time() + DAY_IN_SECONDS, 'daily', 'dnevne_igrice_rounds_cleanup');
        }
    }

    public static function cleanup() {
        if ((int) get_option(self::SCHEMA) !== 1) {
            return;
        }
        global $wpdb;
        $table = self::table();
        $date = self::today()->modify('-' . self::RETENTION_DAYS . ' days')->format('Y-m-d');
        $wpdb->query($wpdb->prepare("DELETE FROM $table WHERE played_on < %s", $date));
    }

    public static function record($slug, $round_id, $day, $finished) {
        $games = DI_Game_Hub::games();
        if (dnevne_igrice_is_legacy_site() || (int) get_option(self::SCHEMA) !== 1 || !isset($games[$slug])
            || $games[$slug]['source'] !== 'hub' || DI_Game_Hub::status($slug) !== 'active'
            || !is_string($round_id) || $round_id === '' || strlen($round_id) > 128
            || !is_string($day) || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/D', $day, $parts)
            || !checkdate((int) $parts[2], (int) $parts[3], (int) $parts[1])) {
            return false;
        }
        global $wpdb;
        $table = self::table();
        $round = hash_hmac('sha256', $slug . ':' . $day . ':' . $round_id, wp_salt('auth'));
        $saved = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO $table (game_key,round_key,played_on,finished) VALUES (%s,%s,%s,%d)",
            $slug, $round, $day, (int) $finished
        ));
        if ($saved === false) {
            return false;
        }
        if ($finished && !$saved) {
            return $wpdb->update($table, array('finished'=>1), array('game_key'=>$slug, 'round_key'=>$round, 'finished'=>0)) !== false;
        }
        return true;
    }

    private static function visitor() {
        $cookie = $_COOKIE[self::COOKIE] ?? '';
        if (is_string($cookie) && preg_match('/^([a-f0-9]{32})\.([a-f0-9]{64})$/D', $cookie, $parts)
            && hash_equals(hash_hmac('sha256', 'di-oko:' . $parts[1], wp_salt('auth')), $parts[2])) {
            return $parts[1];
        }
        if (headers_sent()) {
            return '';
        }
        $visitor = bin2hex(random_bytes(16));
        $cookie = $visitor . '.' . hash_hmac('sha256', 'di-oko:' . $visitor, wp_salt('auth'));
        setcookie(self::COOKIE, $cookie, array(
            'expires'=>time() + 2 * DAY_IN_SECONDS, 'path'=>wp_parse_url(home_url('/'), PHP_URL_PATH) ?: '/',
            'secure'=>is_ssl(), 'httponly'=>true, 'samesite'=>'Lax',
        ));
        $_COOKIE[self::COOKIE] = $cookie;
        return $visitor;
    }

    public static function prepare_oko() {
        if (!dnevne_igrice_is_legacy_site() && (int) get_option(self::SCHEMA) === 1
            && function_exists('oko_game_page') && oko_game_page()
            && DI_Game_Hub::status('oko-kustosa') === 'active') {
            self::visitor();
        }
    }

    public static function record_oko($response, $handler, $request) {
        if ($request->get_route() !== '/oko-kustosa/v1/odgovor' || $request->get_method() !== 'POST'
            || is_wp_error($response) || dnevne_igrice_is_legacy_site() || (int) get_option(self::SCHEMA) !== 1
            || DI_Game_Hub::status('oko-kustosa') !== 'active') {
            return $response;
        }
        $result = rest_ensure_response($response);
        $data = $result->get_data();
        if ($result->get_status() < 300 && is_array($data)
            && (isset($data['value'], $data['points']) || isset($data['answers'], $data['score']))) {
            $visitor = self::visitor();
            if ($visitor !== '') {
                self::record('oko-kustosa', $visitor, $request->get_param('day'), isset($data['answers'], $data['score']));
            }
            $result->header('Cache-Control', 'private, no-store, max-age=0');
            return $result;
        }
        return $response;
    }

    public static function all($days) {
        global $wpdb;
        $from = self::today()->modify('-' . ($days - 1) . ' days')->format('Y-m-d');
        $today = self::today()->format('Y-m-d');
        $result = array();
        $games = DI_Game_Hub::games();
        if ((int) get_option(self::SCHEMA) === 1) {
            $table = self::table();
            $result = $wpdb->get_results($wpdb->prepare(
                "SELECT game_key, COUNT(*) AS started, SUM(finished) AS finished FROM $table
                WHERE played_on >= %s AND played_on <= %s GROUP BY game_key", $from, $today
            ), OBJECT_K) ?: array();
        }
        if (isset($games['vukov-vez']) && class_exists('VV_Store') && (int) get_option('vv_schema') > 0) {
            $table = VV_Store::table('players');
            $result['vukov-vez'] = $wpdb->get_row($wpdb->prepare(
                "SELECT COUNT(*) AS started, SUM(CASE WHEN completed_at IS NOT NULL THEN 1 ELSE 0 END) AS finished
                FROM $table WHERE day >= %s AND day <= %s", $from, $today
            ));
        }
        if (class_exists('SND_Analytics') && SND_Analytics::ready()) {
            $table = SND_Analytics::games_table();
            $geographic = $wpdb->get_results($wpdb->prepare(
                "SELECT kind, COUNT(*) AS started, SUM(CASE WHEN stage = 'complete' THEN 1 ELSE 0 END) AS finished
                FROM $table WHERE played_on >= %s AND played_on <= %s GROUP BY kind", $from, $today
            ), OBJECT_K) ?: array();
            foreach (DI_Game_Hub::geographic_games() as $kind=>$game) {
                $result[$game[0]] = $geographic[$kind] ?? null;
            }
        }
        return $result;
    }
}

function dnevne_igrice_record_round($slug, $round_id, $date, $finished = false) {
    return DI_Game_Stats::record($slug, $round_id, $date, $finished);
}
add_action('template_redirect', array('DI_Game_Stats','prepare_oko'), 12);
add_action('dnevne_igrice_rounds_cleanup', array('DI_Game_Stats','cleanup'));
add_filter('rest_request_after_callbacks', array('DI_Game_Stats','record_oko'), 10, 3);

add_filter('the_content', static function ($content) {
    if (is_privacy_policy() && in_the_loop() && is_main_query() && isset(DI_Game_Hub::games()['oko-kustosa'])) {
        $content .= '<h2>Analitika igre Oko kustosa</h2><p>Nasumična oznaka pregledača važi dva dana i služi za brojanje započetih i završenih partija. Čuvamo datum i status partije do 90 dana.</p>';
    }
    return $content;
});
