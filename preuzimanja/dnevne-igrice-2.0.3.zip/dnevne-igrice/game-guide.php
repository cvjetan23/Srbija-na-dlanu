<?php
defined('ABSPATH') || exit;
?>
<section class="di-admin-guide" aria-labelledby="di-guide-title">
    <h2 id="di-guide-title">Obrazac za novu igru</h2>
    <p>Odgovori na pitanja pre izrade. Prođi kontrolnu listu pre nego što igru označiš kao aktivnu.</p>

    <details open>
        <summary>Koncept i pravila</summary>
        <ul>
            <li>Kako se igra zove, koja je njena adresa i kako se objašnjava u jednoj rečenici?</li>
            <li>Šta igrač prvo radi, šta čini jedan pokušaj i kada se partija završava?</li>
            <li>Koliko traje partija i kad stiže novi izazov po vremenu u Beogradu?</li>
            <li>Šta se dešava kada igrač zatvori stranicu, izgubi vezu ili se vrati posle promene dana?</li>
            <li>Da li su potrebni vežbanje, arhiva, nalog, rang-lista, prevodi ili drugo pismo?</li>
            <li>Ko proverava sadržaj i izvore? Kako igrač prijavljuje grešku?</li>
        </ul>
    </details>

    <details>
        <summary>Bodovanje i rezultati</summary>
        <ul>
            <li>Koliko ima pokušaja i koliko poena donose tačan, delimično tačan i pogrešan odgovor, preskok i pomoć?</li>
            <li>Koji je raspon rezultata? Kako se rešava izjednačenje ako igra ima rang-listu?</li>
            <li>Šta se prikazuje odmah posle odgovora, a šta tek po završetku?</li>
            <li>Šta se deli na kraju? Da li poruka otkriva rešenje?</li>
            <li>Šta se beleži kao početak i završetak? Da li server čuva odgovor i rezultat kada se zahtev ponovi ili igra koristi u dva taba?</li>
        </ul>
    </details>

    <details>
        <summary>Kontrolna lista za dizajn, sadržaj i SEO</summary>
        <ul>
            <li>Logo u zaglavlju i podnožju, favicon, meni, kontakt, privatnost i povratak na Dnevne igre.</li>
            <li>Slika za deljenje od 1200 × 630 px, pregled naslova, opisa i slike za deljenje.</li>
            <li>Naslov, glavni naslov, meta opis, ciljani izrazi za pretragu i kanonska adresa.</li>
            <li>Jasan sledeći korak na ekranima za uvod, učitavanje, odgovor, grešku i kraj partije.</li>
            <li>Telefon širine 320 px i desktop, tastatura, vidljiv fokus, kontrast i smanjeno kretanje.</li>
            <li>Alternativni tekst za važne slike, provereni odgovori, izvori, autori i licence.</li>
            <li>Tekst privatnosti pokriva podatke koje igra stvarno čuva.</li>
        </ul>
    </details>

    <details>
        <summary>Kontrolna lista za instalaciju, analitiku i puštanje</summary>
        <ul>
            <li>Ponovna instalacija koristi istu stranicu. Nova igra se automatski pojavljuje na kontrolnoj tabli kao neaktivna.</li>
            <li>Server bira izazov, proverava odgovore i računa poene. Rezultat ostaje stabilan pri osvežavanju i u dva taba.</li>
            <li>Na testnoj kopiji odigraj jednu celu i jednu nedovršenu partiju. Ponovo učitaj rezultat. Očekuju se dve započete i jedna završena partija.</li>
            <li>Proveri direktnu adresu, katalog i API dok je igra neaktivna i dok je u testiranju.</li>
            <li>Proveri javnu adresu, deljenje i mapu sajta po aktivaciji. Odredi ko proverava prvu objavljenu partiju i ko može da vrati neaktivan status.</li>
        </ul>
        <p>Za povezivanje igre koristi filter <code>dnevne_igre_native_games</code>. Posle serverske potvrde početka i završetka pozovi <code>dnevne_igrice_record_round()</code> sa istim identifikatorom partije i datumom izazova.</p>
    </details>
</section>
