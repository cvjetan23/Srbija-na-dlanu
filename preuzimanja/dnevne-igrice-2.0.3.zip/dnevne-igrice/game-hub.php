<?php
defined('ABSPATH') || exit;

final class DI_Game_Hub {
    const STATUSES = array('active'=>'Aktivna', 'inactive'=>'Neaktivna', 'test'=>'U testiranju');
    const STATUS_OPTION = 'dnevne_igrice_native_game_status';
    const PAGE_OPTION = 'dnevne_igrice_our_games_page';

    public static function geographic_games() {
        return array(
            'district'=>array('srbija-okruzi', 'Okruzi Srbije', 'Pogodi upravni okrug prema obrisu na karti.'),
            'municipality'=>array('srbija-opstine', 'Opštine Srbije', 'Prepoznaj opštinu prema obliku njene teritorije.'),
            'city'=>array('srbija-gradovi', 'Gradovi i naselja', 'Pronađi naselje označeno na karti.'),
            'river'=>array('srbija-reke', 'Reke Srbije', 'Prepoznaj reku prema istaknutom toku.'),
            'mountain'=>array('srbija-planine', 'Planine Srbije', 'Pogodi planinu označenu na karti.'),
        );
    }

    public static function games() {
        static $games;
        if ($games !== null) {
            return $games;
        }
        $registered = apply_filters('dnevne_igre_native_games', array());
        $games = array();
        $categories = dnevne_igrice_categories();
        foreach ($registered as $slug => $game) {
            if ($slug === 'srbija-na-dlanu' || !is_array($game) || empty($game['name'])
                || empty($game['url']) || !isset($categories[$game['category'] ?? ''])
                || !is_string($slug) || $slug !== sanitize_key($slug) || strlen($slug) > 64) {
                continue;
            }
            $page_id = (int) ($game['page_id'] ?? 0);
            if (!$page_id) {
                if ($slug === 'oko-kustosa') {
                    $page_id = (int) get_option('cvjetan_oko_kustosa_page');
                } elseif ($slug === 'vukov-vez') {
                    $page_id = (int) get_option('vv_page_id');
                } else {
                    $page_id = (int) url_to_postid($game['url']);
                }
            }
            if (!$page_id || get_post_status($page_id) !== 'publish') {
                continue;
            }
            $namespace = $game['rest_namespace'] ?? (
                in_array($slug, array('oko-kustosa','vukov-vez'), true) ? $slug . '/v1' : ''
            );
            $games[$slug] = array(
                'name'=>$game['name'], 'url'=>$game['url'], 'description'=>$game['description'] ?? '',
                'category'=>$game['category'], 'page_id'=>$page_id,
                'rest_namespace'=>is_string($namespace) ? trim($namespace, '/') : '',
                'source'=>$slug === 'vukov-vez' ? 'vukov-vez' : 'hub',
            );
        }
        if (isset($registered['srbija-na-dlanu']) && class_exists('SND_Site')) {
            $pages = (array) get_option('snd_pages', array());
            foreach (self::geographic_games() as $kind=>[$slug, $name, $description]) {
                if (empty($pages[$kind]) || get_post_status($pages[$kind]) !== 'publish') {
                    continue;
                }
                $games[$slug] = array(
                    'name'=>$name, 'description'=>$description, 'category'=>'geografija',
                    'url'=>get_permalink($pages[$kind]), 'page_id'=>(int) $pages[$kind],
                    'rest_namespace'=>'', 'source'=>'geografija', 'kind'=>$kind,
                );
            }
        }
        return $games;
    }

    public static function legacy_statuses() {
        $statuses = array();
        foreach (self::games() as $slug=>$game) {
            if ($game['source'] === 'geografija') {
                $statuses[$slug] = SND_Settings::get($game['kind'] . '_enabled') ? 'active' : 'inactive';
            } elseif (in_array($slug, array('vukov-vez','oko-kustosa'), true)) {
                $statuses[$slug] = 'active';
            }
        }
        return $statuses;
    }

    public static function status($slug) {
        $explicit = get_option(self::STATUS_OPTION . '_' . $slug, null);
        if (is_string($explicit) && isset(self::STATUSES[$explicit])) {
            return $explicit;
        }
        $statuses = get_option(self::STATUS_OPTION, null);
        // Existing games keep running between a plugin update and the first admin request.
        if ($statuses === null && dnevne_igrice_page_id()) {
            $statuses = self::legacy_statuses();
        }
        return $statuses[$slug] ?? 'inactive';
    }

    public static function retired_page_id() {
        $id = (int) get_option(self::PAGE_OPTION, 0);
        if (!$id) {
            $page = get_page_by_path('nase-igre', OBJECT, 'page');
            $id = $page ? $page->ID : 0;
        }
        return $id && get_post_meta($id, '_di_our_games', true) ? $id : 0;
    }

    public static function public_directory_exists() {
        $id = self::retired_page_id();
        return $id && in_array(get_post_status($id), array('publish', 'future', 'private'), true);
    }

    public static function install($upgrade) {
        if (dnevne_igrice_is_legacy_site()) {
            return;
        }
        add_option(self::STATUS_OPTION, $upgrade ? self::legacy_statuses() : array(), '', false);
        DI_Game_Stats::install();
        if (self::public_directory_exists()) {
            wp_update_post(array('ID'=>self::retired_page_id(), 'post_status'=>'draft'));
        }
    }

    public static function match_url($url, $games) {
        $host = wp_parse_url($url, PHP_URL_HOST);
        if ($host && !in_array($host, array(wp_parse_url(home_url('/'), PHP_URL_HOST), 'cvjetan.dev'), true)) {
            return '';
        }
        $path = untrailingslashit((string) wp_parse_url($url, PHP_URL_PATH));
        foreach ($games as $slug=>$game) {
            if ($path === untrailingslashit((string) wp_parse_url($game['url'], PHP_URL_PATH))) {
                return $slug;
            }
        }
        return '';
    }

    private static function status_for_page($page_id) {
        if ((int) $page_id && (int) $page_id === self::retired_page_id()) {
            return 'inactive';
        }
        foreach (self::games() as $slug=>$game) {
            if ((int) $page_id === $game['page_id']) {
                return self::status($slug);
            }
        }
        return '';
    }

    public static function guard_page() {
        if (dnevne_igrice_is_legacy_site() || !is_page()) {
            return;
        }
        $page_id = get_queried_object_id();
        $status = self::status_for_page($page_id);
        if ($status === '' || $status === 'active') {
            return;
        }
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        nocache_headers();
        header('X-Robots-Tag: noindex, follow', true);
        $GLOBALS['wp_query']->set_404();
        status_header(404);
    }

    public static function guard_request($response, $handler, $request) {
        if (dnevne_igrice_is_legacy_site() || is_wp_error($response)) {
            return $response;
        }
        $route = $request->get_route();
        if (preg_match('~^/wp/v2/pages/(\d+)$~D', $route, $matches)
            && in_array(self::status_for_page((int) $matches[1]), array('inactive','test'), true)
            && !current_user_can('manage_options')) {
            return new WP_Error('di_game_hidden', 'Stranica nije dostupna.', array('status'=>404));
        }
        $slug = '';
        if (preg_match('~^/srbija-na-dlanu/v1/(start|resume|action|claim)$~D', $route, $matches)) {
            $kind = $request->get_param('kind');
            if ($matches[1] !== 'start') {
                $token = $request->get_param('token');
                $state = is_string($token) && preg_match('/^[a-f0-9]{48}$/D', $token)
                    ? get_transient('snd_session_' . $token) : null;
                $kind = is_array($state) ? ($state['challenge']['kind'] ?? '') : '';
            }
            if (is_string($kind)) {
                $slug = self::geographic_games()[$kind][0] ?? '';
            }
        } else {
            foreach (self::games() as $key=>$game) {
                $namespace = $game['rest_namespace'];
                if ($namespace && ($route === '/' . $namespace || strpos($route, '/' . $namespace . '/') === 0)) {
                    $slug = $key;
                    break;
                }
            }
        }
        if ($slug && self::status($slug) !== 'active') {
            return new WP_Error('di_game_unavailable', 'Igra trenutno nije dostupna za igranje.', array('status'=>404));
        }
        return $response;
    }

    public static function excluded_page_ids($ids = array()) {
        if (dnevne_igrice_is_legacy_site()) {
            return $ids;
        }
        $retired_page = self::retired_page_id();
        if ($retired_page) {
            $ids[] = $retired_page;
        }
        foreach (self::games() as $slug=>$game) {
            if ($game['page_id'] && self::status($slug) !== 'active') {
                $ids[] = $game['page_id'];
            }
        }
        return array_values(array_unique($ids));
    }

    public static function filter_search($query) {
        if (!is_admin() && $query->is_main_query() && $query->is_search()) {
            $query->set('post__not_in', self::excluded_page_ids((array) $query->get('post__not_in')));
        }
    }

    public static function filter_public_pages($args) {
        $args['post__not_in'] = self::excluded_page_ids((array) ($args['post__not_in'] ?? array()));
        if (!empty($args['post__in'])) {
            $args['post__in'] = array_values(array_diff($args['post__in'], $args['post__not_in'])) ?: array(0);
        }
        return $args;
    }

    public static function filter_core_sitemap($args, $type) {
        return $type === 'page' ? self::filter_public_pages($args) : $args;
    }

    public static function filter_slim_sitemap($entry, $post) {
        return $entry || in_array((int) $post->ID, self::excluded_page_ids(), true);
    }

    public static function filter_snd_menu($settings) {
        if ((is_admin() && !wp_doing_ajax()) || dnevne_igrice_is_legacy_site() || get_option(self::STATUS_OPTION, null) === null) {
            return $settings;
        }
        $settings = (array) $settings;
        foreach (self::geographic_games() as $kind=>$game) {
            $settings[$kind . '_enabled'] = self::status($game[0]) === 'active';
        }
        return $settings;
    }
}

add_action('template_redirect', array('DI_Game_Hub','guard_page'), 0);
add_filter('rest_request_before_callbacks', array('DI_Game_Hub','guard_request'), 10, 3);
add_action('pre_get_posts', array('DI_Game_Hub','filter_search'));
add_filter('wpseo_exclude_from_sitemap_by_post_ids', array('DI_Game_Hub','excluded_page_ids'), 30);
add_filter('wp_sitemaps_posts_query_args', array('DI_Game_Hub','filter_core_sitemap'), 30, 2);
add_filter('slim_seo_sitemap_post_ignore', array('DI_Game_Hub','filter_slim_sitemap'), 30, 2);
add_filter('oembed_response_data', static function ($data, $post) {
    return in_array((int) $post->ID, DI_Game_Hub::excluded_page_ids(), true) ? false : $data;
}, 30, 2);
add_filter('rest_page_query', static function ($args, $request) {
    return $request->get_param('context') === 'edit' && current_user_can('manage_options')
        ? $args : DI_Game_Hub::filter_public_pages($args);
}, 10, 2);
add_filter('rest_post_search_query', array('DI_Game_Hub','filter_public_pages'));
add_filter('option_snd_settings', array('DI_Game_Hub','filter_snd_menu'));
add_filter('default_option_snd_settings', array('DI_Game_Hub','filter_snd_menu'));
